# Module F02: GearGuard Landing Page

## Overview

**Estimated Time:** 45min

**Complexity:** Simple

**Type:** Frontend-only

**Risk Level:** Low

**Dependencies:** None

## Problem Context

Companies need a professional landing page to showcase GearGuard's maintenance management capabilities, onboard new users, and provide information about the system's features and benefits.

## Technical Requirements

**Module Type:** Frontend-only

### Frontend Tasks

- [ ] **Landing Pages:** Create comprehensive marketing pages
  - `pages/landing/LandingPage.tsx` - Main hero section and features
  - `pages/landing/FeaturesPage.tsx` - Detailed feature showcase
  - `pages/landing/PricingPage.tsx` - Pricing plans and tiers
  - `pages/landing/AboutPage.tsx` - Company and product information
  - `pages/landing/ContactPage.tsx` - Contact forms and information
  - `pages/landing/HelpPage.tsx` - FAQ and help documentation

- [ ] **Components:** Reusable landing page components
  - `components/landing/HeroSection.tsx` - Hero banner with CTA
  - `components/landing/FeatureCard.tsx` - Feature highlight cards
  - `components/landing/TestimonialCard.tsx` - Customer testimonials
  - `components/landing/PricingCard.tsx` - Pricing tier cards
  - `components/landing/ContactForm.tsx` - Contact and demo request forms
  - `components/landing/FAQSection.tsx` - Frequently asked questions
  - `components/landing/StatsSection.tsx` - Key statistics and metrics

- [ ] **Routing:** Add landing page routes to React Router
  - `/` - Main landing page (redirects to dashboard if signed in)
  - `/features` - Feature showcase
  - `/pricing` - Pricing information
  - `/about` - About the company/product
  - `/contact` - Contact and demo requests
  - `/help` - FAQ and documentation

- [ ] **Responsive Design:** Mobile-first approach with Tailwind CSS
  - Hero section optimized for all screen sizes
  - Feature cards in responsive grid layout
  - Mobile-friendly navigation and forms

- [ ] **Static Content:** No backend dependencies initially
  - All content hardcoded for fast development
  - Images from Lorem Picsum or local assets
  - Contact forms can be enhanced later with backend integration

### Database Schema

**No database required** - This is a frontend-only module for the foundation phase.

## Enhancement Features

### Enhancement Feature: Dynamic Equipment Statistics

**Problem Solved:** Landing page visitors want to see real-time statistics about equipment being managed and maintenance efficiency.

**Enhancement Type:** Smart Logic + Future API Integration - Display compelling statistics that can be made dynamic later

**User Trigger:** Automatic display in stats section of landing page

**Input Requirements:**
- **Required Fields:** None (uses static data initially)
- **Optional Fields:** Real equipment data (for future integration)
- **Validation Rules:** Statistics must be realistic and compelling

**Processing Logic:**
1. **Static Phase:** Display impressive but realistic statistics
2. **Dynamic Phase:** (M06) Integrate with equipment API for real numbers
3. **Animation:** Count-up animations for visual appeal
4. **Caching:** Cache real statistics for performance

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface LandingStats {
  totalEquipment: number;
  activeRequests: number;
  completedMaintenance: number;
  uptime: number; // percentage
  costSavings: number; // in dollars
  responseTime: number; // in hours
}

export interface FeatureHighlight {
  id: string;
  title: string;
  description: string;
  icon: string;
  benefits: string[];
}

export interface TestimonialData {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
  rating: number;
  avatar?: string;
}

export interface PricingTier {
  id: string;
  name: string;
  price: number;
  period: 'month' | 'year';
  features: string[];
  recommended?: boolean;
  maxEquipment?: number;
  maxUsers?: number;
}
```

**Frontend Component:**
```typescript
// components/landing/StatsSection.tsx
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface StatItemProps {
  label: string;
  value: number;
  suffix?: string;
  prefix?: string;
  format?: 'number' | 'percentage' | 'currency' | 'time';
}

const StatItem = ({ label, value, suffix, prefix, format }: StatItemProps) => {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    const duration = 2000; // 2 seconds
    const steps = 60;
    const increment = value / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value]);

  const formatValue = (val: number) => {
    switch (format) {
      case 'percentage':
        return `${val}%`;
      case 'currency':
        return `$${val.toLocaleString()}`;
      case 'time':
        return `${val}h`;
      default:
        return val.toLocaleString();
    }
  };

  return (
    <div className="text-center">
      <div className="text-3xl font-bold text-primary mb-2">
        {prefix}{formatValue(displayValue)}{suffix}
      </div>
      <div className="text-sm text-muted-foreground">{label}</div>
    </div>
  );
};

export const StatsSection = () => {
  // Static impressive statistics for foundation phase
  const stats = {
    totalEquipment: 2847,
    activeRequests: 156,
    completedMaintenance: 12453,
    uptime: 98.7,
    costSavings: 284000,
    responseTime: 2.3
  };

  return (
    <section className="py-16 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            Trusted by Companies Worldwide
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            See how GearGuard is transforming maintenance management across industries
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          <Card>
            <CardContent className="p-6">
              <StatItem
                label="Equipment Tracked"
                value={stats.totalEquipment}
                format="number"
              />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <StatItem
                label="Active Requests"
                value={stats.activeRequests}
                format="number"
              />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <StatItem
                label="Completed Jobs"
                value={stats.completedMaintenance}
                format="number"
              />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <StatItem
                label="System Uptime"
                value={stats.uptime}
                format="percentage"
              />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <StatItem
                label="Cost Savings"
                value={stats.costSavings}
                format="currency"
              />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <StatItem
                label="Avg Response"
                value={stats.responseTime}
                format="time"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};
```

**Hero Section Component:**
```typescript
// components/landing/HeroSection.tsx
import { Button } from '@/components/ui/button';
import { ArrowRight, Shield, Wrench, BarChart3 } from 'lucide-react';
import { Link } from 'react-router-dom';

export const HeroSection = () => {
  return (
    <section className="relative py-20 lg:py-32 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                The Ultimate
                <span className="text-primary block">
                  Maintenance Tracker
                </span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Streamline your equipment management, automate maintenance workflows, 
                and keep your operations running smoothly with GearGuard's intelligent 
                maintenance tracking system.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="text-lg px-8" asChild>
                <Link to="/sign-up">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8" asChild>
                <Link to="/contact">
                  Schedule Demo
                </Link>
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-500" />
                <span className="text-sm text-muted-foreground">Enterprise Security</span>
              </div>
              <div className="flex items-center gap-2">
                <Wrench className="h-5 w-5 text-blue-500" />
                <span className="text-sm text-muted-foreground">24/7 Support</span>
              </div>
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-purple-500" />
                <span className="text-sm text-muted-foreground">Real-time Analytics</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl p-8">
              <img
                src="https://picsum.photos/600/400?random=maintenance"
                alt="GearGuard Dashboard Preview"
                className="rounded-lg shadow-2xl w-full"
              />
            </div>
            
            {/* Floating stats cards */}
            <div className="absolute -top-4 -left-4 bg-white rounded-lg shadow-lg p-4 border">
              <div className="text-2xl font-bold text-green-500">98.7%</div>
              <div className="text-sm text-muted-foreground">Uptime</div>
            </div>
            
            <div className="absolute -bottom-4 -right-4 bg-white rounded-lg shadow-lg p-4 border">
              <div className="text-2xl font-bold text-blue-500">2.3h</div>
              <div className="text-sm text-muted-foreground">Avg Response</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
```

**Features Section Component:**
```typescript
// components/landing/FeaturesSection.tsx
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Wrench, 
  Users, 
  Calendar, 
  BarChart3, 
  Shield, 
  Zap,
  Clock,
  Target,
  TrendingUp
} from 'lucide-react';

const features = [
  {
    icon: Wrench,
    title: 'Equipment Tracking',
    description: 'Comprehensive asset management with ownership, warranties, and technical specifications.',
    benefits: ['Serial number tracking', 'Warranty management', 'Location monitoring', 'Status updates']
  },
  {
    icon: Users,
    title: 'Team Management',
    description: 'Organize maintenance teams by specialization and automatically assign requests.',
    benefits: ['Specialized teams', 'Auto-assignment', 'Workload balancing', 'Skill matching']
  },
  {
    icon: Calendar,
    title: 'Smart Scheduling',
    description: 'Preventive maintenance scheduling with calendar integration and automated reminders.',
    benefits: ['Calendar view', 'Automated scheduling', 'Reminder system', 'Conflict detection']
  },
  {
    icon: BarChart3,
    title: 'Analytics Dashboard',
    description: 'Real-time insights into maintenance performance, costs, and equipment health.',
    benefits: ['Performance metrics', 'Cost tracking', 'Trend analysis', 'Custom reports']
  },
  {
    icon: Zap,
    title: 'Workflow Automation',
    description: 'Kanban boards, auto-assignment, and smart notifications for seamless operations.',
    benefits: ['Kanban workflow', 'Auto-assignment', 'Smart notifications', 'Status tracking']
  },
  {
    icon: Shield,
    title: 'Enterprise Security',
    description: 'Role-based access control, audit trails, and enterprise-grade security.',
    benefits: ['RBAC system', 'Audit logging', 'Data encryption', 'Compliance ready']
  }
];

export const FeaturesSection = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            Everything You Need for Maintenance Excellence
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            From equipment tracking to predictive analytics, GearGuard provides 
            all the tools your team needs to maintain peak operational efficiency.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="h-full hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {feature.description}
                </p>
                <ul className="space-y-2">
                  {feature.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
```

**Contact Form Component:**
```typescript
// components/landing/ContactForm.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';

export const ContactForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    message: '',
    requestType: 'demo'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // For foundation phase, just simulate success
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success('Thank you! We\'ll get back to you within 24 hours.');
      setFormData({
        name: '',
        email: '',
        company: '',
        phone: '',
        message: '',
        requestType: 'demo'
      });
    } catch (error) {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Get Started with GearGuard</CardTitle>
        <p className="text-muted-foreground">
          Schedule a demo or get in touch with our team to learn how GearGuard 
          can transform your maintenance operations.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="John Doe"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="john@company.com"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="company">Company</Label>
              <Input
                id="company"
                name="company"
                value={formData.company}
                onChange={handleChange}
                placeholder="Your Company"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+1 (555) 123-4567"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              placeholder="Tell us about your maintenance management needs..."
              rows={4}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full" 
            size="lg"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Sending...' : 'Schedule Demo'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` for frontend patterns and component structure.

### Step 1: Frontend Implementation

1. Create landing page components using shadcn/ui
2. Implement responsive design with Tailwind CSS
3. Add animated statistics section
4. Create contact forms (static for now)
5. Set up routing for all landing pages

### Step 2: Content Creation

1. Write compelling copy for all sections
2. Source appropriate images (Lorem Picsum for development)
3. Create realistic statistics and testimonials
4. Design pricing tiers and feature comparisons

### Step 3: Integration

1. Add landing page routes to React Router
2. Ensure proper redirects for authenticated users
3. Test responsive design on all devices
4. Optimize loading performance

## Acceptance Criteria

- [ ] Professional landing page with hero section and features
- [ ] Animated statistics section with count-up effects
- [ ] Responsive design works on all screen sizes
- [ ] Contact forms collect user information (static submission)
- [ ] Multiple landing pages (features, pricing, about, contact, help)
- [ ] Proper routing and navigation between pages
- [ ] **Demo Ready:** Can showcase professional landing page in 30 seconds
- [ ] **Frontend-Only:** No backend dependencies for foundation phase
- [ ] **Mobile Responsive:** Optimized for mobile devices
- [ ] **Fast Loading:** Optimized images and minimal dependencies

## Testing Checklist

- [ ] **Responsive Testing:** Test on mobile, tablet, and desktop
- [ ] **Form Testing:** Verify contact forms work correctly
- [ ] **Navigation Testing:** Test all internal links and routing
- [ ] **Performance Testing:** Check loading times and image optimization
- [ ] **Cross-Browser Testing:** Test in Chrome, Firefox, Safari

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in client
- [ ] **Routing:** Added landing page routes to React Router
- [ ] **Assets:** Optimized images and static content
- [ ] **Testing:** Manual testing completed across devices