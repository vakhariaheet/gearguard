# Module F01: Equipment Management

## Overview

**Estimated Time:** 1hr

**Complexity:** Medium

**Type:** Full-stack

**Risk Level:** Low

**Dependencies:** None

## Problem Context

Companies need a central database to track all assets (machines, vehicles, computers) with ownership details, technical specifications, and assigned maintenance teams. This module serves as the foundation for all maintenance operations.

## Technical Requirements

**Module Type:** Full-stack

### Backend Tasks

- [ ] **Handler Files:** Create CRUD handlers for equipment management
  - `handlers/listEquipment.ts` - GET /api/equipment
  - `handlers/getEquipment.ts` - GET /api/equipment/:id  
  - `handlers/createEquipment.ts` - POST /api/equipment
  - `handlers/updateEquipment.ts` - PUT /api/equipment/:id
  - `handlers/deleteEquipment.ts` - DELETE /api/equipment/:id

- [ ] **Function Configs:** Create serverless function configurations
  - `functions/listEquipment.yml`
  - `functions/getEquipment.yml`
  - `functions/createEquipment.yml`
  - `functions/updateEquipment.yml`
  - `functions/deleteEquipment.yml`

- [ ] **Service Layer:** Business logic in `services/EquipmentService.ts`
  - Equipment CRUD operations
  - Department and employee assignment logic
  - Warranty status calculations
  - Location tracking

- [ ] **Type Definitions:** Add types to `types.ts`
  - Equipment entity with all required fields
  - Request/response types for API endpoints
  - Department and ownership enums

- [ ] **RBAC Verification:** Module already configured in `config/permissions.ts`

- [ ] **AWS Service Integration:** Use `shared/clients/dynamodb` for data storage

### Frontend Tasks

- [ ] **Components:** Equipment management UI components
  - `components/equipment/EquipmentList.tsx` - List view with shadcn table
  - `components/equipment/EquipmentForm.tsx` - Create/edit form
  - `components/equipment/EquipmentCard.tsx` - Card component for grid view
  - `components/equipment/EquipmentDetails.tsx` - Detail view with smart buttons

- [ ] **Pages:** Equipment management pages
  - `pages/equipment/EquipmentListPage.tsx` - Main equipment list
  - `pages/equipment/EquipmentCreatePage.tsx` - Create new equipment
  - `pages/equipment/EquipmentEditPage.tsx` - Edit existing equipment

- [ ] **API Integration:** Equipment API service
  - `hooks/useEquipment.ts` - React Query hooks for equipment operations
  - `services/equipmentApi.ts` - API service functions

- [ ] **Routing:** Add equipment routes to React Router

### Database Schema (Single Table)

```
PK: EQUIPMENT#[id] | SK: DETAILS | GSI1PK: DEPT#[department] | GSI1SK: EQUIPMENT#[id]
PK: EQUIPMENT#[id] | SK: OWNER#[employeeId] | GSI1PK: EMPLOYEE#[employeeId] | GSI1SK: EQUIPMENT#[id]

Fields:
- equipmentName: string (required)
- serialNumber: string (unique)
- category: string (Machine, Vehicle, Computer, etc.)
- department: string (Production, IT, Maintenance, etc.)
- assignedEmployee?: string (employee ID)
- assignedTeam: string (maintenance team ID)
- purchaseDate: string (ISO date)
- warrantyExpiry?: string (ISO date)
- location: string (physical location)
- status: 'Active' | 'Under Maintenance' | 'Scrapped'
- specifications?: Record<string, any> (technical details)
- createdAt: string
- updatedAt: string
```

## Enhancement Features

### Enhancement Feature: AI-Powered Equipment Health Assessment

**Problem Solved:** Managers need to predict when equipment might need maintenance based on usage patterns and historical data.

**Enhancement Type:** AI - Uses Gemini AI to analyze equipment data and predict maintenance needs

**User Trigger:** "Assess Health" button on equipment detail page

**Input Requirements:**
- **Required Fields:** Equipment ID, usage hours, last maintenance date
- **Optional Fields:** Performance metrics, error logs, environmental conditions
- **Validation Rules:** Equipment must exist, usage hours must be positive

**Processing Logic:**
1. **Input Validation:** Verify equipment exists and has sufficient historical data
2. **Data Analysis:** Analyze usage patterns, maintenance history, and performance metrics
3. **AI Assessment:** Use Gemini AI to predict maintenance needs and risk factors
4. **Result Generation:** Generate health score (0-100) with specific recommendations

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface Equipment {
  id: string;
  equipmentName: string;
  serialNumber: string;
  category: 'Machine' | 'Vehicle' | 'Computer' | 'Tool' | 'Other';
  department: string;
  assignedEmployee?: string;
  assignedTeam: string;
  purchaseDate: string;
  warrantyExpiry?: string;
  location: string;
  status: 'Active' | 'Under Maintenance' | 'Scrapped';
  specifications?: Record<string, any>;
  usageHours?: number;
  lastMaintenanceDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface HealthAssessmentRequest {
  equipmentId: string;
  usageHours?: number;
  performanceMetrics?: {
    efficiency: number;
    errorRate: number;
    downtime: number;
  };
  environmentalFactors?: {
    temperature: number;
    humidity: number;
    vibration: number;
  };
}

export interface HealthAssessmentResponse {
  equipmentId: string;
  healthScore: number; // 0-100
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  recommendations: string[];
  predictedMaintenanceDate?: string;
  confidence: number;
  factors: {
    age: number;
    usage: number;
    maintenance: number;
    performance: number;
  };
  timestamp: string;
}
```

**Frontend Component:**
```typescript
// components/equipment/HealthAssessmentButton.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/components/ui/use-toast';
import { Spinner } from '@/components/ui/spinner';
import { Equipment, HealthAssessmentResponse } from '@/types/equipment';

interface HealthAssessmentButtonProps {
  equipment: Equipment;
  onAssessmentComplete?: (assessment: HealthAssessmentResponse) => void;
}

export const HealthAssessmentButton = ({
  equipment,
  onAssessmentComplete
}: HealthAssessmentButtonProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [assessment, setAssessment] = useState<HealthAssessmentResponse | null>(null);

  const handleAssessment = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/equipment/${equipment.id}/assess-health`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          equipmentId: equipment.id,
          usageHours: equipment.usageHours,
          performanceMetrics: {
            efficiency: 85, // Could be from sensors or user input
            errorRate: 2,
            downtime: 5
          }
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Health assessment failed');
      }

      const data = await response.json();
      setAssessment(data.data);
      onAssessmentComplete?.(data.data);
      toast.success('Health assessment completed');
    } catch (error) {
      console.error('Health assessment error:', error);
      toast.error(error.message || 'Health assessment failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'Low': return 'bg-green-500';
      case 'Medium': return 'bg-yellow-500';
      case 'High': return 'bg-orange-500';
      case 'Critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="health-assessment-section">
      <Button
        onClick={handleAssessment}
        disabled={isLoading}
        variant="outline"
        size="sm"
        className="mb-4"
      >
        {isLoading ? (
          <>
            <Spinner className="w-3 h-3 mr-1" />
            Assessing...
          </>
        ) : (
          'Assess Health'
        )}
      </Button>

      {assessment && (
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Equipment Health Assessment
              <Badge className={getRiskColor(assessment.riskLevel)}>
                {assessment.riskLevel} Risk
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Health Score</span>
                  <span className="text-sm text-muted-foreground">
                    {assessment.healthScore}/100
                  </span>
                </div>
                <Progress value={assessment.healthScore} className="h-2" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-sm font-medium">Age Factor</span>
                  <Progress value={assessment.factors.age} className="h-1 mt-1" />
                </div>
                <div>
                  <span className="text-sm font-medium">Usage Factor</span>
                  <Progress value={assessment.factors.usage} className="h-1 mt-1" />
                </div>
                <div>
                  <span className="text-sm font-medium">Maintenance Factor</span>
                  <Progress value={assessment.factors.maintenance} className="h-1 mt-1" />
                </div>
                <div>
                  <span className="text-sm font-medium">Performance Factor</span>
                  <Progress value={assessment.factors.performance} className="h-1 mt-1" />
                </div>
              </div>

              {assessment.predictedMaintenanceDate && (
                <div className="p-3 bg-muted rounded-md">
                  <span className="text-sm font-medium">Predicted Next Maintenance:</span>
                  <span className="text-sm ml-2">
                    {new Date(assessment.predictedMaintenanceDate).toLocaleDateString()}
                  </span>
                </div>
              )}

              <div>
                <span className="text-sm font-medium mb-2 block">Recommendations:</span>
                <ul className="text-sm space-y-1">
                  {assessment.recommendations.map((rec, index) => (
                    <li key={index} className="flex items-start">
                      <span className="w-1 h-1 bg-current rounded-full mt-2 mr-2 flex-shrink-0" />
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="text-xs text-muted-foreground">
                Confidence: {Math.round(assessment.confidence * 100)}% • 
                Generated: {new Date(assessment.timestamp).toLocaleString()}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/EquipmentService.ts - Add this method
async assessEquipmentHealth(params: HealthAssessmentRequest): Promise<HealthAssessmentResponse> {
  try {
    // Get equipment details
    const equipment = await this.getEquipment(params.equipmentId);
    if (!equipment) {
      throw new Error('Equipment not found');
    }

    // Calculate age factor (0-100, higher is worse)
    const ageInYears = (Date.now() - new Date(equipment.purchaseDate).getTime()) / (1000 * 60 * 60 * 24 * 365);
    const ageFactor = Math.min(ageInYears * 10, 100);

    // Calculate usage factor
    const usageFactor = params.usageHours ? Math.min(params.usageHours / 100, 100) : 50;

    // Calculate maintenance factor (days since last maintenance)
    let maintenanceFactor = 50;
    if (equipment.lastMaintenanceDate) {
      const daysSinceLastMaintenance = (Date.now() - new Date(equipment.lastMaintenanceDate).getTime()) / (1000 * 60 * 60 * 24);
      maintenanceFactor = Math.min(daysSinceLastMaintenance / 30 * 10, 100);
    }

    // Calculate performance factor
    const performanceFactor = params.performanceMetrics 
      ? (100 - params.performanceMetrics.efficiency) + params.performanceMetrics.errorRate + params.performanceMetrics.downtime
      : 30;

    // Use AI to generate comprehensive assessment
    const aiPrompt = `Analyze equipment health for maintenance prediction:

Equipment: ${equipment.equipmentName} (${equipment.category})
Age: ${ageInYears.toFixed(1)} years
Usage Hours: ${params.usageHours || 'Unknown'}
Last Maintenance: ${equipment.lastMaintenanceDate || 'Never'}
Current Status: ${equipment.status}

Factors:
- Age Factor: ${ageFactor.toFixed(1)}/100
- Usage Factor: ${usageFactor.toFixed(1)}/100  
- Maintenance Factor: ${maintenanceFactor.toFixed(1)}/100
- Performance Factor: ${performanceFactor.toFixed(1)}/100

Generate a health assessment with:
1. Overall health score (0-100, higher is better)
2. Risk level (Low/Medium/High/Critical)
3. 3-5 specific maintenance recommendations
4. Predicted next maintenance date (if applicable)

Consider equipment type, age, usage patterns, and maintenance history.`;

    const aiResponse = await geminiClient.generateJSON({
      prompt: aiPrompt,
      schema: {
        healthScore: 'number',
        riskLevel: 'string',
        recommendations: 'array of strings',
        predictedMaintenanceDate: 'string or null',
        reasoning: 'string'
      }
    });

    // Calculate overall health score (weighted average, inverted for health)
    const calculatedHealthScore = Math.max(0, 100 - (
      (ageFactor * 0.2) + 
      (usageFactor * 0.3) + 
      (maintenanceFactor * 0.3) + 
      (performanceFactor * 0.2)
    ));

    // Use AI score if reasonable, otherwise use calculated
    const finalHealthScore = aiResponse.healthScore && aiResponse.healthScore >= 0 && aiResponse.healthScore <= 100
      ? aiResponse.healthScore
      : Math.round(calculatedHealthScore);

    // Determine risk level based on health score
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
    if (finalHealthScore >= 80) riskLevel = 'Low';
    else if (finalHealthScore >= 60) riskLevel = 'Medium';
    else if (finalHealthScore >= 40) riskLevel = 'High';
    else riskLevel = 'Critical';

    // Generate default recommendations if AI didn't provide good ones
    const defaultRecommendations = [
      `Schedule routine inspection for ${equipment.equipmentName}`,
      'Check warranty status and coverage options',
      'Review usage patterns and optimize operation schedule',
      'Update maintenance logs and documentation'
    ];

    return {
      equipmentId: params.equipmentId,
      healthScore: finalHealthScore,
      riskLevel: aiResponse.riskLevel || riskLevel,
      recommendations: aiResponse.recommendations?.length > 0 ? aiResponse.recommendations : defaultRecommendations,
      predictedMaintenanceDate: aiResponse.predictedMaintenanceDate,
      confidence: 0.85,
      factors: {
        age: Math.round(ageFactor),
        usage: Math.round(usageFactor),
        maintenance: Math.round(maintenanceFactor),
        performance: Math.round(performanceFactor)
      },
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Equipment health assessment failed:', error);
    throw new Error(`Health assessment failed: ${error.message}`);
  }
}
```

**API Handler:**
```typescript
// handlers/assessEquipmentHealth.ts
import { APIGatewayProxyResultV2 } from 'aws-lambda';
import { AuthenticatedAPIGatewayEvent } from '../../../shared/types';
import { withRbac } from '../../../shared/auth/rbacMiddleware';
import { successResponse, errorResponse, handleAsyncError } from '../../../shared/response';
import { equipmentService } from '../services/EquipmentService';
import { HealthAssessmentRequest } from '../types';

/**
 * @route POST /api/equipment/:id/assess-health
 * @description Assess equipment health using AI analysis
 */
const baseHandler = async (
  event: AuthenticatedAPIGatewayEvent
): Promise<APIGatewayProxyResultV2> => {
  try {
    const equipmentId = event.pathParameters?.id;
    if (!equipmentId) {
      return errorResponse(400, 'MISSING_EQUIPMENT_ID', 'Equipment ID is required');
    }

    // Parse request body
    const body: Partial<HealthAssessmentRequest> = JSON.parse(event.body || '{}');

    // Validate equipment exists
    const equipment = await equipmentService.getEquipment(equipmentId);
    if (!equipment) {
      return errorResponse(404, 'EQUIPMENT_NOT_FOUND', 'Equipment not found');
    }

    // Perform health assessment
    const assessment = await equipmentService.assessEquipmentHealth({
      equipmentId,
      ...body
    });

    return successResponse(assessment);
  } catch (error) {
    return handleAsyncError(error);
  }
};

export const handler = withRbac(baseHandler, 'equipment', 'read');
```

**Function Configuration:**
```yaml
# functions/assessEquipmentHealth.yml
assessEquipmentHealth:
  handler: src/modules/equipment/handlers/assessEquipmentHealth.handler
  events:
    - httpApi:
        path: /api/equipment/{id}/assess-health
        method: post
        authorizer:
          name: clerkJwtAuthorizer
  environment:
    GEMINI_API_KEY: ${env:GEMINI_API_KEY}
  timeout: 30
  memorySize: 512
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` COMPLETELY before writing any code.

### Step 1: Backend Implementation (Lambda-Compatible)

1. Create handlers for CRUD operations following existing patterns
2. Implement EquipmentService with business logic
3. Add health assessment feature using Gemini AI
4. Configure serverless functions with proper RBAC

### Step 2: Frontend Implementation

1. Create equipment management components using shadcn/ui
2. Implement health assessment UI with progress indicators
3. Add equipment list with smart buttons showing request counts
4. Integrate with backend APIs using React Query

### Step 3: Integration

1. Add equipment routes to React Router
2. Update navigation to include equipment management
3. Test health assessment feature end-to-end
4. Verify RBAC permissions work correctly

## Acceptance Criteria

- [ ] Equipment CRUD operations work for all user roles
- [ ] Health assessment generates AI-powered recommendations
- [ ] Smart buttons show maintenance request counts
- [ ] Equipment can be assigned to departments and employees
- [ ] Warranty status is calculated and displayed
- [ ] **Demo Ready:** Can demonstrate equipment management and health assessment in 30 seconds
- [ ] **Full-Stack Working:** Frontend connects to backend, backend connects to database
- [ ] **Lambda Compatible:** Backend code works in serverless environment
- [ ] **Error Handling:** Graceful failure modes implemented
- [ ] **Mobile Responsive:** Works on mobile devices

## Testing Checklist

- [ ] **Manual API Testing:** Test with Postman/curl
- [ ] **Frontend Testing:** Manual testing in browser
- [ ] **Health Assessment:** Test AI-powered health assessment feature
- [ ] **RBAC Testing:** Verify permissions work for different roles
- [ ] **Integration:** End-to-end flow works as expected

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **Serverless Config:** Added function imports to serverless.yml
- [ ] **RBAC Config:** Verified permissions.ts includes equipment module
- [ ] **Types:** Exported types from module's types.ts for frontend use
- [ ] **Testing:** Manual testing completed