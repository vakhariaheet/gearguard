# Module M08: Kanban Board + Calendar Integration

## Overview

**Estimated Time:** 1.5hr

**Complexity:** Complex

**Type:** Integration

**Risk Level:** Medium

**Dependencies:** F04 (Request Management) + F01 (Equipment Management) + F03 (Maintenance Teams)

## Problem Context

Create the primary workspace for technicians and managers with a visual Kanban board for request workflow management and integrated calendar view for preventive maintenance scheduling. This module provides the core user interface that brings together all maintenance operations in an intuitive, drag-and-drop workflow system.

## Technical Requirements

**Module Type:** Integration (Connects F01, F03, F04 with visual workflow)

### Backend Tasks

- [ ] **Integration Handler Files:** Create handlers for Kanban and calendar operations
  - `handlers/getKanbanBoard.ts` - GET /api/kanban/board
  - `handlers/updateRequestStatus.ts` - PUT /api/kanban/requests/:id/status
  - `handlers/getCalendarEvents.ts` - GET /api/calendar/events
  - `handlers/createCalendarEvent.ts` - POST /api/calendar/events
  - `handlers/updateCalendarEvent.ts` - PUT /api/calendar/events/:id

- [ ] **Function Configs:** Create function configurations
  - `functions/getKanbanBoard.yml`
  - `functions/updateRequestStatus.yml`
  - `functions/getCalendarEvents.yml`
  - `functions/createCalendarEvent.yml`
  - `functions/updateCalendarEvent.yml`

- [ ] **Integration Service Layer:** Create KanbanService and CalendarService
  - Kanban board data aggregation
  - Status transition validation
  - Calendar event management
  - Cross-module data synchronization

- [ ] **Type Definitions:** Add Kanban and calendar types
  - Kanban board structure
  - Calendar event interfaces
  - Status transition rules

- [ ] **Real-time Updates:** WebSocket integration for live updates
  - Real-time status changes
  - Live calendar updates
  - Multi-user collaboration

### Frontend Tasks

- [ ] **Core Components:** Create Kanban and calendar components
  - `components/kanban/KanbanBoard.tsx` - Main Kanban interface
  - `components/kanban/KanbanColumn.tsx` - Status columns (New, In Progress, Repaired, Scrap)
  - `components/kanban/RequestCard.tsx` - Draggable request cards
  - `components/calendar/MaintenanceCalendar.tsx` - Calendar view for preventive maintenance
  - `components/calendar/CalendarEventModal.tsx` - Event creation/editing

- [ ] **Pages:** Main workspace pages
  - `pages/workspace/KanbanPage.tsx` - Primary technician workspace
  - `pages/workspace/CalendarPage.tsx` - Maintenance scheduling interface
  - `pages/workspace/WorkspacePage.tsx` - Combined Kanban + Calendar view

- [ ] **Drag & Drop:** Implement drag-and-drop functionality
  - React DnD or similar library for Kanban
  - Status transition validation
  - Optimistic updates with rollback

- [ ] **Real-time Integration:** WebSocket connection for live updates
  - Real-time status changes across users
  - Live calendar event updates
  - Conflict resolution for concurrent edits

### Database Schema Extensions

```
PK: KANBAN#BOARD | SK: CONFIG | GSI1PK: BOARD_TYPE#[type] | GSI1SK: KANBAN#BOARD
PK: CALENDAR#EVENT#[id] | SK: DETAILS | GSI1PK: DATE#[date] | GSI1SK: EVENT#[id]
PK: CALENDAR#EVENT#[id] | SK: RECURRENCE | GSI1PK: RECURRENCE_TYPE#[type] | GSI1SK: EVENT#[id]

Kanban Configuration:
- columns: Array<{
  id: string;
  title: string;
  status: string;
  color: string;
  order: number;
  limits?: { min?: number; max?: number };
}>
- rules: {
  allowedTransitions: Record<string, string[]>;
  autoTransitions: Array<{
    from: string;
    to: string;
    condition: string;
    delay?: number;
  }>;
}

Calendar Event Fields:
- title: string
- description?: string
- startTime: string (ISO date)
- endTime: string (ISO date)
- eventType: 'Preventive' | 'Scheduled' | 'Meeting' | 'Deadline'
- equipmentId?: string
- assignedTeam?: string
- assignedTechnician?: string
- recurrence?: {
  type: 'Daily' | 'Weekly' | 'Monthly' | 'Yearly';
  interval: number;
  endDate?: string;
  daysOfWeek?: number[];
}
- isAllDay: boolean
- location?: string
- priority: 'Low' | 'Medium' | 'High' | 'Critical'
- status: 'Scheduled' | 'InProgress' | 'Completed' | 'Cancelled'
```

## Enhancement Features

### Enhancement Feature: Smart Kanban Automation

**Problem Solved:** Automatically move requests through workflow stages based on conditions, time elapsed, and technician actions to reduce manual status updates and ensure consistent workflow progression.

**Enhancement Type:** Smart Logic + Real-time Updates - Uses business rules and real-time monitoring to automate workflow transitions

**User Trigger:** Automatic based on conditions or manual drag-and-drop with smart suggestions

**Input Requirements:**
- **Required Fields:** Request status changes, time-based triggers
- **Optional Fields:** Technician actions, equipment status updates
- **Validation Rules:** Status transitions must follow defined workflow rules

**Processing Logic:**
1. **Rule Engine:** Evaluate transition conditions and business rules
2. **Time-based Triggers:** Automatically progress requests based on elapsed time
3. **Smart Suggestions:** Suggest next actions based on request context
4. **Real-time Sync:** Update all connected users instantly via WebSocket

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface KanbanBoard {
  id: string;
  name: string;
  columns: KanbanColumn[];
  rules: WorkflowRules;
  filters: BoardFilters;
  lastUpdated: string;
}

export interface KanbanColumn {
  id: string;
  title: string;
  status: 'New' | 'In Progress' | 'Repaired' | 'Scrap';
  color: string;
  order: number;
  requests: RequestCard[];
  limits?: {
    min?: number;
    max?: number;
    warnAt?: number;
  };
  automationRules?: AutomationRule[];
}

export interface RequestCard {
  id: string;
  subject: string;
  description?: string;
  equipmentName: string;
  equipmentCategory: string;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  assignedTechnician?: {
    id: string;
    name: string;
    avatar?: string;
  };
  assignedTeam?: string;
  createdAt: string;
  updatedAt: string;
  dueDate?: string;
  estimatedHours?: number;
  actualHours?: number;
  tags: string[];
  isOverdue: boolean;
  healthScore?: number;
  lastActivity?: string;
}

export interface WorkflowRules {
  allowedTransitions: Record<string, string[]>;
  autoTransitions: AutoTransition[];
  validationRules: ValidationRule[];
  notificationRules: NotificationRule[];
}

export interface AutoTransition {
  id: string;
  name: string;
  fromStatus: string;
  toStatus: string;
  condition: TransitionCondition;
  delay?: number; // minutes
  isActive: boolean;
}

export interface TransitionCondition {
  type: 'TimeElapsed' | 'TechnicianAction' | 'EquipmentStatus' | 'SLABreach' | 'Custom';
  value: any;
  operator: 'equals' | 'greaterThan' | 'lessThan' | 'contains';
}

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  eventType: 'Preventive' | 'Scheduled' | 'Meeting' | 'Deadline' | 'Emergency';
  equipmentId?: string;
  equipmentName?: string;
  assignedTeam?: string;
  assignedTechnician?: string;
  location?: string;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Scheduled' | 'InProgress' | 'Completed' | 'Cancelled';
  isAllDay: boolean;
  recurrence?: RecurrenceRule;
  attendees?: string[];
  relatedRequestId?: string;
  estimatedDuration?: number; // minutes
  actualDuration?: number; // minutes
  createdAt: string;
  updatedAt: string;
}

export interface RecurrenceRule {
  type: 'Daily' | 'Weekly' | 'Monthly' | 'Yearly';
  interval: number;
  endDate?: string;
  daysOfWeek?: number[]; // 0-6 (Sunday-Saturday)
  dayOfMonth?: number;
  weekOfMonth?: number;
  monthOfYear?: number;
}

export interface BoardFilters {
  teams?: string[];
  priorities?: string[];
  equipmentCategories?: string[];
  assignedTechnicians?: string[];
  dateRange?: {
    start: string;
    end: string;
  };
  tags?: string[];
  showOverdueOnly?: boolean;
  showMyRequestsOnly?: boolean;
}

export interface KanbanUpdate {
  requestId: string;
  fromColumn: string;
  toColumn: string;
  newIndex: number;
  updatedBy: string;
  timestamp: string;
  reason?: string;
}
```

**Frontend Component:**
```typescript
// components/kanban/KanbanBoard.tsx
import { useState, useEffect, useCallback } from 'react';
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Filter, 
  Search, 
  Users, 
  Calendar,
  AlertTriangle,
  Clock,
  CheckCircle,
  Trash2,
  Settings
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { KanbanColumn } from './KanbanColumn';
import { RequestCard } from './RequestCard';
import { useWebSocket } from '@/hooks/useWebSocket';
import { KanbanBoard as KanbanBoardType, RequestCard as RequestCardType, KanbanUpdate } from '@/types/kanban';

interface KanbanBoardProps {
  initialBoard: KanbanBoardType;
  onRequestUpdate?: (update: KanbanUpdate) => void;
}

export const KanbanBoard = ({ initialBoard, onRequestUpdate }: KanbanBoardProps) => {
  const [board, setBoard] = useState<KanbanBoardType>(initialBoard);
  const [activeCard, setActiveCard] = useState<RequestCardType | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTeam, setSelectedTeam] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [showOverdueOnly, setShowOverdueOnly] = useState(false);

  // WebSocket for real-time updates
  const { isConnected, sendMessage } = useWebSocket('/kanban', {
    onMessage: handleWebSocketMessage
  });

  const handleWebSocketMessage = useCallback((message: any) => {
    if (message.type === 'KANBAN_UPDATE') {
      const update: KanbanUpdate = message.data;
      updateBoardFromWebSocket(update);
    }
  }, []);

  const updateBoardFromWebSocket = (update: KanbanUpdate) => {
    setBoard(prevBoard => {
      const newBoard = { ...prevBoard };
      
      // Find and move the request
      let movedRequest: RequestCardType | null = null;
      
      // Remove from source column
      newBoard.columns = newBoard.columns.map(column => {
        if (column.status === update.fromColumn) {
          const requestIndex = column.requests.findIndex(r => r.id === update.requestId);
          if (requestIndex !== -1) {
            movedRequest = column.requests[requestIndex];
            return {
              ...column,
              requests: column.requests.filter(r => r.id !== update.requestId)
            };
          }
        }
        return column;
      });

      // Add to destination column
      if (movedRequest) {
        newBoard.columns = newBoard.columns.map(column => {
          if (column.status === update.toColumn) {
            const newRequests = [...column.requests];
            newRequests.splice(update.newIndex, 0, movedRequest!);
            return {
              ...column,
              requests: newRequests
            };
          }
          return column;
        });
      }

      return newBoard;
    });

    toast.success(`Request moved to ${update.toColumn} by ${update.updatedBy}`);
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const activeRequest = findRequestById(active.id as string);
    setActiveCard(activeRequest);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveCard(null);

    if (!over) return;

    const requestId = active.id as string;
    const newColumnId = over.id as string;
    
    const activeRequest = findRequestById(requestId);
    const currentColumn = findColumnByRequestId(requestId);
    const targetColumn = board.columns.find(col => col.id === newColumnId);

    if (!activeRequest || !currentColumn || !targetColumn || currentColumn.id === targetColumn.id) {
      return;
    }

    // Validate transition
    if (!isValidTransition(currentColumn.status, targetColumn.status)) {
      toast.error(`Cannot move request from ${currentColumn.title} to ${targetColumn.title}`);
      return;
    }

    // Optimistic update
    const update: KanbanUpdate = {
      requestId,
      fromColumn: currentColumn.status,
      toColumn: targetColumn.status,
      newIndex: 0, // Simplified - would calculate actual index
      updatedBy: 'Current User', // Would get from auth context
      timestamp: new Date().toISOString()
    };

    updateBoardLocally(update);

    try {
      // Send to backend
      const response = await fetch(`/api/kanban/requests/${requestId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          newStatus: targetColumn.status,
          previousStatus: currentColumn.status,
          reason: 'Kanban drag and drop'
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update request status');
      }

      // Broadcast to other users via WebSocket
      if (isConnected) {
        sendMessage({
          type: 'KANBAN_UPDATE',
          data: update
        });
      }

      onRequestUpdate?.(update);
      toast.success(`Request moved to ${targetColumn.title}`);
    } catch (error) {
      // Rollback optimistic update
      const rollbackUpdate: KanbanUpdate = {
        requestId,
        fromColumn: targetColumn.status,
        toColumn: currentColumn.status,
        newIndex: 0,
        updatedBy: 'System',
        timestamp: new Date().toISOString()
      };
      updateBoardLocally(rollbackUpdate);
      
      toast.error('Failed to update request status');
      console.error('Kanban update error:', error);
    }
  };

  const updateBoardLocally = (update: KanbanUpdate) => {
    setBoard(prevBoard => {
      const newBoard = { ...prevBoard };
      let movedRequest: RequestCardType | null = null;

      // Remove from source
      newBoard.columns = newBoard.columns.map(column => {
        if (column.status === update.fromColumn) {
          const requestIndex = column.requests.findIndex(r => r.id === update.requestId);
          if (requestIndex !== -1) {
            movedRequest = column.requests[requestIndex];
            return {
              ...column,
              requests: column.requests.filter(r => r.id !== update.requestId)
            };
          }
        }
        return column;
      });

      // Add to destination
      if (movedRequest) {
        newBoard.columns = newBoard.columns.map(column => {
          if (column.status === update.toColumn) {
            return {
              ...column,
              requests: [...column.requests, movedRequest!]
            };
          }
          return column;
        });
      }

      return newBoard;
    });
  };

  const findRequestById = (id: string): RequestCardType | null => {
    for (const column of board.columns) {
      const request = column.requests.find(r => r.id === id);
      if (request) return request;
    }
    return null;
  };

  const findColumnByRequestId = (requestId: string) => {
    return board.columns.find(column => 
      column.requests.some(request => request.id === requestId)
    );
  };

  const isValidTransition = (fromStatus: string, toStatus: string): boolean => {
    const allowedTransitions = board.rules.allowedTransitions[fromStatus] || [];
    return allowedTransitions.includes(toStatus);
  };

  const getFilteredRequests = (requests: RequestCardType[]): RequestCardType[] => {
    return requests.filter(request => {
      // Search filter
      if (searchTerm && !request.subject.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !request.equipmentName.toLowerCase().includes(searchTerm.toLowerCase())) {
        return false;
      }

      // Team filter
      if (selectedTeam !== 'all' && request.assignedTeam !== selectedTeam) {
        return false;
      }

      // Priority filter
      if (selectedPriority !== 'all' && request.priority !== selectedPriority) {
        return false;
      }

      // Overdue filter
      if (showOverdueOnly && !request.isOverdue) {
        return false;
      }

      return true;
    });
  };

  const getColumnStats = (column: KanbanColumn) => {
    const filteredRequests = getFilteredRequests(column.requests);
    const overdueCount = filteredRequests.filter(r => r.isOverdue).length;
    const highPriorityCount = filteredRequests.filter(r => r.priority === 'High' || r.priority === 'Critical').length;
    
    return { total: filteredRequests.length, overdue: overdueCount, highPriority: highPriorityCount };
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-500';
      case 'High': return 'bg-orange-500';
      case 'Medium': return 'bg-yellow-500';
      case 'Low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header with filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Maintenance Kanban Board
              {isConnected && (
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  Live
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                Calendar View
              </Button>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex items-center gap-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search requests..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
            </div>

            <Select value={selectedTeam} onValueChange={setSelectedTeam}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Teams" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Teams</SelectItem>
                <SelectItem value="Mechanics">Mechanics</SelectItem>
                <SelectItem value="Electricians">Electricians</SelectItem>
                <SelectItem value="IT Support">IT Support</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedPriority} onValueChange={setSelectedPriority}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Priorities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant={showOverdueOnly ? "default" : "outline"}
              size="sm"
              onClick={() => setShowOverdueOnly(!showOverdueOnly)}
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              Overdue Only
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Kanban Board */}
      <div className="flex-1 overflow-hidden">
        <DndContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
          <div className="grid grid-cols-4 gap-6 h-full">
            {board.columns.map((column) => {
              const stats = getColumnStats(column);
              const filteredRequests = getFilteredRequests(column.requests);
              
              return (
                <div key={column.id} className="flex flex-col h-full">
                  <Card className="mb-4">
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div 
                            className={`w-3 h-3 rounded-full`}
                            style={{ backgroundColor: column.color }}
                          />
                          {column.title}
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">{stats.total}</Badge>
                          {stats.overdue > 0 && (
                            <Badge variant="destructive" className="text-xs">
                              {stats.overdue} overdue
                            </Badge>
                          )}
                        </div>
                      </CardTitle>
                    </CardHeader>
                  </Card>

                  <SortableContext items={filteredRequests.map(r => r.id)} strategy={verticalListSortingStrategy}>
                    <KanbanColumn
                      column={{ ...column, requests: filteredRequests }}
                      onRequestClick={(request) => {
                        // Handle request click - open details modal
                        console.log('Request clicked:', request);
                      }}
                    />
                  </SortableContext>
                </div>
              );
            })}
          </div>

          <DragOverlay>
            {activeCard ? (
              <RequestCard 
                request={activeCard} 
                isDragging={true}
                onClick={() => {}}
              />
            ) : null}
          </DragOverlay>
        </DndContext>
      </div>
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/KanbanService.ts - Create new service
export class KanbanService {
  async getKanbanBoard(filters?: BoardFilters): Promise<KanbanBoard> {
    try {
      // Get all requests with their current status
      const requests = await this.getAllRequests(filters);
      
      // Get board configuration
      const boardConfig = await this.getBoardConfiguration();
      
      // Organize requests by status into columns
      const columns = this.organizeRequestsIntoColumns(requests, boardConfig.columns);
      
      return {
        id: 'main-board',
        name: 'Maintenance Requests',
        columns,
        rules: boardConfig.rules,
        filters: filters || {},
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Failed to get Kanban board:', error);
      throw new Error(`Failed to load Kanban board: ${error.message}`);
    }
  }

  async updateRequestStatus(
    requestId: string, 
    newStatus: string, 
    previousStatus: string,
    updatedBy: string,
    reason?: string
  ): Promise<void> {
    try {
      // Validate transition
      const isValid = await this.validateStatusTransition(previousStatus, newStatus);
      if (!isValid) {
        throw new Error(`Invalid status transition from ${previousStatus} to ${newStatus}`);
      }

      // Update request status in database
      await dynamodb.update(
        { PK: `REQUEST#${requestId}`, SK: 'DETAILS' },
        {
          status: newStatus,
          updatedAt: new Date().toISOString(),
          updatedBy,
          ...(newStatus === 'In Progress' && { startedAt: new Date().toISOString() }),
          ...(newStatus === 'Repaired' && { completedAt: new Date().toISOString() })
        }
      );

      // Log status change
      await this.logStatusChange(requestId, previousStatus, newStatus, updatedBy, reason);

      // Trigger any automation rules
      await this.processAutomationRules(requestId, newStatus);

      // Send notifications if required
      await this.sendStatusChangeNotifications(requestId, newStatus, updatedBy);

    } catch (error) {
      console.error('Failed to update request status:', error);
      throw new Error(`Failed to update status: ${error.message}`);
    }
  }

  private async getAllRequests(filters?: BoardFilters): Promise<RequestCardType[]> {
    // Query all requests with filters
    let queryParams: any = {
      FilterExpression: 'begins_with(PK, :pk)',
      ExpressionAttributeValues: { ':pk': 'REQUEST#' }
    };

    // Apply filters
    if (filters?.teams?.length) {
      queryParams.FilterExpression += ' AND assignedTeam IN (:teams)';
      queryParams.ExpressionAttributeValues[':teams'] = filters.teams;
    }

    if (filters?.priorities?.length) {
      queryParams.FilterExpression += ' AND priority IN (:priorities)';
      queryParams.ExpressionAttributeValues[':priorities'] = filters.priorities;
    }

    if (filters?.dateRange) {
      queryParams.FilterExpression += ' AND createdAt BETWEEN :startDate AND :endDate';
      queryParams.ExpressionAttributeValues[':startDate'] = filters.dateRange.start;
      queryParams.ExpressionAttributeValues[':endDate'] = filters.dateRange.end;
    }

    const result = await dynamodb.scan(queryParams);
    
    return (result.Items || []).map(item => this.mapToRequestCard(item));
  }

  private mapToRequestCard(item: any): RequestCardType {
    const now = new Date();
    const dueDate = item.scheduledDate ? new Date(item.scheduledDate) : null;
    const isOverdue = dueDate ? now > dueDate && item.status !== 'Repaired' : false;

    return {
      id: item.PK.replace('REQUEST#', ''),
      subject: item.subject,
      description: item.description,
      equipmentName: item.equipmentName,
      equipmentCategory: item.equipmentCategory || 'Unknown',
      priority: item.priority,
      assignedTechnician: item.assignedTechnician ? {
        id: item.assignedTechnician,
        name: item.assignedTechnicianName || 'Unknown',
        avatar: item.assignedTechnicianAvatar
      } : undefined,
      assignedTeam: item.assignedTeam,
      createdAt: item.createdAt,
      updatedAt: item.updatedAt,
      dueDate: item.scheduledDate,
      estimatedHours: item.estimatedHours,
      actualHours: item.hoursSpent,
      tags: item.tags || [],
      isOverdue,
      healthScore: item.equipmentHealthScore,
      lastActivity: item.updatedAt
    };
  }

  private organizeRequestsIntoColumns(requests: RequestCardType[], columnConfigs: any[]): KanbanColumn[] {
    return columnConfigs.map(config => ({
      id: config.id,
      title: config.title,
      status: config.status,
      color: config.color,
      order: config.order,
      requests: requests.filter(request => request.status === config.status),
      limits: config.limits,
      automationRules: config.automationRules || []
    }));
  }

  private async getBoardConfiguration(): Promise<{ columns: any[]; rules: WorkflowRules }> {
    // Default board configuration
    return {
      columns: [
        {
          id: 'new',
          title: 'New',
          status: 'New',
          color: '#3b82f6',
          order: 1,
          limits: { max: 20, warnAt: 15 }
        },
        {
          id: 'in-progress',
          title: 'In Progress',
          status: 'In Progress',
          color: '#f59e0b',
          order: 2,
          limits: { max: 10, warnAt: 8 }
        },
        {
          id: 'repaired',
          title: 'Repaired',
          status: 'Repaired',
          color: '#10b981',
          order: 3
        },
        {
          id: 'scrap',
          title: 'Scrap',
          status: 'Scrap',
          color: '#ef4444',
          order: 4
        }
      ],
      rules: {
        allowedTransitions: {
          'New': ['In Progress', 'Scrap'],
          'In Progress': ['Repaired', 'Scrap', 'New'],
          'Repaired': [],
          'Scrap': []
        },
        autoTransitions: [],
        validationRules: [],
        notificationRules: []
      }
    };
  }

  private async validateStatusTransition(fromStatus: string, toStatus: string): Promise<boolean> {
    const config = await this.getBoardConfiguration();
    const allowedTransitions = config.rules.allowedTransitions[fromStatus] || [];
    return allowedTransitions.includes(toStatus);
  }

  private async logStatusChange(
    requestId: string, 
    fromStatus: string, 
    toStatus: string, 
    updatedBy: string, 
    reason?: string
  ): Promise<void> {
    await dynamodb.put({
      PK: `REQUEST#${requestId}`,
      SK: `STATUS_CHANGE#${Date.now()}`,
      fromStatus,
      toStatus,
      updatedBy,
      reason,
      timestamp: new Date().toISOString()
    });
  }

  private async processAutomationRules(requestId: string, newStatus: string): Promise<void> {
    // Process any automation rules for the new status
    // This could include auto-assignments, notifications, etc.
  }

  private async sendStatusChangeNotifications(
    requestId: string, 
    newStatus: string, 
    updatedBy: string
  ): Promise<void> {
    // Send notifications to relevant stakeholders
    // This could integrate with email, SMS, or push notifications
  }
}

export const kanbanService = new KanbanService();
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` and understand F01, F03, F04 integration patterns and WebSocket implementation.

### Step 1: Backend Implementation

1. Create KanbanService and CalendarService for data aggregation
2. Implement status transition validation and workflow rules
3. Add WebSocket integration for real-time updates
4. Create calendar event management with recurrence support

### Step 2: Frontend Implementation

1. Implement drag-and-drop Kanban board with React DnD
2. Create calendar view with event scheduling
3. Add real-time updates via WebSocket connection
4. Implement filtering and search functionality

### Step 3: Integration

1. Connect Kanban board to request, equipment, and team data
2. Integrate calendar with preventive maintenance scheduling
3. Test real-time collaboration features
4. Verify workflow automation rules work correctly

## Acceptance Criteria

- [ ] Kanban board displays requests organized by status with drag-and-drop functionality
- [ ] Status transitions follow defined workflow rules and validate properly
- [ ] Calendar view shows preventive maintenance schedule with recurring events
- [ ] Real-time updates sync across multiple users via WebSocket
- [ ] Visual indicators show overdue requests, technician assignments, and priority levels
- [ ] **Demo Ready:** Can demonstrate Kanban workflow and calendar scheduling in 30 seconds
- [ ] **Integration Working:** Successfully aggregates data from F01, F03, and F04 modules
- [ ] **Real-time Collaboration:** Multiple users can work simultaneously with live updates
- [ ] **Workflow Management:** Complete request lifecycle management with visual progress
- [ ] **Mobile Responsive:** Optimized for tablet and mobile use by field technicians

## Testing Checklist

- [ ] **Drag & Drop:** Test Kanban card movement and status transitions
- [ ] **Real-time Updates:** Verify WebSocket synchronization across multiple browsers
- [ ] **Calendar Integration:** Test event creation, editing, and recurrence rules
- [ ] **Workflow Validation:** Test status transition rules and restrictions
- [ ] **Performance:** Test with large numbers of requests and events

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **WebSocket Config:** Configured WebSocket API for real-time updates
- [ ] **Integration Points:** Verified cross-module data aggregation works correctly
- [ ] **Performance Testing:** Confirmed board loads quickly with large datasets
- [ ] **Real-time Testing:** Verified WebSocket connections work in production environment