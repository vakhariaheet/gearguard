# Module F03: Maintenance Teams

## Overview

**Estimated Time:** 1hr

**Complexity:** Medium

**Type:** Full-stack

**Risk Level:** Low

**Dependencies:** None

## Problem Context

The system must support multiple specialized maintenance teams (Mechanics, Electricians, IT Support) with specific team members. When maintenance requests are created, they should be automatically assigned to the appropriate team based on equipment type, and only team members should be able to pick up requests assigned to their team.

## Technical Requirements

**Module Type:** Full-stack

### Backend Tasks

- [ ] **Handler Files:** Create CRUD handlers for team management
  - `handlers/listTeams.ts` - GET /api/teams
  - `handlers/getTeam.ts` - GET /api/teams/:id
  - `handlers/createTeam.ts` - POST /api/teams
  - `handlers/updateTeam.ts` - PUT /api/teams/:id
  - `handlers/deleteTeam.ts` - DELETE /api/teams/:id
  - `handlers/addTeamMember.ts` - POST /api/teams/:id/members
  - `handlers/removeTeamMember.ts` - DELETE /api/teams/:id/members/:userId

- [ ] **Function Configs:** Create serverless function configurations
  - `functions/listTeams.yml`
  - `functions/getTeam.yml`
  - `functions/createTeam.yml`
  - `functions/updateTeam.yml`
  - `functions/deleteTeam.yml`
  - `functions/addTeamMember.yml`
  - `functions/removeTeamMember.yml`

- [ ] **Service Layer:** Business logic in `services/TeamService.ts`
  - Team CRUD operations
  - Team member management
  - Skill and specialization tracking
  - Workload balancing logic

- [ ] **Type Definitions:** Add types to `types.ts`
  - Team entity with specializations
  - Team member relationships
  - Request/response types for API endpoints

- [ ] **RBAC Verification:** Module already configured in `config/permissions.ts`

- [ ] **AWS Service Integration:** Use `shared/clients/dynamodb` for data storage

### Frontend Tasks

- [ ] **Components:** Team management UI components
  - `components/teams/TeamList.tsx` - List view with shadcn table
  - `components/teams/TeamForm.tsx` - Create/edit team form
  - `components/teams/TeamCard.tsx` - Team card with member avatars
  - `components/teams/TeamMemberManager.tsx` - Add/remove team members
  - `components/teams/SkillBadges.tsx` - Display team specializations

- [ ] **Pages:** Team management pages
  - `pages/teams/TeamListPage.tsx` - Main teams list
  - `pages/teams/TeamCreatePage.tsx` - Create new team
  - `pages/teams/TeamEditPage.tsx` - Edit existing team
  - `pages/teams/TeamDetailsPage.tsx` - Team details with members

- [ ] **API Integration:** Team API service
  - `hooks/useTeams.ts` - React Query hooks for team operations
  - `services/teamsApi.ts` - API service functions

- [ ] **Routing:** Add team routes to React Router

### Database Schema (Single Table)

```
PK: TEAM#[id] | SK: DETAILS | GSI1PK: SPECIALIZATION#[type] | GSI1SK: TEAM#[id]
PK: TEAM#[id] | SK: MEMBER#[userId] | GSI1PK: USER#[userId] | GSI1SK: TEAM#[id]

Team Details Fields:
- teamName: string (required)
- specialization: string (Mechanics, Electricians, IT Support, General, etc.)
- description?: string
- skills: string[] (specific skills/certifications)
- maxCapacity?: number (maximum concurrent requests)
- isActive: boolean
- leadTechnician?: string (user ID)
- createdAt: string
- updatedAt: string

Team Member Fields:
- userId: string (Clerk user ID)
- role: 'Lead' | 'Senior' | 'Junior' | 'Trainee'
- joinedAt: string
- skills?: string[]
- certifications?: string[]
- isActive: boolean
```

## Enhancement Features

### Enhancement Feature: Smart Team Assignment

**Problem Solved:** Automatically suggest the best team for equipment based on equipment type, team specialization, current workload, and team member skills.

**Enhancement Type:** Smart Logic + AI - Uses intelligent algorithms and AI to optimize team assignments

**User Trigger:** "Suggest Team" button when creating maintenance requests or viewing equipment

**Input Requirements:**
- **Required Fields:** Equipment type/category, request urgency
- **Optional Fields:** Required skills, preferred team, location
- **Validation Rules:** Equipment must exist, urgency must be valid

**Processing Logic:**
1. **Equipment Analysis:** Analyze equipment type and required maintenance skills
2. **Team Matching:** Match equipment requirements with team specializations
3. **Workload Assessment:** Check current team workloads and availability
4. **AI Optimization:** Use AI to recommend optimal team assignment

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface Team {
  id: string;
  teamName: string;
  specialization: 'Mechanics' | 'Electricians' | 'IT Support' | 'HVAC' | 'General' | 'Facilities';
  description?: string;
  skills: string[];
  maxCapacity?: number;
  isActive: boolean;
  leadTechnician?: string;
  currentWorkload: number; // number of active requests
  members: TeamMember[];
  createdAt: string;
  updatedAt: string;
}

export interface TeamMember {
  userId: string;
  userName: string;
  email: string;
  role: 'Lead' | 'Senior' | 'Junior' | 'Trainee';
  joinedAt: string;
  skills?: string[];
  certifications?: string[];
  isActive: boolean;
  currentRequests: number;
}

export interface TeamAssignmentRequest {
  equipmentId: string;
  equipmentCategory: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  requiredSkills?: string[];
  preferredTeam?: string;
  location?: string;
  description?: string;
}

export interface TeamAssignmentResponse {
  recommendedTeam: Team;
  alternativeTeams: Team[];
  confidence: number;
  reasoning: string[];
  estimatedResponseTime: number; // in hours
  workloadImpact: 'Low' | 'Medium' | 'High';
  skillMatch: number; // 0-100 percentage
}
```

**Frontend Component:**
```typescript
// components/teams/TeamAssignmentSuggestion.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Users, Clock, Target, TrendingUp } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { Team, TeamAssignmentResponse } from '@/types/teams';

interface TeamAssignmentSuggestionProps {
  equipmentId: string;
  equipmentCategory: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  onTeamSelected?: (team: Team) => void;
}

export const TeamAssignmentSuggestion = ({
  equipmentId,
  equipmentCategory,
  urgency,
  onTeamSelected
}: TeamAssignmentSuggestionProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<TeamAssignmentResponse | null>(null);

  const handleGetSuggestion = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/teams/suggest-assignment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          equipmentId,
          equipmentCategory,
          urgency,
          requiredSkills: getRequiredSkillsForCategory(equipmentCategory)
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Team suggestion failed');
      }

      const data = await response.json();
      setSuggestion(data.data);
      toast.success('Team suggestion generated');
    } catch (error) {
      console.error('Team suggestion error:', error);
      toast.error(error.message || 'Failed to get team suggestion');
    } finally {
      setIsLoading(false);
    }
  };

  const getRequiredSkillsForCategory = (category: string): string[] => {
    const skillMap: Record<string, string[]> = {
      'Machine': ['Mechanical Repair', 'Hydraulics', 'Pneumatics'],
      'Vehicle': ['Automotive Repair', 'Engine Diagnostics', 'Electrical Systems'],
      'Computer': ['Hardware Troubleshooting', 'Network Configuration', 'Software Installation'],
      'HVAC': ['Climate Control', 'Refrigeration', 'Ductwork'],
      'Electrical': ['Electrical Wiring', 'Circuit Analysis', 'Safety Protocols']
    };
    return skillMap[category] || [];
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'Low': return 'bg-green-500';
      case 'Medium': return 'bg-yellow-500';
      case 'High': return 'bg-orange-500';
      case 'Critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getWorkloadColor = (impact: string) => {
    switch (impact) {
      case 'Low': return 'text-green-600';
      case 'Medium': return 'text-yellow-600';
      case 'High': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="team-assignment-section">
      <Button
        onClick={handleGetSuggestion}
        disabled={isLoading}
        variant="outline"
        size="sm"
        className="mb-4"
      >
        {isLoading ? 'Analyzing...' : 'Suggest Best Team'}
      </Button>

      {suggestion && (
        <div className="space-y-4">
          {/* Recommended Team */}
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Recommended Team
                </div>
                <Badge className="bg-primary">
                  {Math.round(suggestion.confidence * 100)}% Match
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">
                      {suggestion.recommendedTeam.teamName}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {suggestion.recommendedTeam.specialization}
                    </p>
                  </div>
                  <Button
                    onClick={() => onTeamSelected?.(suggestion.recommendedTeam)}
                    size="sm"
                  >
                    Select Team
                  </Button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-1">
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="text-sm font-medium">
                      {suggestion.recommendedTeam.members.length} Members
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-1">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="text-sm font-medium">
                      {suggestion.estimatedResponseTime}h Response
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-1">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className={`text-sm font-medium ${getWorkloadColor(suggestion.workloadImpact)}`}>
                      {suggestion.workloadImpact} Impact
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-sm font-medium">
                      {suggestion.skillMatch}% Skills
                    </div>
                    <Progress value={suggestion.skillMatch} className="h-1 mt-1" />
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-2">Why this team?</h4>
                  <ul className="text-sm space-y-1">
                    {suggestion.reasoning.map((reason, index) => (
                      <li key={index} className="flex items-start">
                        <span className="w-1 h-1 bg-current rounded-full mt-2 mr-2 flex-shrink-0" />
                        {reason}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-2">Team Skills</h4>
                  <div className="flex flex-wrap gap-1">
                    {suggestion.recommendedTeam.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Alternative Teams */}
          {suggestion.alternativeTeams.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Alternative Teams</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {suggestion.alternativeTeams.slice(0, 2).map((team, index) => (
                    <div key={team.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">{team.teamName}</div>
                        <div className="text-sm text-muted-foreground">
                          {team.specialization} • {team.members.length} members
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onTeamSelected?.(team)}
                      >
                        Select
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/TeamService.ts - Add this method
async suggestTeamAssignment(params: TeamAssignmentRequest): Promise<TeamAssignmentResponse> {
  try {
    // Get all active teams
    const teams = await this.listTeams({ isActive: true });
    
    if (teams.length === 0) {
      throw new Error('No active teams available');
    }

    // Calculate scores for each team
    const teamScores = await Promise.all(
      teams.map(async (team) => {
        const score = await this.calculateTeamScore(team, params);
        return { team, score };
      })
    );

    // Sort by score (highest first)
    teamScores.sort((a, b) => b.score.total - a.score.total);

    const bestTeam = teamScores[0];
    const alternativeTeams = teamScores.slice(1, 4).map(ts => ts.team);

    // Use AI to generate reasoning
    const aiPrompt = `Analyze team assignment for maintenance request:

Equipment: ${params.equipmentCategory}
Urgency: ${params.urgency}
Required Skills: ${params.requiredSkills?.join(', ') || 'None specified'}

Recommended Team: ${bestTeam.team.teamName}
- Specialization: ${bestTeam.team.specialization}
- Skills: ${bestTeam.team.skills.join(', ')}
- Current Workload: ${bestTeam.team.currentWorkload}/${bestTeam.team.maxCapacity || 10}
- Members: ${bestTeam.team.members.length}

Provide 3-4 specific reasons why this team is the best choice for this maintenance request.
Focus on skill match, availability, specialization alignment, and response time.`;

    const aiResponse = await geminiClient.generateJSON({
      prompt: aiPrompt,
      schema: {
        reasoning: 'array of strings',
        estimatedResponseTime: 'number',
        workloadImpact: 'string'
      }
    });

    // Calculate estimated response time based on urgency and workload
    const baseResponseTime = this.getBaseResponseTime(params.urgency);
    const workloadMultiplier = 1 + (bestTeam.team.currentWorkload / (bestTeam.team.maxCapacity || 10));
    const estimatedResponseTime = Math.round(baseResponseTime * workloadMultiplier);

    // Determine workload impact
    const workloadPercentage = bestTeam.team.currentWorkload / (bestTeam.team.maxCapacity || 10);
    let workloadImpact: 'Low' | 'Medium' | 'High';
    if (workloadPercentage < 0.5) workloadImpact = 'Low';
    else if (workloadPercentage < 0.8) workloadImpact = 'Medium';
    else workloadImpact = 'High';

    return {
      recommendedTeam: bestTeam.team,
      alternativeTeams,
      confidence: bestTeam.score.total / 100,
      reasoning: aiResponse.reasoning || [
        `Specializes in ${bestTeam.team.specialization} matching equipment type`,
        `Team has required skills: ${bestTeam.team.skills.slice(0, 2).join(', ')}`,
        `Current workload allows for timely response`,
        `${bestTeam.team.members.length} qualified team members available`
      ],
      estimatedResponseTime: aiResponse.estimatedResponseTime || estimatedResponseTime,
      workloadImpact: aiResponse.workloadImpact as any || workloadImpact,
      skillMatch: bestTeam.score.skillMatch
    };
  } catch (error) {
    console.error('Team assignment suggestion failed:', error);
    throw new Error(`Team suggestion failed: ${error.message}`);
  }
}

private async calculateTeamScore(team: Team, params: TeamAssignmentRequest): Promise<{
  total: number;
  specialization: number;
  skillMatch: number;
  availability: number;
  experience: number;
}> {
  // Specialization match (0-30 points)
  const specializationScore = this.getSpecializationScore(team.specialization, params.equipmentCategory);
  
  // Skill match (0-30 points)
  const skillScore = this.getSkillMatchScore(team.skills, params.requiredSkills || []);
  
  // Availability (0-25 points)
  const availabilityScore = this.getAvailabilityScore(team);
  
  // Experience (0-15 points)
  const experienceScore = this.getExperienceScore(team);
  
  const total = specializationScore + skillScore + availabilityScore + experienceScore;
  
  return {
    total,
    specialization: specializationScore,
    skillMatch: Math.round((skillScore / 30) * 100),
    availability: availabilityScore,
    experience: experienceScore
  };
}

private getSpecializationScore(teamSpec: string, equipmentCategory: string): number {
  const matches: Record<string, string[]> = {
    'Mechanics': ['Machine', 'Vehicle', 'Equipment'],
    'Electricians': ['Electrical', 'Computer', 'Electronics'],
    'IT Support': ['Computer', 'Network', 'Software'],
    'HVAC': ['HVAC', 'Climate', 'Ventilation'],
    'Facilities': ['Building', 'Infrastructure', 'General'],
    'General': ['Tool', 'Furniture', 'Miscellaneous']
  };
  
  const teamCategories = matches[teamSpec] || [];
  return teamCategories.includes(equipmentCategory) ? 30 : 10;
}

private getSkillMatchScore(teamSkills: string[], requiredSkills: string[]): number {
  if (requiredSkills.length === 0) return 20; // Default score if no specific skills required
  
  const matchCount = requiredSkills.filter(skill => 
    teamSkills.some(teamSkill => 
      teamSkill.toLowerCase().includes(skill.toLowerCase()) ||
      skill.toLowerCase().includes(teamSkill.toLowerCase())
    )
  ).length;
  
  return Math.round((matchCount / requiredSkills.length) * 30);
}

private getAvailabilityScore(team: Team): number {
  const maxCapacity = team.maxCapacity || 10;
  const utilizationRate = team.currentWorkload / maxCapacity;
  
  if (utilizationRate < 0.5) return 25; // Low utilization
  if (utilizationRate < 0.7) return 20; // Medium utilization
  if (utilizationRate < 0.9) return 15; // High utilization
  return 5; // Very high utilization
}

private getExperienceScore(team: Team): number {
  const seniorMembers = team.members.filter(m => 
    m.role === 'Lead' || m.role === 'Senior'
  ).length;
  
  const experienceRatio = seniorMembers / team.members.length;
  return Math.round(experienceRatio * 15);
}

private getBaseResponseTime(urgency: string): number {
  switch (urgency) {
    case 'Critical': return 1;
    case 'High': return 4;
    case 'Medium': return 8;
    case 'Low': return 24;
    default: return 8;
  }
}
```

**API Handler:**
```typescript
// handlers/suggestTeamAssignment.ts
import { APIGatewayProxyResultV2 } from 'aws-lambda';
import { AuthenticatedAPIGatewayEvent } from '../../../shared/types';
import { withRbac } from '../../../shared/auth/rbacMiddleware';
import { successResponse, errorResponse, handleAsyncError } from '../../../shared/response';
import { teamService } from '../services/TeamService';
import { TeamAssignmentRequest } from '../types';

/**
 * @route POST /api/teams/suggest-assignment
 * @description Suggest best team for equipment maintenance request
 */
const baseHandler = async (
  event: AuthenticatedAPIGatewayEvent
): Promise<APIGatewayProxyResultV2> => {
  try {
    // Parse request body
    const body: TeamAssignmentRequest = JSON.parse(event.body || '{}');

    // Validate required fields
    if (!body.equipmentId) {
      return errorResponse(400, 'MISSING_EQUIPMENT_ID', 'Equipment ID is required');
    }

    if (!body.equipmentCategory) {
      return errorResponse(400, 'MISSING_EQUIPMENT_CATEGORY', 'Equipment category is required');
    }

    if (!body.urgency) {
      return errorResponse(400, 'MISSING_URGENCY', 'Urgency level is required');
    }

    // Validate urgency level
    const validUrgencies = ['Low', 'Medium', 'High', 'Critical'];
    if (!validUrgencies.includes(body.urgency)) {
      return errorResponse(400, 'INVALID_URGENCY', `Urgency must be one of: ${validUrgencies.join(', ')}`);
    }

    // Get team suggestion
    const suggestion = await teamService.suggestTeamAssignment(body);

    return successResponse(suggestion);
  } catch (error) {
    return handleAsyncError(error);
  }
};

export const handler = withRbac(baseHandler, 'teams', 'read');
```

**Function Configuration:**
```yaml
# functions/suggestTeamAssignment.yml
suggestTeamAssignment:
  handler: src/modules/teams/handlers/suggestTeamAssignment.handler
  events:
    - httpApi:
        path: /api/teams/suggest-assignment
        method: post
        authorizer:
          name: clerkJwtAuthorizer
  environment:
    GEMINI_API_KEY: ${env:GEMINI_API_KEY}
  timeout: 30
  memorySize: 512
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` COMPLETELY before writing any code.

### Step 1: Backend Implementation (Lambda-Compatible)

1. Create handlers for team CRUD operations
2. Implement TeamService with member management
3. Add smart team assignment feature using AI
4. Configure serverless functions with proper RBAC

### Step 2: Frontend Implementation

1. Create team management components using shadcn/ui
2. Implement team assignment suggestion UI
3. Add team member management interface
4. Integrate with backend APIs using React Query

### Step 3: Integration

1. Add team routes to React Router
2. Test smart team assignment feature
3. Verify team member management works
4. Test RBAC permissions for different roles

## Acceptance Criteria

- [ ] Team CRUD operations work for managers and admins
- [ ] Team members can be added and removed from teams
- [ ] Smart team assignment suggests best team based on equipment and skills
- [ ] Teams have specializations and skill tracking
- [ ] Workload balancing considers current team capacity
- [ ] **Demo Ready:** Can demonstrate team management and smart assignment in 30 seconds
- [ ] **Full-Stack Working:** Frontend connects to backend, backend connects to database
- [ ] **Lambda Compatible:** Backend code works in serverless environment
- [ ] **Error Handling:** Graceful failure modes implemented
- [ ] **Mobile Responsive:** Works on mobile devices

## Testing Checklist

- [ ] **Manual API Testing:** Test with Postman/curl
- [ ] **Frontend Testing:** Manual testing in browser
- [ ] **Smart Assignment:** Test AI-powered team suggestion feature
- [ ] **RBAC Testing:** Verify permissions work for different roles
- [ ] **Integration:** End-to-end flow works as expected

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **Serverless Config:** Added function imports to serverless.yml
- [ ] **RBAC Config:** Verified permissions.ts includes teams module
- [ ] **Types:** Exported types from module's types.ts for frontend use
- [ ] **Testing:** Manual testing completed