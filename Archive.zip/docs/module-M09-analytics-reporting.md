# Module M09: Analytics & Reporting Dashboard

## Overview

**Estimated Time:** 2hr

**Complexity:** Complex

**Type:** Full-stack

**Risk Level:** Medium

**Dependencies:** All previous modules (F01, F02, F03, F04, M05, M06, M07, M08)

## Problem Context

Create a comprehensive analytics and reporting dashboard that provides insights into maintenance performance, equipment health trends, team productivity, cost analysis, and predictive analytics. This module aggregates data from all other modules to provide actionable business intelligence for maintenance operations.

## Technical Requirements

**Module Type:** Full-stack (Data aggregation and visualization)

### Backend Tasks

- [ ] **Analytics Handler Files:** Create handlers for analytics and reporting
  - `handlers/getMaintenanceAnalytics.ts` - GET /api/analytics/maintenance
  - `handlers/getEquipmentAnalytics.ts` - GET /api/analytics/equipment
  - `handlers/getTeamPerformance.ts` - GET /api/analytics/teams
  - `handlers/getCostAnalysis.ts` - GET /api/analytics/costs
  - `handlers/getPredictiveInsights.ts` - GET /api/analytics/predictions
  - `handlers/generateReport.ts` - POST /api/analytics/reports

- [ ] **Function Configs:** Create function configurations
  - `functions/getMaintenanceAnalytics.yml`
  - `functions/getEquipmentAnalytics.yml`
  - `functions/getTeamPerformance.yml`
  - `functions/getCostAnalysis.yml`
  - `functions/getPredictiveInsights.yml`
  - `functions/generateReport.yml`

- [ ] **Analytics Service Layer:** Create AnalyticsService for data aggregation
  - Cross-module data aggregation
  - Statistical calculations and trend analysis
  - Predictive analytics using AI
  - Report generation and export

- [ ] **Type Definitions:** Add analytics and reporting types
  - Analytics dashboard interfaces
  - Report generation types
  - Chart and visualization data structures

- [ ] **Data Aggregation:** Implement efficient data aggregation
  - Time-series data processing
  - Cross-module data correlation
  - Performance optimization with caching

### Frontend Tasks

- [ ] **Analytics Components:** Create comprehensive analytics dashboard
  - `components/analytics/MaintenanceMetrics.tsx` - Key performance indicators
  - `components/analytics/EquipmentHealthTrends.tsx` - Equipment analytics
  - `components/analytics/TeamPerformanceCharts.tsx` - Team productivity
  - `components/analytics/CostAnalysisDashboard.tsx` - Financial insights
  - `components/analytics/PredictiveInsights.tsx` - AI-powered predictions
  - `components/analytics/ReportGenerator.tsx` - Custom report builder

- [ ] **Visualization Components:** Create chart and graph components
  - `components/charts/LineChart.tsx` - Trend analysis
  - `components/charts/BarChart.tsx` - Comparative data
  - `components/charts/PieChart.tsx` - Distribution analysis
  - `components/charts/HeatMap.tsx` - Performance matrices
  - `components/charts/GaugeChart.tsx` - KPI indicators

- [ ] **Pages:** Analytics and reporting pages
  - `pages/analytics/AnalyticsDashboard.tsx` - Main analytics dashboard
  - `pages/analytics/ReportsPage.tsx` - Report generation and management
  - `pages/analytics/InsightsPage.tsx` - AI-powered insights and predictions

- [ ] **Data Visualization:** Implement charts using Recharts or similar
  - Interactive charts with drill-down capabilities
  - Real-time data updates
  - Export functionality for charts and reports

### Database Schema Extensions

```
PK: ANALYTICS#METRIC#[type] | SK: DATE#[date] | GSI1PK: METRIC_TYPE#[type] | GSI1SK: DATE#[date]
PK: ANALYTICS#REPORT#[id] | SK: DETAILS | GSI1PK: REPORT_TYPE#[type] | GSI1SK: CREATED#[date]
PK: ANALYTICS#CACHE#[key] | SK: DATA | GSI1PK: CACHE_TYPE#[type] | GSI1SK: EXPIRES#[timestamp]

Analytics Metrics:
- metricType: 'maintenance' | 'equipment' | 'team' | 'cost' | 'prediction'
- date: string (ISO date)
- value: number
- metadata: Record<string, any>
- aggregationLevel: 'daily' | 'weekly' | 'monthly' | 'yearly'
- calculatedAt: string

Report Configuration:
- reportType: 'maintenance' | 'equipment' | 'team' | 'cost' | 'custom'
- title: string
- description?: string
- parameters: Record<string, any>
- schedule?: {
  frequency: 'daily' | 'weekly' | 'monthly';
  recipients: string[];
  format: 'pdf' | 'excel' | 'csv';
}
- createdBy: string
- isPublic: boolean
```

## Enhancement Features

### Enhancement Feature: AI-Powered Predictive Insights

**Problem Solved:** Provide intelligent predictions and recommendations based on historical maintenance data, equipment performance trends, and operational patterns to enable proactive decision-making.

**Enhancement Type:** AI + Advanced Analytics - Uses Gemini AI with statistical analysis to generate actionable business insights

**User Trigger:** "Generate Insights" button on analytics dashboard or automatic daily/weekly analysis

**Input Requirements:**
- **Required Fields:** Time range for analysis, analysis type
- **Optional Fields:** Specific equipment/teams to focus on, prediction horizon
- **Validation Rules:** Sufficient historical data must be available (minimum 30 days)

**Processing Logic:**
1. **Data Aggregation:** Collect and correlate data from all modules
2. **Pattern Recognition:** Identify trends, anomalies, and correlations
3. **AI Analysis:** Use Gemini AI to generate insights and predictions
4. **Actionable Recommendations:** Provide specific, actionable recommendations

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface AnalyticsDashboard {
  timeRange: {
    start: string;
    end: string;
  };
  kpis: KeyPerformanceIndicators;
  trends: TrendAnalysis;
  insights: PredictiveInsights;
  alerts: AnalyticsAlert[];
  lastUpdated: string;
}

export interface KeyPerformanceIndicators {
  maintenance: {
    totalRequests: number;
    completedRequests: number;
    averageResponseTime: number; // hours
    averageResolutionTime: number; // hours
    slaComplianceRate: number; // percentage
    preventiveMaintenanceRate: number; // percentage
    emergencyRequestRate: number; // percentage
  };
  equipment: {
    totalEquipment: number;
    activeEquipment: number;
    averageHealthScore: number;
    equipmentAtRisk: number;
    predictedFailures: number;
    maintenanceCostPerUnit: number;
  };
  teams: {
    totalTechnicians: number;
    activeTechnicians: number;
    averageWorkload: number;
    teamEfficiencyScore: number;
    skillUtilizationRate: number;
  };
  costs: {
    totalMaintenanceCost: number;
    preventiveCost: number;
    emergencyRepairCost: number;
    costSavings: number;
    costPerRequest: number;
    budgetUtilization: number; // percentage
  };
}

export interface TrendAnalysis {
  requestVolume: ChartData[];
  responseTimeTrend: ChartData[];
  equipmentHealthTrend: ChartData[];
  teamPerformanceTrend: ChartData[];
  costTrend: ChartData[];
  slaComplianceTrend: ChartData[];
}

export interface ChartData {
  date: string;
  value: number;
  label?: string;
  category?: string;
  metadata?: Record<string, any>;
}

export interface PredictiveInsights {
  predictions: Prediction[];
  recommendations: Recommendation[];
  riskAssessment: RiskAssessment;
  opportunityAnalysis: OpportunityAnalysis;
  confidence: number;
  generatedAt: string;
}

export interface Prediction {
  id: string;
  type: 'EquipmentFailure' | 'MaintenanceDemand' | 'CostProjection' | 'ResourceNeeds';
  title: string;
  description: string;
  predictedDate?: string;
  probability: number; // 0-1
  impact: 'Low' | 'Medium' | 'High' | 'Critical';
  affectedAssets: string[];
  confidence: number;
  timeHorizon: number; // days
}

export interface Recommendation {
  id: string;
  category: 'Maintenance' | 'Equipment' | 'Team' | 'Cost' | 'Process';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  title: string;
  description: string;
  expectedBenefit: string;
  implementationEffort: 'Low' | 'Medium' | 'High';
  estimatedSavings?: number;
  timeToImplement?: number; // days
  actionItems: string[];
}

export interface RiskAssessment {
  overallRiskScore: number; // 0-100
  riskFactors: Array<{
    factor: string;
    score: number;
    impact: string;
    mitigation: string;
  }>;
  criticalEquipment: string[];
  resourceConstraints: string[];
  upcomingChallenges: string[];
}

export interface OpportunityAnalysis {
  costOptimization: Array<{
    opportunity: string;
    potentialSavings: number;
    effort: string;
  }>;
  efficiencyImprovements: Array<{
    area: string;
    currentPerformance: number;
    potentialImprovement: number;
    actions: string[];
  }>;
  preventiveMaintenanceOpportunities: Array<{
    equipmentId: string;
    equipmentName: string;
    riskReduction: number;
    costBenefit: number;
  }>;
}

export interface AnalyticsAlert {
  id: string;
  type: 'Warning' | 'Critical' | 'Info' | 'Success';
  title: string;
  message: string;
  severity: number; // 1-10
  category: 'Performance' | 'Cost' | 'Equipment' | 'Team' | 'SLA';
  createdAt: string;
  acknowledged: boolean;
  actionRequired: boolean;
  relatedData?: any;
}

export interface ReportConfiguration {
  id: string;
  name: string;
  description?: string;
  reportType: 'maintenance' | 'equipment' | 'team' | 'cost' | 'custom';
  parameters: {
    timeRange: { start: string; end: string };
    includeCharts: boolean;
    includePredictions: boolean;
    includeRecommendations: boolean;
    filterBy?: {
      teams?: string[];
      equipmentCategories?: string[];
      priorities?: string[];
    };
  };
  schedule?: {
    frequency: 'daily' | 'weekly' | 'monthly';
    dayOfWeek?: number;
    dayOfMonth?: number;
    time: string; // HH:MM format
    recipients: string[];
    format: 'pdf' | 'excel' | 'csv';
  };
  createdBy: string;
  createdAt: string;
  lastGenerated?: string;
  isActive: boolean;
}
```

**Frontend Component:**
```typescript
// components/analytics/PredictiveInsights.tsx
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Target,
  DollarSign,
  Clock,
  Lightbulb,
  Shield,
  Zap
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { PredictiveInsights as PredictiveInsightsType, Prediction, Recommendation } from '@/types/analytics';

interface PredictiveInsightsProps {
  timeRange: { start: string; end: string };
  onInsightsGenerated?: (insights: PredictiveInsightsType) => void;
}

export const PredictiveInsights = ({ timeRange, onInsightsGenerated }: PredictiveInsightsProps) => {
  const [insights, setInsights] = useState<PredictiveInsightsType | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    generateInsights();
  }, [timeRange]);

  const generateInsights = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/analytics/predictions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          timeRange,
          analysisType: 'comprehensive',
          includeRecommendations: true,
          predictionHorizon: 90 // days
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Failed to generate insights');
      }

      const data = await response.json();
      setInsights(data.data);
      onInsightsGenerated?.(data.data);
      toast.success('Predictive insights generated successfully');
    } catch (error) {
      console.error('Insights generation error:', error);
      toast.error(error.message || 'Failed to generate insights');
    } finally {
      setIsGenerating(false);
    }
  };

  const getPredictionIcon = (type: string) => {
    switch (type) {
      case 'EquipmentFailure': return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'MaintenanceDemand': return <Clock className="h-5 w-5 text-blue-500" />;
      case 'CostProjection': return <DollarSign className="h-5 w-5 text-green-500" />;
      case 'ResourceNeeds': return <Target className="h-5 w-5 text-purple-500" />;
      default: return <Brain className="h-5 w-5 text-gray-500" />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'Critical': return 'bg-red-500';
      case 'High': return 'bg-orange-500';
      case 'Medium': return 'bg-yellow-500';
      case 'Low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'text-red-600 border-red-200 bg-red-50';
      case 'High': return 'text-orange-600 border-orange-200 bg-orange-50';
      case 'Medium': return 'text-yellow-600 border-yellow-200 bg-yellow-50';
      case 'Low': return 'text-green-600 border-green-200 bg-green-50';
      default: return 'text-gray-600 border-gray-200 bg-gray-50';
    }
  };

  const getEffortColor = (effort: string) => {
    switch (effort) {
      case 'Low': return 'text-green-600';
      case 'Medium': return 'text-yellow-600';
      case 'High': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const filteredRecommendations = insights?.recommendations.filter(rec => 
    selectedCategory === 'all' || rec.category.toLowerCase() === selectedCategory.toLowerCase()
  ) || [];

  if (isGenerating) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <div className="text-lg font-medium mb-2">Generating AI Insights</div>
          <div className="text-sm text-muted-foreground">
            Analyzing maintenance data, equipment performance, and operational patterns...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!insights) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <div className="text-lg font-medium mb-2">No Insights Available</div>
          <div className="text-sm text-muted-foreground mb-4">
            Generate AI-powered insights to get predictive analytics and recommendations
          </div>
          <Button onClick={generateInsights}>
            Generate Insights
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with confidence score */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-500" />
              AI-Powered Predictive Insights
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary">
                {Math.round(insights.confidence * 100)}% Confidence
              </Badge>
              <Button variant="outline" size="sm" onClick={generateInsights}>
                Refresh Insights
              </Button>
            </div>
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Generated {new Date(insights.generatedAt).toLocaleString()}
          </p>
        </CardHeader>
      </Card>

      <Tabs defaultValue="predictions" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="risks">Risk Assessment</TabsTrigger>
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
        </TabsList>

        <TabsContent value="predictions" className="space-y-4">
          <div className="grid gap-4">
            {insights.predictions.map((prediction) => (
              <Card key={prediction.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      {getPredictionIcon(prediction.type)}
                      <div>
                        <div className="font-medium">{prediction.title}</div>
                        <div className="text-sm text-muted-foreground">
                          {prediction.description}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={getImpactColor(prediction.impact)}>
                        {prediction.impact} Impact
                      </Badge>
                      <div className="text-xs text-muted-foreground mt-1">
                        {Math.round(prediction.probability * 100)}% probability
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                    <div className="text-center">
                      <div className="text-sm font-medium">Confidence</div>
                      <Progress value={prediction.confidence * 100} className="h-2 mt-1" />
                      <div className="text-xs text-muted-foreground">
                        {Math.round(prediction.confidence * 100)}%
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-sm font-medium">Time Horizon</div>
                      <div className="text-lg font-bold text-blue-600">
                        {prediction.timeHorizon}
                      </div>
                      <div className="text-xs text-muted-foreground">days</div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-sm font-medium">Affected Assets</div>
                      <div className="text-lg font-bold text-orange-600">
                        {prediction.affectedAssets.length}
                      </div>
                      <div className="text-xs text-muted-foreground">equipment</div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-sm font-medium">Predicted Date</div>
                      <div className="text-sm font-bold">
                        {prediction.predictedDate 
                          ? new Date(prediction.predictedDate).toLocaleDateString()
                          : 'TBD'
                        }
                      </div>
                    </div>
                  </div>

                  {prediction.affectedAssets.length > 0 && (
                    <div>
                      <div className="text-sm font-medium mb-2">Affected Equipment:</div>
                      <div className="flex flex-wrap gap-1">
                        {prediction.affectedAssets.slice(0, 5).map((asset, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {asset}
                          </Badge>
                        ))}
                        {prediction.affectedAssets.length > 5 && (
                          <Badge variant="outline" className="text-xs">
                            +{prediction.affectedAssets.length - 5} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <div className="flex gap-2 mb-4">
            <Button
              variant={selectedCategory === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('all')}
            >
              All Categories
            </Button>
            {['Maintenance', 'Equipment', 'Team', 'Cost', 'Process'].map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>

          <div className="grid gap-4">
            {filteredRecommendations.map((recommendation) => (
              <Card key={recommendation.id} className={`border ${getPriorityColor(recommendation.priority)}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Lightbulb className="h-5 w-5 text-yellow-500" />
                      <div>
                        <div className="font-medium">{recommendation.title}</div>
                        <div className="text-sm text-muted-foreground">
                          {recommendation.description}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className={getPriorityColor(recommendation.priority)}>
                        {recommendation.priority} Priority
                      </Badge>
                      <div className="text-xs text-muted-foreground mt-1">
                        {recommendation.category}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                    <div className="text-center">
                      <div className="text-sm font-medium">Expected Benefit</div>
                      <div className="text-sm text-green-600 font-medium">
                        {recommendation.expectedBenefit}
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-sm font-medium">Implementation</div>
                      <div className={`text-sm font-medium ${getEffortColor(recommendation.implementationEffort)}`}>
                        {recommendation.implementationEffort} Effort
                      </div>
                    </div>
                    
                    {recommendation.estimatedSavings && (
                      <div className="text-center">
                        <div className="text-sm font-medium">Est. Savings</div>
                        <div className="text-sm font-bold text-green-600">
                          ${recommendation.estimatedSavings.toLocaleString()}
                        </div>
                      </div>
                    )}
                    
                    {recommendation.timeToImplement && (
                      <div className="text-center">
                        <div className="text-sm font-medium">Timeline</div>
                        <div className="text-sm font-bold">
                          {recommendation.timeToImplement} days
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="text-sm font-medium mb-2">Action Items:</div>
                    <ul className="space-y-1">
                      {recommendation.actionItems.map((item, index) => (
                        <li key={index} className="text-sm flex items-start">
                          <span className="w-1 h-1 bg-current rounded-full mt-2 mr-2 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="risks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-red-500" />
                Overall Risk Assessment
                <Badge className={
                  insights.riskAssessment.overallRiskScore > 70 ? 'bg-red-500' :
                  insights.riskAssessment.overallRiskScore > 40 ? 'bg-yellow-500' : 'bg-green-500'
                }>
                  {insights.riskAssessment.overallRiskScore}/100
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Progress value={insights.riskAssessment.overallRiskScore} className="h-3 mb-4" />
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-medium mb-3">Risk Factors</h4>
                  <div className="space-y-3">
                    {insights.riskAssessment.riskFactors.map((factor, index) => (
                      <div key={index} className="p-3 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{factor.factor}</span>
                          <Badge variant={factor.score > 70 ? 'destructive' : factor.score > 40 ? 'secondary' : 'outline'}>
                            {factor.score}/100
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground mb-2">{factor.impact}</div>
                        <div className="text-sm">
                          <span className="font-medium">Mitigation:</span> {factor.mitigation}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-3">Critical Equipment</h4>
                  <div className="space-y-2 mb-4">
                    {insights.riskAssessment.criticalEquipment.map((equipment, index) => (
                      <Badge key={index} variant="destructive" className="mr-2">
                        {equipment}
                      </Badge>
                    ))}
                  </div>

                  <h4 className="text-sm font-medium mb-3">Resource Constraints</h4>
                  <ul className="space-y-1 mb-4">
                    {insights.riskAssessment.resourceConstraints.map((constraint, index) => (
                      <li key={index} className="text-sm flex items-start">
                        <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5 mr-2 flex-shrink-0" />
                        {constraint}
                      </li>
                    ))}
                  </ul>

                  <h4 className="text-sm font-medium mb-3">Upcoming Challenges</h4>
                  <ul className="space-y-1">
                    {insights.riskAssessment.upcomingChallenges.map((challenge, index) => (
                      <li key={index} className="text-sm flex items-start">
                        <Clock className="h-4 w-4 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                        {challenge}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="opportunities" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-500" />
                  Cost Optimization
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {insights.opportunityAnalysis.costOptimization.map((opportunity, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{opportunity.opportunity}</span>
                        <Badge variant="secondary" className="text-green-600">
                          ${opportunity.potentialSavings.toLocaleString()}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Effort: {opportunity.effort}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                  Efficiency Improvements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {insights.opportunityAnalysis.efficiencyImprovements.map((improvement, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{improvement.area}</span>
                        <Badge variant="secondary" className="text-blue-600">
                          +{improvement.potentialImprovement}%
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">
                        Current: {improvement.currentPerformance}%
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">Actions:</span>
                        <ul className="mt-1 space-y-1">
                          {improvement.actions.map((action, actionIndex) => (
                            <li key={actionIndex} className="flex items-start">
                              <span className="w-1 h-1 bg-current rounded-full mt-2 mr-2 flex-shrink-0" />
                              {action}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-purple-500" />
                Preventive Maintenance Opportunities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {insights.opportunityAnalysis.preventiveMaintenanceOpportunities.map((opportunity, index) => (
                  <Card key={index} className="border-purple-200">
                    <CardContent className="p-4">
                      <div className="font-medium mb-2">{opportunity.equipmentName}</div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="text-muted-foreground">Risk Reduction:</span>
                          <div className="font-bold text-green-600">
                            {opportunity.riskReduction}%
                          </div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Cost Benefit:</span>
                          <div className="font-bold text-blue-600">
                            ${opportunity.costBenefit.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/AnalyticsService.ts - Create new service
export class AnalyticsService {
  async generatePredictiveInsights(params: {
    timeRange: { start: string; end: string };
    analysisType: 'quick' | 'comprehensive';
    includeRecommendations: boolean;
    predictionHorizon: number;
  }): Promise<PredictiveInsightsType> {
    try {
      // Aggregate data from all modules
      const [
        maintenanceData,
        equipmentData,
        teamData,
        costData
      ] = await Promise.all([
        this.getMaintenanceAnalytics(params.timeRange),
        this.getEquipmentAnalytics(params.timeRange),
        this.getTeamPerformance(params.timeRange),
        this.getCostAnalysis(params.timeRange)
      ]);

      // Generate AI-powered insights
      const aiPrompt = `Analyze comprehensive maintenance operations data and generate predictive insights:

MAINTENANCE METRICS:
- Total Requests: ${maintenanceData.totalRequests}
- Completion Rate: ${maintenanceData.completionRate}%
- Average Response Time: ${maintenanceData.averageResponseTime} hours
- SLA Compliance: ${maintenanceData.slaComplianceRate}%
- Emergency Rate: ${maintenanceData.emergencyRequestRate}%

EQUIPMENT HEALTH:
- Total Equipment: ${equipmentData.totalEquipment}
- Average Health Score: ${equipmentData.averageHealthScore}/100
- Equipment at Risk: ${equipmentData.equipmentAtRisk}
- Predicted Failures: ${equipmentData.predictedFailures}

TEAM PERFORMANCE:
- Active Technicians: ${teamData.activeTechnicians}
- Average Workload: ${teamData.averageWorkload}/10
- Team Efficiency: ${teamData.teamEfficiencyScore}%

COST ANALYSIS:
- Total Maintenance Cost: $${costData.totalMaintenanceCost.toLocaleString()}
- Preventive vs Emergency Ratio: ${costData.preventiveRatio}%
- Cost Savings: $${costData.costSavings.toLocaleString()}

ANALYSIS REQUIREMENTS:
- Prediction Horizon: ${params.predictionHorizon} days
- Analysis Type: ${params.analysisType}
- Include Recommendations: ${params.includeRecommendations}

Generate comprehensive predictive insights including:
1. Equipment failure predictions with probability and timeline
2. Maintenance demand forecasting
3. Cost projections and optimization opportunities
4. Resource planning recommendations
5. Risk assessment with mitigation strategies
6. Actionable recommendations with implementation priorities

Focus on actionable insights that can improve maintenance efficiency, reduce costs, and prevent equipment failures.`;

      const aiResponse = await geminiClient.generateJSON({
        prompt: aiPrompt,
        schema: {
          predictions: 'array of prediction objects',
          recommendations: 'array of recommendation objects',
          riskAssessment: 'risk assessment object',
          opportunityAnalysis: 'opportunity analysis object',
          confidence: 'number'
        }
      });

      // Process and structure the AI response
      const predictions = this.processPredictions(aiResponse.predictions, equipmentData);
      const recommendations = this.processRecommendations(aiResponse.recommendations);
      const riskAssessment = this.processRiskAssessment(aiResponse.riskAssessment, maintenanceData, equipmentData);
      const opportunityAnalysis = this.processOpportunityAnalysis(aiResponse.opportunityAnalysis, costData);

      return {
        predictions,
        recommendations,
        riskAssessment,
        opportunityAnalysis,
        confidence: aiResponse.confidence || 0.85,
        generatedAt: new Date().toISOString()
      };
    } catch (error) {
      console.error('Failed to generate predictive insights:', error);
      throw new Error(`Predictive insights generation failed: ${error.message}`);
    }
  }

  private processPredictions(aiPredictions: any[], equipmentData: any): Prediction[] {
    // Process AI predictions and add real data context
    const basePredictions: Prediction[] = [
      {
        id: 'pred-1',
        type: 'EquipmentFailure',
        title: 'High-Risk Equipment Failure Predicted',
        description: 'CNC Machine #1 showing declining performance metrics',
        predictedDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString(),
        probability: 0.78,
        impact: 'High',
        affectedAssets: ['CNC Machine #1', 'Production Line A'],
        confidence: 0.82,
        timeHorizon: 45
      },
      {
        id: 'pred-2',
        type: 'MaintenanceDemand',
        title: 'Increased Maintenance Demand Expected',
        description: 'Seasonal equipment usage patterns indicate 30% increase in requests',
        probability: 0.65,
        impact: 'Medium',
        affectedAssets: ['HVAC Systems', 'Cooling Equipment'],
        confidence: 0.75,
        timeHorizon: 30
      }
    ];

    // Merge with AI predictions if available
    return aiPredictions?.length > 0 ? 
      aiPredictions.map((pred, index) => ({
        id: `ai-pred-${index}`,
        type: pred.type || 'EquipmentFailure',
        title: pred.title || 'AI Prediction',
        description: pred.description || 'AI-generated prediction',
        predictedDate: pred.predictedDate,
        probability: pred.probability || 0.5,
        impact: pred.impact || 'Medium',
        affectedAssets: pred.affectedAssets || [],
        confidence: pred.confidence || 0.7,
        timeHorizon: pred.timeHorizon || 30
      })) : basePredictions;
  }

  private processRecommendations(aiRecommendations: any[]): Recommendation[] {
    const baseRecommendations: Recommendation[] = [
      {
        id: 'rec-1',
        category: 'Maintenance',
        priority: 'High',
        title: 'Implement Predictive Maintenance Program',
        description: 'Establish condition-based monitoring for critical equipment',
        expectedBenefit: '25% reduction in emergency repairs',
        implementationEffort: 'Medium',
        estimatedSavings: 45000,
        timeToImplement: 60,
        actionItems: [
          'Install IoT sensors on critical equipment',
          'Set up monitoring dashboard',
          'Train technicians on new procedures',
          'Establish maintenance schedules based on data'
        ]
      },
      {
        id: 'rec-2',
        category: 'Team',
        priority: 'Medium',
        title: 'Cross-Train Technicians',
        description: 'Increase team flexibility by cross-training on multiple equipment types',
        expectedBenefit: 'Improved response times and workload distribution',
        implementationEffort: 'Low',
        timeToImplement: 30,
        actionItems: [
          'Identify skill gaps across teams',
          'Develop cross-training curriculum',
          'Schedule training sessions',
          'Update technician skill profiles'
        ]
      }
    ];

    return aiRecommendations?.length > 0 ?
      aiRecommendations.map((rec, index) => ({
        id: `ai-rec-${index}`,
        category: rec.category || 'Maintenance',
        priority: rec.priority || 'Medium',
        title: rec.title || 'AI Recommendation',
        description: rec.description || 'AI-generated recommendation',
        expectedBenefit: rec.expectedBenefit || 'Operational improvement',
        implementationEffort: rec.implementationEffort || 'Medium',
        estimatedSavings: rec.estimatedSavings,
        timeToImplement: rec.timeToImplement,
        actionItems: rec.actionItems || ['Implement recommendation']
      })) : baseRecommendations;
  }

  private processRiskAssessment(aiRiskAssessment: any, maintenanceData: any, equipmentData: any): RiskAssessment {
    // Calculate overall risk score based on multiple factors
    const slaRisk = (100 - maintenanceData.slaComplianceRate) * 0.3;
    const equipmentRisk = (100 - equipmentData.averageHealthScore) * 0.4;
    const workloadRisk = Math.min(maintenanceData.averageWorkload * 10, 100) * 0.3;
    
    const overallRiskScore = Math.round(slaRisk + equipmentRisk + workloadRisk);

    return {
      overallRiskScore,
      riskFactors: [
        {
          factor: 'Equipment Health Decline',
          score: Math.round(equipmentRisk / 0.4),
          impact: 'Potential equipment failures and increased downtime',
          mitigation: 'Implement predictive maintenance and increase inspection frequency'
        },
        {
          factor: 'SLA Compliance Issues',
          score: Math.round(slaRisk / 0.3),
          impact: 'Customer satisfaction and operational efficiency concerns',
          mitigation: 'Optimize technician allocation and improve response procedures'
        },
        {
          factor: 'Resource Constraints',
          score: Math.round(workloadRisk / 0.3),
          impact: 'Delayed maintenance and potential service quality issues',
          mitigation: 'Consider additional staffing or workload redistribution'
        }
      ],
      criticalEquipment: equipmentData.criticalEquipment || ['CNC Machine #1', 'Main Compressor', 'Server Rack A'],
      resourceConstraints: [
        'Limited technician availability during peak hours',
        'Spare parts inventory running low for critical components',
        'Training gaps in emerging technologies'
      ],
      upcomingChallenges: [
        'Seasonal maintenance demand increase expected',
        'Equipment warranty expirations requiring budget planning',
        'New compliance requirements implementation'
      ]
    };
  }

  private processOpportunityAnalysis(aiOpportunityAnalysis: any, costData: any): OpportunityAnalysis {
    return {
      costOptimization: [
        {
          opportunity: 'Preventive Maintenance Expansion',
          potentialSavings: 35000,
          effort: 'Medium'
        },
        {
          opportunity: 'Inventory Optimization',
          potentialSavings: 18000,
          effort: 'Low'
        },
        {
          opportunity: 'Energy Efficiency Improvements',
          potentialSavings: 25000,
          effort: 'High'
        }
      ],
      efficiencyImprovements: [
        {
          area: 'Response Time',
          currentPerformance: 85,
          potentialImprovement: 15,
          actions: [
            'Implement mobile technician app',
            'Optimize routing algorithms',
            'Pre-position spare parts'
          ]
        },
        {
          area: 'First-Time Fix Rate',
          currentPerformance: 78,
          potentialImprovement: 12,
          actions: [
            'Improve diagnostic procedures',
            'Enhance technician training',
            'Better spare parts availability'
          ]
        }
      ],
      preventiveMaintenanceOpportunities: [
        {
          equipmentId: 'eq-1',
          equipmentName: 'CNC Machine #1',
          riskReduction: 45,
          costBenefit: 12000
        },
        {
          equipmentId: 'eq-2',
          equipmentName: 'Main Compressor',
          riskReduction: 35,
          costBenefit: 8500
        }
      ]
    };
  }

  private async getMaintenanceAnalytics(timeRange: { start: string; end: string }): Promise<any> {
    // Mock maintenance analytics - in real implementation would aggregate from requests
    return {
      totalRequests: 245,
      completionRate: 92,
      averageResponseTime: 2.3,
      slaComplianceRate: 87,
      emergencyRequestRate: 15,
      averageWorkload: 6.5
    };
  }

  private async getEquipmentAnalytics(timeRange: { start: string; end: string }): Promise<any> {
    // Mock equipment analytics - in real implementation would aggregate from equipment
    return {
      totalEquipment: 156,
      averageHealthScore: 82,
      equipmentAtRisk: 12,
      predictedFailures: 3,
      criticalEquipment: ['CNC Machine #1', 'Main Compressor', 'Server Rack A']
    };
  }

  private async getTeamPerformance(timeRange: { start: string; end: string }): Promise<any> {
    // Mock team performance - in real implementation would aggregate from teams
    return {
      activeTechnicians: 24,
      averageWorkload: 6.5,
      teamEfficiencyScore: 88
    };
  }

  private async getCostAnalysis(timeRange: { start: string; end: string }): Promise<any> {
    // Mock cost analysis - in real implementation would aggregate from requests and equipment
    return {
      totalMaintenanceCost: 125000,
      preventiveRatio: 65,
      costSavings: 35000
    };
  }
}

export const analyticsService = new AnalyticsService();
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` and understand all module integration patterns and data structures.

### Step 1: Backend Implementation

1. Create AnalyticsService for cross-module data aggregation
2. Implement AI-powered predictive insights using Gemini
3. Add efficient data processing and caching mechanisms
4. Create report generation and export functionality

### Step 2: Frontend Implementation

1. Create comprehensive analytics dashboard with multiple chart types
2. Implement AI-powered insights interface with interactive elements
3. Add report builder and export functionality
4. Create responsive design for mobile analytics viewing

### Step 3: Integration

1. Connect to all previous modules for data aggregation
2. Test predictive insights generation and accuracy
3. Verify report generation and export functionality
4. Optimize performance for large datasets

## Acceptance Criteria

- [ ] Analytics dashboard displays comprehensive KPIs from all modules
- [ ] AI-powered predictive insights generate accurate predictions and recommendations
- [ ] Interactive charts and visualizations provide drill-down capabilities
- [ ] Report generation creates professional PDF/Excel exports
- [ ] Real-time data updates reflect current system state
- [ ] **Demo Ready:** Can showcase comprehensive analytics and AI insights in 30 seconds
- [ ] **Cross-Module Integration:** Successfully aggregates data from all modules
- [ ] **AI-Powered:** Uses Gemini AI for intelligent predictions and recommendations
- [ ] **Business Intelligence:** Provides actionable insights for maintenance optimization
- [ ] **Mobile Responsive:** Analytics dashboard works on all devices

## Testing Checklist

- [ ] **Data Aggregation:** Test cross-module data collection and correlation
- [ ] **AI Insights:** Verify predictive analytics accuracy and relevance
- [ ] **Chart Rendering:** Test all chart types with various data sets
- [ ] **Report Generation:** Test PDF/Excel export functionality
- [ ] **Performance:** Test with large datasets and multiple concurrent users

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **Data Processing:** Optimized analytics queries and caching
- [ ] **AI Configuration:** Confirmed Gemini AI integration for insights generation
- [ ] **Export Functionality:** Verified report generation and export capabilities
- [ ] **Performance Testing:** Confirmed dashboard loads quickly with production data volumes