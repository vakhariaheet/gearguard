# Module M05: Enhanced Equipment + Smart Features

## Overview

**Estimated Time:** 1.5hr

**Complexity:** Medium

**Type:** Full-stack

**Risk Level:** Low

**Dependencies:** F01 (Equipment Management)

## Problem Context

Enhance the basic equipment management with advanced features including predictive maintenance, equipment health monitoring, smart maintenance scheduling, and integration with request management. This module transforms basic equipment tracking into an intelligent maintenance system.

## Technical Requirements

**Module Type:** Full-stack (Enhancement of F01)

### Backend Tasks

- [ ] **Enhanced Handler Files:** Extend existing equipment handlers
  - `handlers/getEquipmentHealth.ts` - GET /api/equipment/:id/health
  - `handlers/predictMaintenance.ts` - POST /api/equipment/:id/predict-maintenance
  - `handlers/getMaintenanceSchedule.ts` - GET /api/equipment/:id/schedule
  - `handlers/updateEquipmentStatus.ts` - PUT /api/equipment/:id/status

- [ ] **Function Configs:** Create new function configurations
  - `functions/getEquipmentHealth.yml`
  - `functions/predictMaintenance.yml`
  - `functions/getMaintenanceSchedule.yml`
  - `functions/updateEquipmentStatus.yml`

- [ ] **Enhanced Service Layer:** Extend EquipmentService with AI features
  - Predictive maintenance algorithms
  - Health scoring and risk assessment
  - Smart scheduling recommendations
  - Integration with request and team data

- [ ] **Type Definitions:** Add enhanced types to `types.ts`
  - Equipment health metrics
  - Predictive maintenance models
  - Smart scheduling types

- [ ] **Integration Points:** Connect with F04 (Requests) and F03 (Teams)
  - Cross-module API calls for request history
  - Team workload integration for scheduling

### Frontend Tasks

- [ ] **Enhanced Components:** Extend existing equipment components
  - `components/equipment/EquipmentHealthDashboard.tsx` - Health monitoring
  - `components/equipment/PredictiveMaintenancePanel.tsx` - AI predictions
  - `components/equipment/SmartScheduler.tsx` - Intelligent scheduling
  - `components/equipment/EquipmentAnalytics.tsx` - Performance analytics

- [ ] **Enhanced Pages:** Add new equipment management pages
  - `pages/equipment/EquipmentHealthPage.tsx` - Health monitoring dashboard
  - `pages/equipment/MaintenanceSchedulePage.tsx` - Smart scheduling interface

- [ ] **Enhanced API Integration:** Extend equipment API service
  - `hooks/useEquipmentHealth.ts` - Health monitoring hooks
  - `hooks/usePredictiveMaintenance.ts` - Predictive analytics hooks

### Database Schema Extensions

```
PK: EQUIPMENT#[id] | SK: HEALTH#[date] | GSI1PK: HEALTH_SCORE#[score] | GSI1SK: EQUIPMENT#[id]
PK: EQUIPMENT#[id] | SK: PREDICTION#[type] | GSI1PK: PREDICTION_DATE#[date] | GSI1SK: EQUIPMENT#[id]

Health Tracking Fields:
- healthScore: number (0-100)
- riskLevel: 'Low' | 'Medium' | 'High' | 'Critical'
- lastAssessment: string (ISO date)
- performanceMetrics: {
  efficiency: number;
  uptime: number;
  errorRate: number;
  energyConsumption?: number;
}
- predictedFailureDate?: string
- recommendedActions: string[]
- maintenanceScore: number (0-100)
```

## Enhancement Features

### Enhancement Feature: Predictive Maintenance AI

**Problem Solved:** Predict when equipment will need maintenance before it breaks down, reducing downtime and preventing costly emergency repairs.

**Enhancement Type:** AI + Smart Logic - Uses Gemini AI with historical data analysis to predict maintenance needs

**User Trigger:** "Predict Maintenance" button on equipment dashboard or automatic daily analysis

**Input Requirements:**
- **Required Fields:** Equipment ID, current performance metrics
- **Optional Fields:** Environmental conditions, usage patterns, maintenance history
- **Validation Rules:** Equipment must have sufficient historical data (minimum 3 months)

**Processing Logic:**
1. **Data Collection:** Gather equipment usage, maintenance history, and performance data
2. **Pattern Analysis:** Analyze trends and identify degradation patterns
3. **AI Prediction:** Use Gemini AI to predict failure probability and optimal maintenance timing
4. **Risk Assessment:** Calculate risk scores and generate actionable recommendations

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface EquipmentHealth {
  equipmentId: string;
  healthScore: number; // 0-100
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  lastAssessment: string;
  performanceMetrics: {
    efficiency: number; // 0-100
    uptime: number; // 0-100
    errorRate: number; // errors per hour
    energyConsumption?: number; // kWh
    vibrationLevel?: number; // 0-100
    temperature?: number; // Celsius
  };
  trendAnalysis: {
    efficiencyTrend: 'Improving' | 'Stable' | 'Declining';
    uptimeTrend: 'Improving' | 'Stable' | 'Declining';
    overallTrend: 'Improving' | 'Stable' | 'Declining';
  };
  alerts: HealthAlert[];
}

export interface HealthAlert {
  id: string;
  type: 'Warning' | 'Critical' | 'Info';
  message: string;
  severity: number; // 1-10
  createdAt: string;
  acknowledged: boolean;
}

export interface PredictiveMaintenanceRequest {
  equipmentId: string;
  analysisType: 'Quick' | 'Comprehensive' | 'Scheduled';
  includeEnvironmental?: boolean;
  forecastDays?: number; // Default 90 days
}

export interface PredictiveMaintenanceResponse {
  equipmentId: string;
  analysisDate: string;
  forecastPeriod: number; // days
  predictions: {
    failureProbability: number; // 0-1
    predictedFailureDate?: string;
    optimalMaintenanceDate: string;
    confidenceLevel: number; // 0-1
    criticalComponents: string[];
  };
  recommendations: {
    immediate: string[];
    shortTerm: string[]; // 1-4 weeks
    longTerm: string[]; // 1-6 months
  };
  costAnalysis: {
    preventiveCost: number;
    emergencyRepairCost: number;
    potentialSavings: number;
  };
  riskFactors: Array<{
    factor: string;
    impact: number; // 0-100
    description: string;
  }>;
}

export interface SmartScheduleRequest {
  equipmentId: string;
  maintenanceType: 'Routine' | 'Preventive' | 'Predictive';
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  estimatedDuration?: number; // hours
  requiredSkills?: string[];
  preferredTeam?: string;
}

export interface SmartScheduleResponse {
  recommendedDate: string;
  alternativeDates: string[];
  assignedTeam: string;
  estimatedDuration: number;
  reasoning: string[];
  conflictWarnings: string[];
  optimizationScore: number; // 0-100
}
```

**Frontend Component:**
```typescript
// components/equipment/PredictiveMaintenancePanel.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  Calendar, 
  DollarSign,
  Zap,
  Clock,
  Target
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { PredictiveMaintenanceResponse, EquipmentHealth } from '@/types/equipment';

interface PredictiveMaintenancePanelProps {
  equipmentId: string;
  currentHealth: EquipmentHealth;
  onMaintenanceScheduled?: (date: string) => void;
}

export const PredictiveMaintenancePanel = ({
  equipmentId,
  currentHealth,
  onMaintenanceScheduled
}: PredictiveMaintenancePanelProps) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [prediction, setPrediction] = useState<PredictiveMaintenanceResponse | null>(null);
  const [analysisType, setAnalysisType] = useState<'Quick' | 'Comprehensive'>('Quick');

  const handlePredictiveMaintenance = async () => {
    setIsAnalyzing(true);
    try {
      const response = await fetch(`/api/equipment/${equipmentId}/predict-maintenance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          equipmentId,
          analysisType,
          includeEnvironmental: true,
          forecastDays: 90
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Predictive analysis failed');
      }

      const data = await response.json();
      setPrediction(data.data);
      toast.success('Predictive maintenance analysis completed');
    } catch (error) {
      console.error('Predictive maintenance error:', error);
      toast.error(error.message || 'Analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const scheduleOptimalMaintenance = async () => {
    if (!prediction) return;

    try {
      const response = await fetch('/api/requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          subject: 'Predictive Maintenance - Optimal Timing',
          description: `AI-recommended maintenance based on predictive analysis. Failure probability: ${Math.round(prediction.predictions.failureProbability * 100)}%`,
          requestType: 'Preventive',
          equipmentId,
          priority: prediction.predictions.failureProbability > 0.7 ? 'High' : 'Medium',
          scheduledDate: prediction.predictions.optimalMaintenanceDate
        })
      });

      if (response.ok) {
        toast.success('Maintenance request scheduled for optimal date');
        onMaintenanceScheduled?.(prediction.predictions.optimalMaintenanceDate);
      }
    } catch (error) {
      toast.error('Failed to schedule maintenance request');
    }
  };

  const getRiskColor = (probability: number) => {
    if (probability < 0.3) return 'text-green-600';
    if (probability < 0.6) return 'text-yellow-600';
    if (probability < 0.8) return 'text-orange-600';
    return 'text-red-600';
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'Improving': return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'Declining': return <TrendingDown className="h-4 w-4 text-red-500" />;
      default: return <div className="h-4 w-4 bg-gray-400 rounded-full" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Current Health Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Equipment Health Status
            <Badge className={
              currentHealth.riskLevel === 'Low' ? 'bg-green-500' :
              currentHealth.riskLevel === 'Medium' ? 'bg-yellow-500' :
              currentHealth.riskLevel === 'High' ? 'bg-orange-500' : 'bg-red-500'
            }>
              {currentHealth.riskLevel} Risk
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold mb-1">{currentHealth.healthScore}</div>
              <div className="text-sm text-muted-foreground">Health Score</div>
              <Progress value={currentHealth.healthScore} className="h-2 mt-2" />
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-1">
                <span className="text-2xl font-bold mr-2">{currentHealth.performanceMetrics.efficiency}%</span>
                {getTrendIcon(currentHealth.trendAnalysis.efficiencyTrend)}
              </div>
              <div className="text-sm text-muted-foreground">Efficiency</div>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-1">
                <span className="text-2xl font-bold mr-2">{currentHealth.performanceMetrics.uptime}%</span>
                {getTrendIcon(currentHealth.trendAnalysis.uptimeTrend)}
              </div>
              <div className="text-sm text-muted-foreground">Uptime</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold mb-1">{currentHealth.performanceMetrics.errorRate}</div>
              <div className="text-sm text-muted-foreground">Errors/Hour</div>
            </div>
          </div>

          <div className="flex gap-2 mb-4">
            <Button
              onClick={handlePredictiveMaintenance}
              disabled={isAnalyzing}
              className="flex-1"
            >
              {isAnalyzing ? 'Analyzing...' : 'Run Predictive Analysis'}
            </Button>
            <Button
              variant="outline"
              onClick={() => setAnalysisType(analysisType === 'Quick' ? 'Comprehensive' : 'Quick')}
            >
              {analysisType} Mode
            </Button>
          </div>

          {/* Active Alerts */}
          {currentHealth.alerts.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-yellow-500" />
                Active Alerts ({currentHealth.alerts.length})
              </h4>
              {currentHealth.alerts.slice(0, 3).map((alert) => (
                <div key={alert.id} className="flex items-center justify-between p-2 bg-muted rounded">
                  <div className="flex items-center gap-2">
                    <Badge variant={alert.type === 'Critical' ? 'destructive' : 'secondary'}>
                      {alert.type}
                    </Badge>
                    <span className="text-sm">{alert.message}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(alert.createdAt).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Predictive Analysis Results */}
      {prediction && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-blue-500" />
              Predictive Maintenance Analysis
              <Badge variant="secondary">
                {Math.round(prediction.predictions.confidenceLevel * 100)}% Confidence
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="predictions" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="predictions">Predictions</TabsTrigger>
                <TabsTrigger value="recommendations">Actions</TabsTrigger>
                <TabsTrigger value="costs">Cost Analysis</TabsTrigger>
                <TabsTrigger value="risks">Risk Factors</TabsTrigger>
              </TabsList>

              <TabsContent value="predictions" className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Failure Probability</span>
                        <span className={`text-lg font-bold ${getRiskColor(prediction.predictions.failureProbability)}`}>
                          {Math.round(prediction.predictions.failureProbability * 100)}%
                        </span>
                      </div>
                      <Progress 
                        value={prediction.predictions.failureProbability * 100} 
                        className="h-2"
                      />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="h-4 w-4" />
                        <span className="text-sm font-medium">Optimal Maintenance Date</span>
                      </div>
                      <div className="text-lg font-bold">
                        {new Date(prediction.predictions.optimalMaintenanceDate).toLocaleDateString()}
                      </div>
                      <Button 
                        size="sm" 
                        className="mt-2 w-full"
                        onClick={scheduleOptimalMaintenance}
                      >
                        Schedule Maintenance
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                {prediction.predictions.criticalComponents.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium mb-2">Critical Components</h4>
                    <div className="flex flex-wrap gap-2">
                      {prediction.predictions.criticalComponents.map((component, index) => (
                        <Badge key={index} variant="outline" className="text-red-600 border-red-200">
                          {component}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="recommendations" className="space-y-4">
                <div className="grid gap-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      Immediate Actions
                    </h4>
                    <ul className="space-y-1">
                      {prediction.recommendations.immediate.map((action, index) => (
                        <li key={index} className="text-sm flex items-start">
                          <span className="w-1 h-1 bg-red-500 rounded-full mt-2 mr-2 flex-shrink-0" />
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                      <Clock className="h-4 w-4 text-yellow-500" />
                      Short-term (1-4 weeks)
                    </h4>
                    <ul className="space-y-1">
                      {prediction.recommendations.shortTerm.map((action, index) => (
                        <li key={index} className="text-sm flex items-start">
                          <span className="w-1 h-1 bg-yellow-500 rounded-full mt-2 mr-2 flex-shrink-0" />
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                      <Target className="h-4 w-4 text-green-500" />
                      Long-term (1-6 months)
                    </h4>
                    <ul className="space-y-1">
                      {prediction.recommendations.longTerm.map((action, index) => (
                        <li key={index} className="text-sm flex items-start">
                          <span className="w-1 h-1 bg-green-500 rounded-full mt-2 mr-2 flex-shrink-0" />
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="costs" className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <DollarSign className="h-8 w-8 text-green-500 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-green-600">
                        ${prediction.costAnalysis.preventiveCost.toLocaleString()}
                      </div>
                      <div className="text-sm text-muted-foreground">Preventive Cost</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 text-center">
                      <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-red-600">
                        ${prediction.costAnalysis.emergencyRepairCost.toLocaleString()}
                      </div>
                      <div className="text-sm text-muted-foreground">Emergency Repair</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 text-center">
                      <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-blue-600">
                        ${prediction.costAnalysis.potentialSavings.toLocaleString()}
                      </div>
                      <div className="text-sm text-muted-foreground">Potential Savings</div>
                    </CardContent>
                  </Card>
                </div>

                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="text-sm font-medium text-green-800 mb-1">Cost Benefit Analysis</div>
                  <div className="text-sm text-green-700">
                    Preventive maintenance could save up to{' '}
                    <span className="font-bold">
                      ${(prediction.costAnalysis.emergencyRepairCost - prediction.costAnalysis.preventiveCost).toLocaleString()}
                    </span>{' '}
                    compared to emergency repairs, representing a{' '}
                    <span className="font-bold">
                      {Math.round(((prediction.costAnalysis.emergencyRepairCost - prediction.costAnalysis.preventiveCost) / prediction.costAnalysis.emergencyRepairCost) * 100)}%
                    </span>{' '}
                    cost reduction.
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="risks" className="space-y-4">
                {prediction.riskFactors.map((risk, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{risk.factor}</span>
                        <Badge variant={risk.impact > 70 ? 'destructive' : risk.impact > 40 ? 'secondary' : 'outline'}>
                          {risk.impact}% Impact
                        </Badge>
                      </div>
                      <Progress value={risk.impact} className="h-2 mb-2" />
                      <p className="text-sm text-muted-foreground">{risk.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {isAnalyzing && (
        <Card>
          <CardContent className="p-6 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <div className="text-lg font-medium mb-2">Running {analysisType} Analysis</div>
            <div className="text-sm text-muted-foreground">
              Analyzing equipment data, maintenance history, and performance patterns...
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/EquipmentService.ts - Add this method
async predictMaintenance(params: PredictiveMaintenanceRequest): Promise<PredictiveMaintenanceResponse> {
  try {
    // Get equipment details and history
    const equipment = await this.getEquipment(params.equipmentId);
    if (!equipment) {
      throw new Error('Equipment not found');
    }

    // Get maintenance history and performance data
    const maintenanceHistory = await this.getMaintenanceHistory(params.equipmentId);
    const performanceData = await this.getPerformanceData(params.equipmentId, params.forecastDays || 90);

    // Calculate current health metrics
    const currentHealth = await this.calculateCurrentHealth(equipment, performanceData);

    // Use AI for comprehensive predictive analysis
    const aiPrompt = `Perform predictive maintenance analysis for industrial equipment:

Equipment Details:
- Name: ${equipment.equipmentName}
- Category: ${equipment.category}
- Age: ${this.calculateEquipmentAge(equipment.purchaseDate)} years
- Current Health Score: ${currentHealth.healthScore}/100

Performance Metrics (Last 30 days):
- Efficiency: ${currentHealth.performanceMetrics.efficiency}%
- Uptime: ${currentHealth.performanceMetrics.uptime}%
- Error Rate: ${currentHealth.performanceMetrics.errorRate} errors/hour
- Trend: ${currentHealth.trendAnalysis.overallTrend}

Maintenance History:
- Total Maintenance Events: ${maintenanceHistory.length}
- Last Maintenance: ${maintenanceHistory[0]?.completedAt || 'Never'}
- Average Repair Time: ${this.calculateAverageRepairTime(maintenanceHistory)} hours
- Common Issues: ${this.extractCommonIssues(maintenanceHistory).join(', ')}

Analysis Requirements:
- Forecast Period: ${params.forecastDays || 90} days
- Analysis Type: ${params.analysisType}

Provide detailed predictive maintenance analysis including:
1. Failure probability (0-1) for the forecast period
2. Optimal maintenance date (ISO format)
3. Critical components likely to fail
4. Immediate, short-term, and long-term recommendations
5. Cost estimates for preventive vs emergency repair
6. Key risk factors with impact scores

Consider equipment age, usage patterns, maintenance history, and performance trends.`;

    const aiResponse = await geminiClient.generateJSON({
      prompt: aiPrompt,
      schema: {
        failureProbability: 'number',
        optimalMaintenanceDate: 'string',
        criticalComponents: 'array of strings',
        immediateActions: 'array of strings',
        shortTermActions: 'array of strings',
        longTermActions: 'array of strings',
        preventiveCost: 'number',
        emergencyRepairCost: 'number',
        riskFactors: 'array of objects with factor, impact, description'
      }
    });

    // Calculate confidence based on data quality
    const confidence = this.calculatePredictionConfidence(maintenanceHistory, performanceData);

    // Generate cost analysis
    const costAnalysis = this.generateCostAnalysis(
      equipment,
      aiResponse.preventiveCost || this.estimatePreventiveCost(equipment),
      aiResponse.emergencyRepairCost || this.estimateEmergencyRepairCost(equipment)
    );

    // Process risk factors
    const riskFactors = aiResponse.riskFactors || this.generateDefaultRiskFactors(equipment, currentHealth);

    return {
      equipmentId: params.equipmentId,
      analysisDate: new Date().toISOString(),
      forecastPeriod: params.forecastDays || 90,
      predictions: {
        failureProbability: Math.min(Math.max(aiResponse.failureProbability || 0.3, 0), 1),
        predictedFailureDate: aiResponse.failureProbability > 0.7 ? 
          this.calculatePredictedFailureDate(params.forecastDays || 90, aiResponse.failureProbability) : 
          undefined,
        optimalMaintenanceDate: aiResponse.optimalMaintenanceDate || 
          this.calculateOptimalMaintenanceDate(params.forecastDays || 90),
        confidenceLevel: confidence,
        criticalComponents: aiResponse.criticalComponents || this.identifyCriticalComponents(equipment)
      },
      recommendations: {
        immediate: aiResponse.immediateActions || [
          'Inspect equipment for visible wear',
          'Check all safety systems',
          'Review recent performance logs'
        ],
        shortTerm: aiResponse.shortTermActions || [
          'Schedule detailed inspection',
          'Order replacement parts',
          'Plan maintenance window'
        ],
        longTerm: aiResponse.longTermActions || [
          'Consider equipment upgrade',
          'Implement condition monitoring',
          'Review maintenance procedures'
        ]
      },
      costAnalysis,
      riskFactors
    };
  } catch (error) {
    console.error('Predictive maintenance analysis failed:', error);
    throw new Error(`Predictive analysis failed: ${error.message}`);
  }
}

private calculateEquipmentAge(purchaseDate: string): number {
  return (Date.now() - new Date(purchaseDate).getTime()) / (1000 * 60 * 60 * 24 * 365);
}

private async calculateCurrentHealth(equipment: any, performanceData: any[]): Promise<EquipmentHealth> {
  // Calculate health metrics based on recent performance
  const recentData = performanceData.slice(-30); // Last 30 days
  
  const avgEfficiency = recentData.reduce((sum, d) => sum + (d.efficiency || 85), 0) / recentData.length;
  const avgUptime = recentData.reduce((sum, d) => sum + (d.uptime || 95), 0) / recentData.length;
  const avgErrorRate = recentData.reduce((sum, d) => sum + (d.errorRate || 2), 0) / recentData.length;

  // Calculate overall health score
  const healthScore = Math.round((avgEfficiency * 0.4) + (avgUptime * 0.4) + ((100 - avgErrorRate * 10) * 0.2));

  // Determine risk level
  let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  if (healthScore >= 85) riskLevel = 'Low';
  else if (healthScore >= 70) riskLevel = 'Medium';
  else if (healthScore >= 50) riskLevel = 'High';
  else riskLevel = 'Critical';

  // Analyze trends
  const trendAnalysis = this.analyzeTrends(performanceData);

  return {
    equipmentId: equipment.id,
    healthScore,
    riskLevel,
    lastAssessment: new Date().toISOString(),
    performanceMetrics: {
      efficiency: Math.round(avgEfficiency),
      uptime: Math.round(avgUptime),
      errorRate: Math.round(avgErrorRate * 10) / 10
    },
    trendAnalysis,
    alerts: this.generateHealthAlerts(healthScore, riskLevel, trendAnalysis)
  };
}

private analyzeTrends(performanceData: any[]): any {
  // Simple trend analysis - compare first half vs second half
  const midPoint = Math.floor(performanceData.length / 2);
  const firstHalf = performanceData.slice(0, midPoint);
  const secondHalf = performanceData.slice(midPoint);

  const firstAvgEfficiency = firstHalf.reduce((sum, d) => sum + (d.efficiency || 85), 0) / firstHalf.length;
  const secondAvgEfficiency = secondHalf.reduce((sum, d) => sum + (d.efficiency || 85), 0) / secondHalf.length;

  const firstAvgUptime = firstHalf.reduce((sum, d) => sum + (d.uptime || 95), 0) / firstHalf.length;
  const secondAvgUptime = secondHalf.reduce((sum, d) => sum + (d.uptime || 95), 0) / secondHalf.length;

  const efficiencyTrend = secondAvgEfficiency > firstAvgEfficiency + 2 ? 'Improving' :
                         secondAvgEfficiency < firstAvgEfficiency - 2 ? 'Declining' : 'Stable';
  
  const uptimeTrend = secondAvgUptime > firstAvgUptime + 2 ? 'Improving' :
                     secondAvgUptime < firstAvgUptime - 2 ? 'Declining' : 'Stable';

  const overallTrend = (efficiencyTrend === 'Improving' && uptimeTrend === 'Improving') ? 'Improving' :
                      (efficiencyTrend === 'Declining' || uptimeTrend === 'Declining') ? 'Declining' : 'Stable';

  return { efficiencyTrend, uptimeTrend, overallTrend };
}

private generateHealthAlerts(healthScore: number, riskLevel: string, trendAnalysis: any): HealthAlert[] {
  const alerts: HealthAlert[] = [];

  if (healthScore < 60) {
    alerts.push({
      id: `alert-${Date.now()}-1`,
      type: 'Critical',
      message: 'Equipment health score is critically low',
      severity: 9,
      createdAt: new Date().toISOString(),
      acknowledged: false
    });
  }

  if (trendAnalysis.overallTrend === 'Declining') {
    alerts.push({
      id: `alert-${Date.now()}-2`,
      type: 'Warning',
      message: 'Performance trend is declining',
      severity: 6,
      createdAt: new Date().toISOString(),
      acknowledged: false
    });
  }

  return alerts;
}

private calculatePredictionConfidence(maintenanceHistory: any[], performanceData: any[]): number {
  let confidence = 0.5; // Base confidence

  // More maintenance history = higher confidence
  if (maintenanceHistory.length > 10) confidence += 0.2;
  else if (maintenanceHistory.length > 5) confidence += 0.1;

  // More performance data = higher confidence
  if (performanceData.length > 60) confidence += 0.2;
  else if (performanceData.length > 30) confidence += 0.1;

  // Recent data = higher confidence
  const recentData = performanceData.filter(d => 
    new Date(d.date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  );
  if (recentData.length > 20) confidence += 0.1;

  return Math.min(confidence, 0.95);
}

private generateCostAnalysis(equipment: any, preventiveCost: number, emergencyRepairCost: number) {
  return {
    preventiveCost,
    emergencyRepairCost,
    potentialSavings: emergencyRepairCost - preventiveCost
  };
}

private estimatePreventiveCost(equipment: any): number {
  // Simple cost estimation based on equipment category
  const baseCosts: Record<string, number> = {
    'Machine': 2500,
    'Vehicle': 1500,
    'Computer': 500,
    'HVAC': 1200,
    'Electrical': 800
  };
  
  return baseCosts[equipment.category] || 1000;
}

private estimateEmergencyRepairCost(equipment: any): number {
  // Emergency repairs typically cost 3-5x more than preventive
  return this.estimatePreventiveCost(equipment) * 4;
}

private generateDefaultRiskFactors(equipment: any, health: EquipmentHealth) {
  return [
    {
      factor: 'Equipment Age',
      impact: Math.min(this.calculateEquipmentAge(equipment.purchaseDate) * 15, 100),
      description: 'Older equipment has higher failure probability'
    },
    {
      factor: 'Performance Decline',
      impact: 100 - health.healthScore,
      description: 'Current performance metrics indicate potential issues'
    },
    {
      factor: 'Maintenance History',
      impact: 30,
      description: 'Historical maintenance patterns affect future reliability'
    }
  ];
}

private identifyCriticalComponents(equipment: any): string[] {
  // Default critical components based on equipment type
  const componentMap: Record<string, string[]> = {
    'Machine': ['Motor', 'Bearings', 'Hydraulic System', 'Control Unit'],
    'Vehicle': ['Engine', 'Transmission', 'Brakes', 'Electrical System'],
    'Computer': ['Hard Drive', 'Power Supply', 'Cooling System', 'Memory'],
    'HVAC': ['Compressor', 'Fan Motor', 'Filters', 'Thermostat'],
    'Electrical': ['Circuit Breakers', 'Transformers', 'Wiring', 'Control Panel']
  };
  
  return componentMap[equipment.category] || ['Primary System', 'Control Unit', 'Safety Systems'];
}

private calculateOptimalMaintenanceDate(forecastDays: number): string {
  // Schedule maintenance at 70% of forecast period for optimal timing
  const optimalDays = Math.round(forecastDays * 0.7);
  const optimalDate = new Date(Date.now() + optimalDays * 24 * 60 * 60 * 1000);
  return optimalDate.toISOString();
}

private calculatePredictedFailureDate(forecastDays: number, failureProbability: number): string {
  // Higher probability = earlier predicted failure
  const failureDays = Math.round(forecastDays * (1 - failureProbability));
  const failureDate = new Date(Date.now() + failureDays * 24 * 60 * 60 * 1000);
  return failureDate.toISOString();
}

private async getPerformanceData(equipmentId: string, days: number): Promise<any[]> {
  // Mock performance data - in real implementation, would fetch from monitoring systems
  const data = [];
  for (let i = 0; i < days; i++) {
    const date = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
    data.push({
      date: date.toISOString(),
      efficiency: 85 + Math.random() * 10 - (i * 0.1), // Slight decline over time
      uptime: 95 + Math.random() * 5 - (i * 0.05),
      errorRate: 1 + Math.random() * 2 + (i * 0.01)
    });
  }
  return data;
}
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` and understand F01 (Equipment Management) module structure.

### Step 1: Backend Enhancement

1. Extend existing EquipmentService with predictive maintenance methods
2. Add new handlers for health monitoring and predictions
3. Implement AI-powered predictive analysis using Gemini
4. Create integration points with F04 (Requests) for scheduling

### Step 2: Frontend Enhancement

1. Extend existing equipment components with health monitoring
2. Create predictive maintenance dashboard
3. Add smart scheduling interface
4. Integrate with enhanced backend APIs

### Step 3: Integration

1. Connect with F04 (Requests) for automatic maintenance scheduling
2. Integrate with F03 (Teams) for optimal team assignment
3. Test predictive maintenance workflow end-to-end
4. Verify cross-module data flow works correctly

## Acceptance Criteria

- [ ] Equipment health monitoring displays real-time metrics and trends
- [ ] Predictive maintenance analysis generates accurate failure predictions
- [ ] AI-powered recommendations provide actionable maintenance insights
- [ ] Cost analysis shows preventive vs emergency repair comparisons
- [ ] Smart scheduling integrates with request management system
- [ ] **Demo Ready:** Can demonstrate predictive maintenance analysis in 30 seconds
- [ ] **Integration Working:** Connects seamlessly with F01, F03, and F04 modules
- [ ] **AI-Powered:** Uses Gemini AI for intelligent predictions and recommendations
- [ ] **Error Handling:** Graceful failure modes implemented
- [ ] **Mobile Responsive:** Works on mobile devices

## Testing Checklist

- [ ] **Predictive Analysis:** Test AI-powered maintenance predictions
- [ ] **Health Monitoring:** Verify health score calculations and trends
- [ ] **Cost Analysis:** Test cost estimation and savings calculations
- [ ] **Integration:** Test cross-module API calls and data sharing
- [ ] **RBAC Testing:** Verify permissions work for different roles

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **Serverless Config:** Added enhanced function imports to serverless.yml
- [ ] **Integration Points:** Verified cross-module API calls work correctly
- [ ] **AI Configuration:** Confirmed Gemini AI integration is working
- [ ] **Testing:** Manual testing of all enhanced features completed