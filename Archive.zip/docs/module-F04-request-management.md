# Module F04: Request Management

## Overview

**Estimated Time:** 1hr

**Complexity:** Medium

**Type:** Full-stack

**Risk Level:** Low

**Dependencies:** None

## Problem Context

The system must handle the complete lifecycle of maintenance requests, supporting both corrective (unplanned repairs) and preventive (scheduled maintenance) request types. Requests should track the workflow from creation through completion with proper status management and duration tracking.

## Technical Requirements

**Module Type:** Full-stack

### Backend Tasks

- [ ] **Handler Files:** Create CRUD handlers for request management
  - `handlers/listRequests.ts` - GET /api/requests
  - `handlers/getRequest.ts` - GET /api/requests/:id
  - `handlers/createRequest.ts` - POST /api/requests
  - `handlers/updateRequest.ts` - PUT /api/requests/:id
  - `handlers/deleteRequest.ts` - DELETE /api/requests/:id
  - `handlers/assignRequest.ts` - POST /api/requests/:id/assign
  - `handlers/updateStatus.ts` - PUT /api/requests/:id/status

- [ ] **Function Configs:** Create serverless function configurations
  - `functions/listRequests.yml`
  - `functions/getRequest.yml`
  - `functions/createRequest.yml`
  - `functions/updateRequest.yml`
  - `functions/deleteRequest.yml`
  - `functions/assignRequest.yml`
  - `functions/updateStatus.yml`

- [ ] **Service Layer:** Business logic in `services/RequestService.ts`
  - Request CRUD operations
  - Status workflow management
  - Assignment logic
  - Duration tracking and calculations

- [ ] **Type Definitions:** Add types to `types.ts`
  - Request entity with all workflow states
  - Status transition rules
  - Request/response types for API endpoints

- [ ] **RBAC Verification:** Module already configured in `config/permissions.ts`

- [ ] **AWS Service Integration:** Use `shared/clients/dynamodb` for data storage

### Frontend Tasks

- [ ] **Components:** Request management UI components
  - `components/requests/RequestList.tsx` - List view with filtering
  - `components/requests/RequestForm.tsx` - Create/edit request form
  - `components/requests/RequestCard.tsx` - Request card for Kanban view
  - `components/requests/StatusBadge.tsx` - Status indicator component
  - `components/requests/RequestDetails.tsx` - Detailed request view

- [ ] **Pages:** Request management pages
  - `pages/requests/RequestListPage.tsx` - Main requests list
  - `pages/requests/RequestCreatePage.tsx` - Create new request
  - `pages/requests/RequestEditPage.tsx` - Edit existing request
  - `pages/requests/RequestDetailsPage.tsx` - Request details and history

- [ ] **API Integration:** Request API service
  - `hooks/useRequests.ts` - React Query hooks for request operations
  - `services/requestsApi.ts` - API service functions

- [ ] **Routing:** Add request routes to React Router

### Database Schema (Single Table)

```
PK: REQUEST#[id] | SK: DETAILS | GSI1PK: STATUS#[status] | GSI1SK: REQUEST#[id]
PK: REQUEST#[id] | SK: EQUIPMENT#[equipmentId] | GSI1PK: EQUIPMENT#[equipmentId] | GSI1SK: REQUEST#[id]
PK: REQUEST#[id] | SK: ASSIGNEE#[userId] | GSI1PK: USER#[userId] | GSI1SK: REQUEST#[id]

Request Fields:
- subject: string (required) - What is wrong?
- description?: string - Detailed description
- requestType: 'Corrective' | 'Preventive'
- equipmentId: string (required)
- equipmentName: string (denormalized for display)
- assignedTeam?: string (team ID)
- assignedTechnician?: string (user ID)
- status: 'New' | 'In Progress' | 'Repaired' | 'Scrap'
- priority: 'Low' | 'Medium' | 'High' | 'Critical'
- scheduledDate?: string (ISO date) - For preventive maintenance
- startedAt?: string (ISO date)
- completedAt?: string (ISO date)
- hoursSpent?: number - Duration tracking
- notes?: string - Technician notes
- createdBy: string (user ID)
- createdAt: string
- updatedAt: string
```

## Enhancement Features

### Enhancement Feature: Smart Request Auto-Fill

**Problem Solved:** When users select equipment for a maintenance request, automatically populate relevant fields like team assignment, priority suggestions, and common issues to speed up request creation.

**Enhancement Type:** Smart Logic + AI - Uses equipment history and AI to suggest optimal request details

**User Trigger:** Equipment selection dropdown in request creation form

**Input Requirements:**
- **Required Fields:** Equipment ID
- **Optional Fields:** Request type, user description
- **Validation Rules:** Equipment must exist and be active

**Processing Logic:**
1. **Equipment Analysis:** Fetch equipment details and maintenance history
2. **Pattern Recognition:** Analyze common issues and maintenance patterns
3. **AI Suggestions:** Generate smart suggestions for request details
4. **Auto-Population:** Fill form fields with suggested values

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface MaintenanceRequest {
  id: string;
  subject: string;
  description?: string;
  requestType: 'Corrective' | 'Preventive';
  equipmentId: string;
  equipmentName: string;
  equipmentCategory: string;
  assignedTeam?: string;
  assignedTechnician?: string;
  status: 'New' | 'In Progress' | 'Repaired' | 'Scrap';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  scheduledDate?: string;
  startedAt?: string;
  completedAt?: string;
  hoursSpent?: number;
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface RequestAutoFillRequest {
  equipmentId: string;
  requestType?: 'Corrective' | 'Preventive';
  userDescription?: string;
}

export interface RequestAutoFillResponse {
  suggestedSubject: string;
  suggestedDescription: string;
  suggestedPriority: 'Low' | 'Medium' | 'High' | 'Critical';
  suggestedTeam?: string;
  suggestedScheduleDate?: string;
  commonIssues: string[];
  maintenanceHistory: {
    lastMaintenance?: string;
    averageRepairTime: number;
    commonProblems: string[];
    recommendedActions: string[];
  };
  confidence: number;
}

export interface RequestStatusUpdate {
  requestId: string;
  newStatus: 'New' | 'In Progress' | 'Repaired' | 'Scrap';
  notes?: string;
  hoursSpent?: number;
  completedBy?: string;
}
```

**Frontend Component:**
```typescript
// components/requests/SmartRequestForm.tsx
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, Clock, AlertTriangle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { RequestAutoFillResponse } from '@/types/requests';

interface SmartRequestFormProps {
  onSubmit: (requestData: any) => void;
  equipmentOptions: Array<{ id: string; name: string; category: string }>;
}

export const SmartRequestForm = ({ onSubmit, equipmentOptions }: SmartRequestFormProps) => {
  const [formData, setFormData] = useState({
    subject: '',
    description: '',
    requestType: 'Corrective' as 'Corrective' | 'Preventive',
    equipmentId: '',
    priority: 'Medium' as 'Low' | 'Medium' | 'High' | 'Critical',
    scheduledDate: ''
  });

  const [autoFillSuggestion, setAutoFillSuggestion] = useState<RequestAutoFillResponse | null>(null);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  const handleEquipmentChange = async (equipmentId: string) => {
    setFormData(prev => ({ ...prev, equipmentId }));
    
    if (!equipmentId) {
      setAutoFillSuggestion(null);
      return;
    }

    setIsLoadingSuggestions(true);
    try {
      const response = await fetch('/api/requests/auto-fill', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          equipmentId,
          requestType: formData.requestType,
          userDescription: formData.description
        })
      });

      if (response.ok) {
        const data = await response.json();
        setAutoFillSuggestion(data.data);
      }
    } catch (error) {
      console.error('Auto-fill failed:', error);
    } finally {
      setIsLoadingSuggestions(false);
    }
  };

  const applySuggestion = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    toast.success(`Applied suggestion for ${field}`);
  };

  const applyAllSuggestions = () => {
    if (!autoFillSuggestion) return;

    setFormData(prev => ({
      ...prev,
      subject: autoFillSuggestion.suggestedSubject,
      description: autoFillSuggestion.suggestedDescription,
      priority: autoFillSuggestion.suggestedPriority,
      scheduledDate: autoFillSuggestion.suggestedScheduleDate || prev.scheduledDate
    }));

    toast.success('Applied all suggestions');
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Low': return 'bg-green-500';
      case 'Medium': return 'bg-yellow-500';
      case 'High': return 'bg-orange-500';
      case 'Critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Create Maintenance Request</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="requestType">Request Type</Label>
              <Select
                value={formData.requestType}
                onValueChange={(value: 'Corrective' | 'Preventive') => 
                  setFormData(prev => ({ ...prev, requestType: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Corrective">Corrective (Breakdown)</SelectItem>
                  <SelectItem value="Preventive">Preventive (Scheduled)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="equipment">Equipment *</Label>
              <Select
                value={formData.equipmentId}
                onValueChange={handleEquipmentChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select equipment..." />
                </SelectTrigger>
                <SelectContent>
                  {equipmentOptions.map((equipment) => (
                    <SelectItem key={equipment.id} value={equipment.id}>
                      {equipment.name} ({equipment.category})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="subject">Subject *</Label>
              {autoFillSuggestion && formData.subject !== autoFillSuggestion.suggestedSubject && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => applySuggestion('subject', autoFillSuggestion.suggestedSubject)}
                  className="text-xs"
                >
                  <Lightbulb className="h-3 w-3 mr-1" />
                  Use Suggestion
                </Button>
              )}
            </div>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
              placeholder="What is wrong?"
              required
            />
            {autoFillSuggestion && (
              <div className="text-xs text-muted-foreground">
                Suggested: "{autoFillSuggestion.suggestedSubject}"
              </div>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="description">Description</Label>
              {autoFillSuggestion && formData.description !== autoFillSuggestion.suggestedDescription && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => applySuggestion('description', autoFillSuggestion.suggestedDescription)}
                  className="text-xs"
                >
                  <Lightbulb className="h-3 w-3 mr-1" />
                  Use Suggestion
                </Button>
              )}
            </div>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Detailed description of the issue..."
              rows={3}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="priority">Priority</Label>
                {autoFillSuggestion && formData.priority !== autoFillSuggestion.suggestedPriority && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => applySuggestion('priority', autoFillSuggestion.suggestedPriority)}
                    className="text-xs"
                  >
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Use Suggested
                  </Button>
                )}
              </div>
              <Select
                value={formData.priority}
                onValueChange={(value: 'Low' | 'Medium' | 'High' | 'Critical') => 
                  setFormData(prev => ({ ...prev, priority: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Low">Low</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.requestType === 'Preventive' && (
              <div className="space-y-2">
                <Label htmlFor="scheduledDate">Scheduled Date</Label>
                <Input
                  id="scheduledDate"
                  type="datetime-local"
                  value={formData.scheduledDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, scheduledDate: e.target.value }))}
                />
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <Button type="submit" onClick={() => onSubmit(formData)}>
              Create Request
            </Button>
            {autoFillSuggestion && (
              <Button variant="outline" onClick={applyAllSuggestions}>
                Apply All Suggestions
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Smart Suggestions Panel */}
      {autoFillSuggestion && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-yellow-500" />
              Smart Suggestions
              <Badge variant="secondary">
                {Math.round(autoFillSuggestion.confidence * 100)}% Confidence
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {autoFillSuggestion.commonIssues.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2">Common Issues for this Equipment:</h4>
                <div className="flex flex-wrap gap-1">
                  {autoFillSuggestion.commonIssues.map((issue, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                      onClick={() => applySuggestion('subject', issue)}
                    >
                      {issue}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium mb-2 flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  Maintenance History
                </h4>
                <div className="text-sm space-y-1">
                  <div>Last Maintenance: {
                    autoFillSuggestion.maintenanceHistory.lastMaintenance 
                      ? new Date(autoFillSuggestion.maintenanceHistory.lastMaintenance).toLocaleDateString()
                      : 'Never'
                  }</div>
                  <div>Average Repair Time: {autoFillSuggestion.maintenanceHistory.averageRepairTime}h</div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Recommended Actions:</h4>
                <ul className="text-sm space-y-1">
                  {autoFillSuggestion.maintenanceHistory.recommendedActions.map((action, index) => (
                    <li key={index} className="flex items-start">
                      <span className="w-1 h-1 bg-current rounded-full mt-2 mr-2 flex-shrink-0" />
                      {action}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {isLoadingSuggestions && (
        <Card>
          <CardContent className="p-6 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
            <div className="text-sm text-muted-foreground">Analyzing equipment and generating suggestions...</div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/RequestService.ts - Add this method
async generateAutoFillSuggestions(params: RequestAutoFillRequest): Promise<RequestAutoFillResponse> {
  try {
    // Get equipment details (would normally call equipment service)
    const equipment = await this.getEquipmentDetails(params.equipmentId);
    if (!equipment) {
      throw new Error('Equipment not found');
    }

    // Get maintenance history for this equipment
    const maintenanceHistory = await this.getMaintenanceHistory(params.equipmentId);

    // Analyze common issues and patterns
    const commonIssues = this.extractCommonIssues(maintenanceHistory);
    const averageRepairTime = this.calculateAverageRepairTime(maintenanceHistory);

    // Use AI to generate smart suggestions
    const aiPrompt = `Generate maintenance request suggestions for equipment:

Equipment: ${equipment.name} (${equipment.category})
Request Type: ${params.requestType || 'Corrective'}
User Description: ${params.userDescription || 'None provided'}

Maintenance History:
- Total Requests: ${maintenanceHistory.length}
- Common Issues: ${commonIssues.join(', ')}
- Average Repair Time: ${averageRepairTime} hours
- Last Maintenance: ${maintenanceHistory[0]?.completedAt || 'Never'}

Generate:
1. Suggested subject line (concise, specific to equipment type)
2. Suggested description (detailed, based on common issues)
3. Suggested priority (Low/Medium/High/Critical based on equipment criticality)
4. Recommended actions for technician
5. If preventive maintenance, suggest optimal schedule date

Consider equipment age, usage patterns, and maintenance history.`;

    const aiResponse = await geminiClient.generateJSON({
      prompt: aiPrompt,
      schema: {
        suggestedSubject: 'string',
        suggestedDescription: 'string',
        suggestedPriority: 'string',
        recommendedActions: 'array of strings',
        suggestedScheduleDate: 'string or null'
      }
    });

    // Determine suggested team based on equipment category
    const suggestedTeam = await this.getSuggestedTeam(equipment.category);

    // Calculate confidence based on available data
    const confidence = this.calculateSuggestionConfidence(maintenanceHistory, equipment);

    return {
      suggestedSubject: aiResponse.suggestedSubject || `${equipment.category} maintenance required`,
      suggestedDescription: aiResponse.suggestedDescription || `Maintenance needed for ${equipment.name}`,
      suggestedPriority: aiResponse.suggestedPriority as any || 'Medium',
      suggestedTeam: suggestedTeam?.id,
      suggestedScheduleDate: aiResponse.suggestedScheduleDate,
      commonIssues,
      maintenanceHistory: {
        lastMaintenance: maintenanceHistory[0]?.completedAt,
        averageRepairTime,
        commonProblems: commonIssues,
        recommendedActions: aiResponse.recommendedActions || [
          'Inspect equipment thoroughly',
          'Check for wear and tear',
          'Test all functions',
          'Update maintenance log'
        ]
      },
      confidence
    };
  } catch (error) {
    console.error('Auto-fill suggestion failed:', error);
    throw new Error(`Auto-fill failed: ${error.message}`);
  }
}

private async getEquipmentDetails(equipmentId: string): Promise<any> {
  // Mock equipment data for foundation phase
  // In integration phase, this would call the equipment service
  return {
    id: equipmentId,
    name: 'CNC Machine #1',
    category: 'Machine',
    department: 'Production',
    location: 'Factory Floor A'
  };
}

private async getMaintenanceHistory(equipmentId: string): Promise<any[]> {
  // Get historical requests for this equipment
  const requests = await dynamodb.query(
    'GSI1PK = :equipmentKey',
    { ':equipmentKey': `EQUIPMENT#${equipmentId}` },
    { indexName: 'GSI1' }
  );

  return requests.Items?.map(item => ({
    subject: item.subject,
    completedAt: item.completedAt,
    hoursSpent: item.hoursSpent,
    status: item.status
  })) || [];
}

private extractCommonIssues(history: any[]): string[] {
  // Analyze subjects to find common patterns
  const subjects = history.map(h => h.subject).filter(Boolean);
  
  // Simple pattern matching for common issues
  const patterns = [
    'Oil leak', 'Overheating', 'Strange noise', 'Won\'t start',
    'Performance issue', 'Calibration needed', 'Worn parts',
    'Electrical problem', 'Software error', 'Connectivity issue'
  ];

  return patterns.filter(pattern => 
    subjects.some(subject => 
      subject.toLowerCase().includes(pattern.toLowerCase())
    )
  ).slice(0, 5);
}

private calculateAverageRepairTime(history: any[]): number {
  const completedRequests = history.filter(h => h.hoursSpent && h.hoursSpent > 0);
  if (completedRequests.length === 0) return 4; // Default estimate

  const totalHours = completedRequests.reduce((sum, req) => sum + req.hoursSpent, 0);
  return Math.round(totalHours / completedRequests.length * 10) / 10;
}

private async getSuggestedTeam(equipmentCategory: string): Promise<any> {
  // Simple team suggestion based on equipment category
  const teamMap: Record<string, string> = {
    'Machine': 'Mechanics',
    'Vehicle': 'Mechanics',
    'Computer': 'IT Support',
    'Electrical': 'Electricians',
    'HVAC': 'HVAC'
  };

  const specialization = teamMap[equipmentCategory] || 'General';
  
  // Mock team data - in integration phase, would call team service
  return {
    id: 'team-1',
    name: `${specialization} Team`,
    specialization
  };
}

private calculateSuggestionConfidence(history: any[], equipment: any): number {
  let confidence = 0.5; // Base confidence

  // More history = higher confidence
  if (history.length > 5) confidence += 0.2;
  else if (history.length > 2) confidence += 0.1;

  // Equipment with clear category = higher confidence
  if (equipment.category && equipment.category !== 'Other') confidence += 0.2;

  // Recent maintenance history = higher confidence
  if (history.some(h => h.completedAt && 
    new Date(h.completedAt) > new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
  )) {
    confidence += 0.1;
  }

  return Math.min(confidence, 0.95);
}
```

**API Handler:**
```typescript
// handlers/autoFillRequest.ts
import { APIGatewayProxyResultV2 } from 'aws-lambda';
import { AuthenticatedAPIGatewayEvent } from '../../../shared/types';
import { withRbac } from '../../../shared/auth/rbacMiddleware';
import { successResponse, errorResponse, handleAsyncError } from '../../../shared/response';
import { requestService } from '../services/RequestService';
import { RequestAutoFillRequest } from '../types';

/**
 * @route POST /api/requests/auto-fill
 * @description Generate smart suggestions for maintenance request creation
 */
const baseHandler = async (
  event: AuthenticatedAPIGatewayEvent
): Promise<APIGatewayProxyResultV2> => {
  try {
    // Parse request body
    const body: RequestAutoFillRequest = JSON.parse(event.body || '{}');

    // Validate required fields
    if (!body.equipmentId) {
      return errorResponse(400, 'MISSING_EQUIPMENT_ID', 'Equipment ID is required');
    }

    // Generate auto-fill suggestions
    const suggestions = await requestService.generateAutoFillSuggestions(body);

    return successResponse(suggestions);
  } catch (error) {
    return handleAsyncError(error);
  }
};

export const handler = withRbac(baseHandler, 'requests', 'create');
```

**Function Configuration:**
```yaml
# functions/autoFillRequest.yml
autoFillRequest:
  handler: src/modules/requests/handlers/autoFillRequest.handler
  events:
    - httpApi:
        path: /api/requests/auto-fill
        method: post
        authorizer:
          name: clerkJwtAuthorizer
  environment:
    GEMINI_API_KEY: ${env:GEMINI_API_KEY}
  timeout: 30
  memorySize: 512
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` COMPLETELY before writing any code.

### Step 1: Backend Implementation (Lambda-Compatible)

1. Create handlers for request CRUD operations
2. Implement RequestService with workflow management
3. Add smart auto-fill feature using AI
4. Configure serverless functions with proper RBAC

### Step 2: Frontend Implementation

1. Create request management components using shadcn/ui
2. Implement smart request form with auto-fill suggestions
3. Add status management and workflow tracking
4. Integrate with backend APIs using React Query

### Step 3: Integration

1. Add request routes to React Router
2. Test smart auto-fill feature with equipment data
3. Verify status workflow transitions work correctly
4. Test RBAC permissions for different roles

## Acceptance Criteria

- [ ] Request CRUD operations work for all authorized users
- [ ] Smart auto-fill suggests relevant request details based on equipment
- [ ] Status workflow (New → In Progress → Repaired/Scrap) functions correctly
- [ ] Both corrective and preventive request types are supported
- [ ] Duration tracking and completion recording works
- [ ] **Demo Ready:** Can demonstrate request creation and smart auto-fill in 30 seconds
- [ ] **Full-Stack Working:** Frontend connects to backend, backend connects to database
- [ ] **Lambda Compatible:** Backend code works in serverless environment
- [ ] **Error Handling:** Graceful failure modes implemented
- [ ] **Mobile Responsive:** Works on mobile devices

## Testing Checklist

- [ ] **Manual API Testing:** Test with Postman/curl
- [ ] **Frontend Testing:** Manual testing in browser
- [ ] **Smart Auto-Fill:** Test AI-powered suggestion feature
- [ ] **Status Workflow:** Test status transitions and validation
- [ ] **RBAC Testing:** Verify permissions work for different roles
- [ ] **Integration:** End-to-end flow works as expected

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **Serverless Config:** Added function imports to serverless.yml
- [ ] **RBAC Config:** Verified permissions.ts includes requests module
- [ ] **Types:** Exported types from module's types.ts for frontend use
- [ ] **Testing:** Manual testing completed