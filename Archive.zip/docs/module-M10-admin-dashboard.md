# Module M10: Admin Dashboard + System Management

## Overview

**Estimated Time:** 1.5hr

**Complexity:** Medium

**Type:** Full-stack

**Risk Level:** Low

**Dependencies:** All previous modules (F01-F04, M05-M09)

## Problem Context

Create a unified administrative dashboard that provides system-wide management capabilities, user administration, system configuration, audit logging, and operational oversight. This module serves as the central command center for administrators to manage the entire GearGuard maintenance system.

## Technical Requirements

**Module Type:** Full-stack (System administration and management)

### Backend Tasks

- [ ] **Admin Handler Files:** Create handlers for system administration
  - `handlers/getSystemOverview.ts` - GET /api/admin/system/overview
  - `handlers/getAuditLogs.ts` - GET /api/admin/audit/logs
  - `handlers/getSystemHealth.ts` - GET /api/admin/system/health
  - `handlers/updateSystemConfig.ts` - PUT /api/admin/system/config
  - `handlers/exportSystemData.ts` - POST /api/admin/system/export
  - `handlers/getSystemMetrics.ts` - GET /api/admin/system/metrics

- [ ] **Function Configs:** Create function configurations
  - `functions/getSystemOverview.yml`
  - `functions/getAuditLogs.yml`
  - `functions/getSystemHealth.yml`
  - `functions/updateSystemConfig.yml`
  - `functions/exportSystemData.yml`
  - `functions/getSystemMetrics.yml`

- [ ] **Admin Service Layer:** Create AdminService for system management
  - System health monitoring
  - Audit log aggregation
  - Configuration management
  - Data export and backup
  - User activity monitoring

- [ ] **Type Definitions:** Add admin and system management types
  - System overview interfaces
  - Audit log structures
  - Configuration management types
  - Health monitoring metrics

- [ ] **Integration Points:** Connect with all existing modules
  - Cross-module data aggregation
  - System-wide configuration management
  - Unified audit logging

### Frontend Tasks

- [ ] **Admin Components:** Create comprehensive admin interface
  - `components/admin/SystemOverview.tsx` - System status and metrics
  - `components/admin/UserManagement.tsx` - Enhanced user administration
  - `components/admin/AuditLogViewer.tsx` - Audit log interface
  - `components/admin/SystemConfiguration.tsx` - System settings management
  - `components/admin/DataExportManager.tsx` - Data export and backup
  - `components/admin/SystemHealthMonitor.tsx` - Health monitoring dashboard

- [ ] **Admin Pages:** Administrative interface pages
  - `pages/admin/AdminDashboard.tsx` - Main admin dashboard
  - `pages/admin/SystemManagement.tsx` - System configuration and health
  - `pages/admin/UserAdministration.tsx` - User and role management
  - `pages/admin/AuditLogsPage.tsx` - Audit log viewing and analysis

- [ ] **Enhanced Admin Features:** Advanced administrative capabilities
  - Real-time system monitoring
  - Bulk operations for users and data
  - Advanced filtering and search
  - Export and backup functionality

### Database Schema Extensions

```
PK: ADMIN#AUDIT#[id] | SK: DETAILS | GSI1PK: USER#[userId] | GSI1SK: TIMESTAMP#[timestamp]
PK: ADMIN#CONFIG#[key] | SK: VALUE | GSI1PK: CONFIG_TYPE#[type] | GSI1SK: CONFIG#[key]
PK: ADMIN#HEALTH#[component] | SK: METRICS#[timestamp] | GSI1PK: HEALTH_STATUS#[status] | GSI1SK: TIMESTAMP#[timestamp]

Audit Log Fields:
- auditId: string
- userId: string
- userName: string
- action: string (CREATE, UPDATE, DELETE, LOGIN, LOGOUT, etc.)
- resource: string (equipment, request, team, etc.)
- resourceId?: string
- details: Record<string, any>
- ipAddress: string
- userAgent: string
- timestamp: string
- severity: 'Low' | 'Medium' | 'High' | 'Critical'

System Configuration:
- configKey: string
- configValue: any
- configType: 'system' | 'feature' | 'integration' | 'security'
- description: string
- isEditable: boolean
- lastModified: string
- modifiedBy: string

System Health Metrics:
- component: string (api, database, websocket, etc.)
- status: 'Healthy' | 'Warning' | 'Critical' | 'Down'
- metrics: {
  responseTime: number;
  errorRate: number;
  throughput: number;
  availability: number;
}
- lastCheck: string
- alerts: HealthAlert[]
```

## Enhancement Features

### Enhancement Feature: Intelligent System Monitoring

**Problem Solved:** Proactively monitor system health, detect anomalies, and provide intelligent alerts and recommendations for system optimization and issue prevention.

**Enhancement Type:** AI + Real-time Monitoring - Uses AI to analyze system metrics and predict potential issues

**User Trigger:** Automatic continuous monitoring with real-time dashboard updates

**Input Requirements:**
- **Required Fields:** System metrics, performance data, error logs
- **Optional Fields:** Custom monitoring thresholds, alert preferences
- **Validation Rules:** Metrics must be within expected ranges and formats

**Processing Logic:**
1. **Real-time Monitoring:** Continuously collect system performance metrics
2. **Anomaly Detection:** Use AI to identify unusual patterns and potential issues
3. **Predictive Analysis:** Predict system issues before they become critical
4. **Intelligent Alerting:** Generate smart alerts with context and recommendations

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface SystemOverview {
  systemStatus: 'Healthy' | 'Warning' | 'Critical' | 'Maintenance';
  uptime: number; // seconds
  version: string;
  lastDeployment: string;
  activeUsers: number;
  totalUsers: number;
  systemLoad: {
    cpu: number; // percentage
    memory: number; // percentage
    storage: number; // percentage
    network: number; // Mbps
  };
  moduleStatus: Array<{
    module: string;
    status: 'Healthy' | 'Warning' | 'Critical';
    lastCheck: string;
    responseTime: number;
  }>;
  recentActivity: ActivitySummary;
  alerts: SystemAlert[];
}

export interface ActivitySummary {
  last24Hours: {
    requests: number;
    equipmentUpdates: number;
    userLogins: number;
    maintenanceCompleted: number;
  };
  trends: {
    requestsTrend: 'up' | 'down' | 'stable';
    userActivityTrend: 'up' | 'down' | 'stable';
    systemPerformanceTrend: 'up' | 'down' | 'stable';
  };
}

export interface SystemAlert {
  id: string;
  type: 'Performance' | 'Security' | 'Error' | 'Warning' | 'Info';
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  title: string;
  message: string;
  component: string;
  timestamp: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  resolution?: string;
  autoResolved: boolean;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  resource: string;
  resourceId?: string;
  details: Record<string, any>;
  ipAddress: string;
  userAgent: string;
  timestamp: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  success: boolean;
  errorMessage?: string;
}

export interface SystemConfiguration {
  categories: ConfigurationCategory[];
  lastModified: string;
  modifiedBy: string;
}

export interface ConfigurationCategory {
  name: string;
  description: string;
  settings: ConfigurationSetting[];
}

export interface ConfigurationSetting {
  key: string;
  name: string;
  description: string;
  value: any;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  isEditable: boolean;
  validation?: {
    required?: boolean;
    min?: number;
    max?: number;
    pattern?: string;
    options?: string[];
  };
  category: string;
  lastModified: string;
  modifiedBy: string;
}

export interface SystemHealthMetrics {
  overall: {
    status: 'Healthy' | 'Warning' | 'Critical';
    score: number; // 0-100
    lastCheck: string;
  };
  components: Array<{
    name: string;
    status: 'Healthy' | 'Warning' | 'Critical' | 'Down';
    metrics: {
      responseTime: number; // ms
      errorRate: number; // percentage
      throughput: number; // requests/second
      availability: number; // percentage
    };
    alerts: number;
    lastCheck: string;
  }>;
  performance: {
    apiResponseTime: number;
    databaseResponseTime: number;
    memoryUsage: number;
    cpuUsage: number;
    diskUsage: number;
  };
  trends: {
    responseTimeTrend: ChartData[];
    errorRateTrend: ChartData[];
    throughputTrend: ChartData[];
  };
}

export interface DataExportRequest {
  exportType: 'full' | 'partial';
  modules: string[];
  dateRange: {
    start: string;
    end: string;
  };
  format: 'json' | 'csv' | 'excel';
  includeAuditLogs: boolean;
  includeSystemLogs: boolean;
  compression: boolean;
  encryption: boolean;
}

export interface DataExportResult {
  exportId: string;
  status: 'Pending' | 'Processing' | 'Completed' | 'Failed';
  progress: number; // 0-100
  downloadUrl?: string;
  fileSize?: number; // bytes
  recordCount?: number;
  createdAt: string;
  completedAt?: string;
  expiresAt: string;
  error?: string;
}
```

**Frontend Component:**
```typescript
// components/admin/SystemHealthMonitor.tsx
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Activity, 
  Server, 
  Database, 
  Wifi, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Minus,
  RefreshCw
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { SystemHealthMetrics, SystemAlert } from '@/types/admin';

interface SystemHealthMonitorProps {
  onAlertAcknowledge?: (alertId: string) => void;
}

export const SystemHealthMonitor = ({ onAlertAcknowledge }: SystemHealthMonitorProps) => {
  const [healthMetrics, setHealthMetrics] = useState<SystemHealthMetrics | null>(null);
  const [alerts, setAlerts] = useState<SystemAlert[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    loadHealthMetrics();
    
    if (autoRefresh) {
      const interval = setInterval(loadHealthMetrics, 30000); // Refresh every 30 seconds
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const loadHealthMetrics = async () => {
    setIsLoading(true);
    try {
      const [healthResponse, alertsResponse] = await Promise.all([
        fetch('/api/admin/system/health', {
          headers: { 'Authorization': `Bearer ${await getToken()}` }
        }),
        fetch('/api/admin/system/alerts', {
          headers: { 'Authorization': `Bearer ${await getToken()}` }
        })
      ]);

      if (healthResponse.ok && alertsResponse.ok) {
        const healthData = await healthResponse.json();
        const alertsData = await alertsResponse.json();
        
        setHealthMetrics(healthData.data);
        setAlerts(alertsData.data);
      }
    } catch (error) {
      console.error('Failed to load health metrics:', error);
      toast.error('Failed to load system health data');
    } finally {
      setIsLoading(false);
    }
  };

  const acknowledgeAlert = async (alertId: string) => {
    try {
      const response = await fetch(`/api/admin/system/alerts/${alertId}/acknowledge`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${await getToken()}` }
      });

      if (response.ok) {
        setAlerts(prev => prev.map(alert => 
          alert.id === alertId 
            ? { ...alert, acknowledged: true, acknowledgedAt: new Date().toISOString() }
            : alert
        ));
        onAlertAcknowledge?.(alertId);
        toast.success('Alert acknowledged');
      }
    } catch (error) {
      toast.error('Failed to acknowledge alert');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Healthy': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'Warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'Critical': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'Down': return <XCircle className="h-5 w-5 text-gray-500" />;
      default: return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Healthy': return 'bg-green-500';
      case 'Warning': return 'bg-yellow-500';
      case 'Critical': return 'bg-red-500';
      case 'Down': return 'bg-gray-500';
      default: return 'bg-gray-400';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'border-red-500 bg-red-50';
      case 'High': return 'border-orange-500 bg-orange-50';
      case 'Medium': return 'border-yellow-500 bg-yellow-50';
      case 'Low': return 'border-blue-500 bg-blue-50';
      default: return 'border-gray-500 bg-gray-50';
    }
  };

  const getTrendIcon = (trend: number) => {
    if (trend > 5) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend < -5) return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-gray-500" />;
  };

  if (!healthMetrics) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <div className="text-lg font-medium">Loading System Health...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* System Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              System Health Overview
              <Badge className={getStatusColor(healthMetrics.overall.status)}>
                {healthMetrics.overall.status}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${autoRefresh ? 'animate-spin' : ''}`} />
                {autoRefresh ? 'Auto' : 'Manual'}
              </Button>
              <Button variant="outline" size="sm" onClick={loadHealthMetrics} disabled={isLoading}>
                Refresh
              </Button>
            </div>
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Last updated: {new Date(healthMetrics.overall.lastCheck).toLocaleString()}
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">{healthMetrics.overall.score}</div>
              <div className="text-sm text-muted-foreground">Health Score</div>
              <Progress value={healthMetrics.overall.score} className="h-2 mt-2" />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">{healthMetrics.performance.apiResponseTime}ms</div>
              <div className="text-sm text-muted-foreground">API Response</div>
              <div className="flex items-center justify-center mt-1">
                {getTrendIcon(-2)}
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">{healthMetrics.performance.cpuUsage}%</div>
              <div className="text-sm text-muted-foreground">CPU Usage</div>
              <Progress value={healthMetrics.performance.cpuUsage} className="h-2 mt-2" />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">{healthMetrics.performance.memoryUsage}%</div>
              <div className="text-sm text-muted-foreground">Memory Usage</div>
              <Progress value={healthMetrics.performance.memoryUsage} className="h-2 mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="components" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="components">Components</TabsTrigger>
          <TabsTrigger value="alerts">Alerts ({alerts.filter(a => !a.acknowledged).length})</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="components" className="space-y-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {healthMetrics.components.map((component) => (
              <Card key={component.name}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {component.name === 'API' && <Server className="h-4 w-4" />}
                      {component.name === 'Database' && <Database className="h-4 w-4" />}
                      {component.name === 'WebSocket' && <Wifi className="h-4 w-4" />}
                      <span className="font-medium">{component.name}</span>
                    </div>
                    {getStatusIcon(component.status)}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Response:</span>
                      <div className="font-medium">{component.metrics.responseTime}ms</div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Errors:</span>
                      <div className="font-medium">{component.metrics.errorRate}%</div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Throughput:</span>
                      <div className="font-medium">{component.metrics.throughput}/s</div>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Uptime:</span>
                      <div className="font-medium">{component.metrics.availability}%</div>
                    </div>
                  </div>

                  {component.alerts > 0 && (
                    <div className="mt-3 p-2 bg-yellow-50 rounded border border-yellow-200">
                      <div className="text-sm text-yellow-800">
                        {component.alerts} active alert{component.alerts > 1 ? 's' : ''}
                      </div>
                    </div>
                  )}

                  <div className="text-xs text-muted-foreground mt-2">
                    Last check: {new Date(component.lastCheck).toLocaleTimeString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          {alerts.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                <div className="text-lg font-medium">No Active Alerts</div>
                <div className="text-sm text-muted-foreground">
                  All systems are operating normally
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {alerts.map((alert) => (
                <Card key={alert.id} className={`border-l-4 ${getSeverityColor(alert.severity)}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={alert.severity === 'Critical' ? 'destructive' : 'secondary'}>
                            {alert.severity}
                          </Badge>
                          <Badge variant="outline">{alert.type}</Badge>
                          <span className="text-sm text-muted-foreground">
                            {alert.component}
                          </span>
                        </div>
                        
                        <div className="font-medium mb-1">{alert.title}</div>
                        <div className="text-sm text-muted-foreground mb-2">
                          {alert.message}
                        </div>
                        
                        <div className="text-xs text-muted-foreground">
                          {new Date(alert.timestamp).toLocaleString()}
                          {alert.acknowledged && (
                            <span className="ml-2 text-green-600">
                              • Acknowledged {alert.acknowledgedAt ? 
                                `at ${new Date(alert.acknowledgedAt).toLocaleTimeString()}` : ''
                              }
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {!alert.acknowledged && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => acknowledgeAlert(alert.id)}
                        >
                          Acknowledge
                        </Button>
                      )}
                    </div>

                    {alert.resolution && (
                      <div className="mt-3 p-2 bg-green-50 rounded border border-green-200">
                        <div className="text-sm text-green-800">
                          <span className="font-medium">Resolution:</span> {alert.resolution}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Response Time Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Response time chart would be rendered here using a charting library
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Error Rate Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Error rate chart would be rendered here using a charting library
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Throughput Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Throughput chart would be rendered here using a charting library
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Resource Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>CPU Usage</span>
                      <span>{healthMetrics.performance.cpuUsage}%</span>
                    </div>
                    <Progress value={healthMetrics.performance.cpuUsage} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Memory Usage</span>
                      <span>{healthMetrics.performance.memoryUsage}%</span>
                    </div>
                    <Progress value={healthMetrics.performance.memoryUsage} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Disk Usage</span>
                      <span>{healthMetrics.performance.diskUsage}%</span>
                    </div>
                    <Progress value={healthMetrics.performance.diskUsage} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/AdminService.ts - Create new service
export class AdminService {
  async getSystemOverview(): Promise<SystemOverview> {
    try {
      // Aggregate system-wide data
      const [
        systemMetrics,
        moduleStatuses,
        recentActivity,
        activeAlerts
      ] = await Promise.all([
        this.getSystemMetrics(),
        this.getModuleStatuses(),
        this.getRecentActivity(),
        this.getActiveAlerts()
      ]);

      // Calculate system status
      const systemStatus = this.calculateSystemStatus(moduleStatuses, systemMetrics);

      return {
        systemStatus,
        uptime: systemMetrics.uptime,
        version: process.env.APP_VERSION || '1.0.0',
        lastDeployment: process.env.LAST_DEPLOYMENT || new Date().toISOString(),
        activeUsers: await this.getActiveUserCount(),
        totalUsers: await this.getTotalUserCount(),
        systemLoad: {
          cpu: systemMetrics.cpuUsage,
          memory: systemMetrics.memoryUsage,
          storage: systemMetrics.diskUsage,
          network: systemMetrics.networkThroughput
        },
        moduleStatus: moduleStatuses,
        recentActivity,
        alerts: activeAlerts
      };
    } catch (error) {
      console.error('Failed to get system overview:', error);
      throw new Error(`System overview failed: ${error.message}`);
    }
  }

  async getSystemHealthMetrics(): Promise<SystemHealthMetrics> {
    try {
      const components = await this.getComponentHealth();
      const performance = await this.getPerformanceMetrics();
      const trends = await this.getPerformanceTrends();

      // Calculate overall health score
      const componentScores = components.map(c => this.calculateComponentScore(c));
      const overallScore = Math.round(
        componentScores.reduce((sum, score) => sum + score, 0) / componentScores.length
      );

      const overallStatus = this.getStatusFromScore(overallScore);

      return {
        overall: {
          status: overallStatus,
          score: overallScore,
          lastCheck: new Date().toISOString()
        },
        components,
        performance,
        trends
      };
    } catch (error) {
      console.error('Failed to get system health metrics:', error);
      throw new Error(`Health metrics failed: ${error.message}`);
    }
  }

  async getAuditLogs(params: {
    page?: number;
    limit?: number;
    userId?: string;
    action?: string;
    resource?: string;
    severity?: string;
    dateRange?: { start: string; end: string };
  }): Promise<{ logs: AuditLog[]; total: number; page: number; limit: number }> {
    try {
      const page = params.page || 1;
      const limit = params.limit || 50;

      // Build query parameters
      let queryParams: any = {
        FilterExpression: 'begins_with(PK, :pk)',
        ExpressionAttributeValues: { ':pk': 'ADMIN#AUDIT#' },
        ScanIndexForward: false, // Most recent first
        Limit: limit
      };

      // Apply filters
      if (params.userId) {
        queryParams.FilterExpression += ' AND userId = :userId';
        queryParams.ExpressionAttributeValues[':userId'] = params.userId;
      }

      if (params.action) {
        queryParams.FilterExpression += ' AND #action = :action';
        queryParams.ExpressionAttributeNames = { '#action': 'action' };
        queryParams.ExpressionAttributeValues[':action'] = params.action;
      }

      if (params.resource) {
        queryParams.FilterExpression += ' AND #resource = :resource';
        queryParams.ExpressionAttributeNames = { 
          ...queryParams.ExpressionAttributeNames,
          '#resource': 'resource' 
        };
        queryParams.ExpressionAttributeValues[':resource'] = params.resource;
      }

      if (params.dateRange) {
        queryParams.FilterExpression += ' AND #timestamp BETWEEN :startDate AND :endDate';
        queryParams.ExpressionAttributeNames = {
          ...queryParams.ExpressionAttributeNames,
          '#timestamp': 'timestamp'
        };
        queryParams.ExpressionAttributeValues[':startDate'] = params.dateRange.start;
        queryParams.ExpressionAttributeValues[':endDate'] = params.dateRange.end;
      }

      const result = await dynamodb.scan(queryParams);
      const logs = (result.Items || []).map(item => this.mapToAuditLog(item));

      return {
        logs,
        total: result.Count || 0,
        page,
        limit
      };
    } catch (error) {
      console.error('Failed to get audit logs:', error);
      throw new Error(`Audit logs retrieval failed: ${error.message}`);
    }
  }

  async logAuditEvent(event: {
    userId: string;
    userName: string;
    userRole: string;
    action: string;
    resource: string;
    resourceId?: string;
    details: Record<string, any>;
    ipAddress: string;
    userAgent: string;
    success: boolean;
    errorMessage?: string;
  }): Promise<void> {
    try {
      const auditId = `audit-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const severity = this.calculateAuditSeverity(event.action, event.resource, event.success);

      await dynamodb.put({
        PK: `ADMIN#AUDIT#${auditId}`,
        SK: 'DETAILS',
        GSI1PK: `USER#${event.userId}`,
        GSI1SK: `TIMESTAMP#${new Date().toISOString()}`,
        auditId,
        userId: event.userId,
        userName: event.userName,
        userRole: event.userRole,
        action: event.action,
        resource: event.resource,
        resourceId: event.resourceId,
        details: event.details,
        ipAddress: event.ipAddress,
        userAgent: event.userAgent,
        timestamp: new Date().toISOString(),
        severity,
        success: event.success,
        errorMessage: event.errorMessage
      });
    } catch (error) {
      console.error('Failed to log audit event:', error);
      // Don't throw error to avoid breaking the main operation
    }
  }

  async exportSystemData(request: DataExportRequest): Promise<DataExportResult> {
    try {
      const exportId = `export-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      // Create export record
      await dynamodb.put({
        PK: `ADMIN#EXPORT#${exportId}`,
        SK: 'DETAILS',
        exportId,
        status: 'Pending',
        progress: 0,
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
        request
      });

      // Start background export process (would be implemented as separate Lambda)
      await this.startExportProcess(exportId, request);

      return {
        exportId,
        status: 'Pending',
        progress: 0,
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      };
    } catch (error) {
      console.error('Failed to start data export:', error);
      throw new Error(`Data export failed: ${error.message}`);
    }
  }

  private async getSystemMetrics(): Promise<any> {
    // Mock system metrics - in real implementation would get from CloudWatch or monitoring service
    return {
      uptime: 2592000, // 30 days in seconds
      cpuUsage: 45,
      memoryUsage: 62,
      diskUsage: 38,
      networkThroughput: 125.5
    };
  }

  private async getModuleStatuses(): Promise<any[]> {
    // Check health of all modules
    const modules = ['Equipment', 'Requests', 'Teams', 'Analytics', 'Kanban'];
    
    return modules.map(module => ({
      module,
      status: Math.random() > 0.1 ? 'Healthy' : 'Warning', // 90% healthy
      lastCheck: new Date().toISOString(),
      responseTime: Math.floor(Math.random() * 200) + 50 // 50-250ms
    }));
  }

  private async getRecentActivity(): Promise<ActivitySummary> {
    // Mock recent activity - would aggregate from actual data
    return {
      last24Hours: {
        requests: 47,
        equipmentUpdates: 23,
        userLogins: 89,
        maintenanceCompleted: 12
      },
      trends: {
        requestsTrend: 'up',
        userActivityTrend: 'stable',
        systemPerformanceTrend: 'up'
      }
    };
  }

  private async getActiveAlerts(): Promise<SystemAlert[]> {
    // Mock system alerts - would come from monitoring system
    return [
      {
        id: 'alert-1',
        type: 'Performance',
        severity: 'Medium',
        title: 'High Memory Usage',
        message: 'System memory usage is above 80% threshold',
        component: 'API Server',
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        acknowledged: false,
        autoResolved: false
      }
    ];
  }

  private async getActiveUserCount(): Promise<number> {
    // Count users active in last 24 hours
    return 42; // Mock value
  }

  private async getTotalUserCount(): Promise<number> {
    // Count total registered users
    return 156; // Mock value
  }

  private calculateSystemStatus(moduleStatuses: any[], systemMetrics: any): 'Healthy' | 'Warning' | 'Critical' | 'Maintenance' {
    const criticalModules = moduleStatuses.filter(m => m.status === 'Critical').length;
    const warningModules = moduleStatuses.filter(m => m.status === 'Warning').length;
    
    if (criticalModules > 0 || systemMetrics.cpuUsage > 90 || systemMetrics.memoryUsage > 90) {
      return 'Critical';
    }
    
    if (warningModules > 0 || systemMetrics.cpuUsage > 80 || systemMetrics.memoryUsage > 80) {
      return 'Warning';
    }
    
    return 'Healthy';
  }

  private async getComponentHealth(): Promise<any[]> {
    // Mock component health data
    return [
      {
        name: 'API',
        status: 'Healthy',
        metrics: {
          responseTime: 145,
          errorRate: 0.2,
          throughput: 125,
          availability: 99.8
        },
        alerts: 0,
        lastCheck: new Date().toISOString()
      },
      {
        name: 'Database',
        status: 'Healthy',
        metrics: {
          responseTime: 23,
          errorRate: 0.0,
          throughput: 450,
          availability: 99.9
        },
        alerts: 0,
        lastCheck: new Date().toISOString()
      },
      {
        name: 'WebSocket',
        status: 'Warning',
        metrics: {
          responseTime: 89,
          errorRate: 1.2,
          throughput: 67,
          availability: 98.5
        },
        alerts: 1,
        lastCheck: new Date().toISOString()
      }
    ];
  }

  private async getPerformanceMetrics(): Promise<any> {
    return {
      apiResponseTime: 145,
      databaseResponseTime: 23,
      memoryUsage: 62,
      cpuUsage: 45,
      diskUsage: 38
    };
  }

  private async getPerformanceTrends(): Promise<any> {
    // Mock trend data - would come from time-series database
    return {
      responseTimeTrend: [],
      errorRateTrend: [],
      throughputTrend: []
    };
  }

  private calculateComponentScore(component: any): number {
    // Calculate health score based on metrics
    const responseScore = Math.max(0, 100 - (component.metrics.responseTime / 10));
    const errorScore = Math.max(0, 100 - (component.metrics.errorRate * 10));
    const availabilityScore = component.metrics.availability;
    
    return Math.round((responseScore + errorScore + availabilityScore) / 3);
  }

  private getStatusFromScore(score: number): 'Healthy' | 'Warning' | 'Critical' {
    if (score >= 85) return 'Healthy';
    if (score >= 70) return 'Warning';
    return 'Critical';
  }

  private mapToAuditLog(item: any): AuditLog {
    return {
      id: item.auditId,
      userId: item.userId,
      userName: item.userName,
      userRole: item.userRole,
      action: item.action,
      resource: item.resource,
      resourceId: item.resourceId,
      details: item.details,
      ipAddress: item.ipAddress,
      userAgent: item.userAgent,
      timestamp: item.timestamp,
      severity: item.severity,
      success: item.success,
      errorMessage: item.errorMessage
    };
  }

  private calculateAuditSeverity(action: string, resource: string, success: boolean): 'Low' | 'Medium' | 'High' | 'Critical' {
    if (!success) return 'High';
    
    const criticalActions = ['DELETE', 'SYSTEM_CONFIG_CHANGE', 'USER_ROLE_CHANGE'];
    const highActions = ['CREATE', 'UPDATE', 'LOGIN_FAILED'];
    
    if (criticalActions.includes(action)) return 'Critical';
    if (highActions.includes(action)) return 'Medium';
    return 'Low';
  }

  private async startExportProcess(exportId: string, request: DataExportRequest): Promise<void> {
    // In real implementation, this would trigger a background Lambda function
    // For now, we'll just update the status to processing
    setTimeout(async () => {
      await dynamodb.update(
        { PK: `ADMIN#EXPORT#${exportId}`, SK: 'DETAILS' },
        {
          status: 'Processing',
          progress: 25
        }
      );
    }, 1000);
  }
}

export const adminService = new AdminService();
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` and understand all module integration patterns and existing admin functionality.

### Step 1: Backend Implementation

1. Create AdminService for system-wide management and monitoring
2. Implement comprehensive audit logging across all operations
3. Add system health monitoring with real-time metrics
4. Create data export and backup functionality

### Step 2: Frontend Implementation

1. Create comprehensive admin dashboard with system overview
2. Implement advanced user management with bulk operations
3. Add system health monitoring with real-time updates
4. Create audit log viewer with advanced filtering

### Step 3: Integration

1. Connect to all existing modules for unified management
2. Implement system-wide audit logging
3. Test health monitoring and alerting systems
4. Verify data export and backup functionality

## Acceptance Criteria

- [ ] Admin dashboard provides comprehensive system overview and health monitoring
- [ ] User management includes advanced features like bulk operations and role management
- [ ] Audit logging captures all system activities with detailed information
- [ ] System health monitoring provides real-time metrics and intelligent alerting
- [ ] Data export functionality creates comprehensive system backups
- [ ] **Demo Ready:** Can showcase complete admin functionality in 30 seconds
- [ ] **System Management:** Comprehensive administrative control over entire system
- [ ] **Security & Compliance:** Complete audit trail and access control
- [ ] **Monitoring & Alerting:** Proactive system health monitoring
- [ ] **Mobile Responsive:** Admin interface works on all devices

## Testing Checklist

- [ ] **System Monitoring:** Test health metrics collection and alerting
- [ ] **Audit Logging:** Verify all operations are properly logged
- [ ] **User Management:** Test bulk operations and role management
- [ ] **Data Export:** Test backup and export functionality
- [ ] **Security:** Verify admin-only access and proper authorization

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **Admin Security:** Verified admin-only access controls are properly implemented
- [ ] **Audit Logging:** Confirmed audit logging is working across all modules
- [ ] **System Monitoring:** Verified health monitoring and alerting systems
- [ ] **Data Export:** Tested backup and export functionality in production environment