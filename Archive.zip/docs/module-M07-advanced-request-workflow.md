# Module M07: Advanced Request Workflow

## Overview

**Estimated Time:** 1.5hr

**Complexity:** Complex

**Type:** Full-stack

**Risk Level:** Medium

**Dependencies:** F04 (Request Management) + F01 (Equipment Management) + F03 (Maintenance Teams)

## Problem Context

Enhance the basic request management with advanced workflow features including auto-assignment logic, smart scheduling, escalation rules, SLA tracking, and integration with equipment health data and team availability. This module transforms basic request tracking into an intelligent workflow management system.

## Technical Requirements

**Module Type:** Full-stack (Enhancement of F04)

### Backend Tasks

- [ ] **Enhanced Handler Files:** Extend existing request handlers
  - `handlers/autoAssignRequest.ts` - POST /api/requests/:id/auto-assign
  - `handlers/escalateRequest.ts` - POST /api/requests/:id/escalate
  - `handlers/getRequestWorkflow.ts` - GET /api/requests/:id/workflow
  - `handlers/updateSLA.ts` - PUT /api/requests/:id/sla
  - `handlers/getRequestAnalytics.ts` - GET /api/requests/analytics

- [ ] **Function Configs:** Create new function configurations
  - `functions/autoAssignRequest.yml`
  - `functions/escalateRequest.yml`
  - `functions/getRequestWorkflow.yml`
  - `functions/updateSLA.yml`
  - `functions/getRequestAnalytics.yml`

- [ ] **Enhanced Service Layer:** Extend RequestService with workflow features
  - Auto-assignment algorithms
  - Escalation rule engine
  - SLA tracking and notifications
  - Workflow state management
  - Integration with equipment and team data

- [ ] **Type Definitions:** Add workflow types to `types.ts`
  - Workflow state definitions
  - SLA tracking interfaces
  - Auto-assignment rules
  - Escalation policies

- [ ] **Integration Points:** Connect with F01 (Equipment) and F03 (Teams)
  - Equipment health integration for priority calculation
  - Team availability integration for assignment
  - Cross-module notifications and updates

### Frontend Tasks

- [ ] **Enhanced Components:** Extend existing request components
  - `components/requests/WorkflowTimeline.tsx` - Visual workflow progress
  - `components/requests/AutoAssignmentPanel.tsx` - Smart assignment interface
  - `components/requests/SLATracker.tsx` - SLA monitoring and alerts
  - `components/requests/EscalationManager.tsx` - Escalation rules and actions
  - `components/requests/RequestAnalytics.tsx` - Workflow analytics dashboard

- [ ] **Enhanced Pages:** Add advanced request management pages
  - `pages/requests/RequestWorkflowPage.tsx` - Advanced workflow management
  - `pages/requests/RequestAnalyticsPage.tsx` - Analytics and reporting

- [ ] **Enhanced API Integration:** Extend request API service
  - `hooks/useRequestWorkflow.ts` - Workflow management hooks
  - `hooks/useRequestAnalytics.ts` - Analytics and reporting hooks

### Database Schema Extensions

```
PK: REQUEST#[id] | SK: WORKFLOW#[step] | GSI1PK: WORKFLOW_STATUS#[status] | GSI1SK: REQUEST#[id]
PK: REQUEST#[id] | SK: SLA#[type] | GSI1PK: SLA_STATUS#[status] | GSI1SK: DUE_DATE#[date]
PK: REQUEST#[id] | SK: ESCALATION#[level] | GSI1PK: ESCALATION_DATE#[date] | GSI1SK: REQUEST#[id]

Workflow Fields:
- workflowStep: string (Created, Assigned, InProgress, Review, Completed)
- stepStartTime: string (ISO date)
- stepDuration: number (minutes)
- assignmentRules: {
  autoAssign: boolean;
  preferredTeam?: string;
  skillRequirements: string[];
  urgencyMultiplier: number;
}
- slaTracking: {
  responseTime: number; // minutes
  resolutionTime: number; // minutes
  responseDeadline: string; // ISO date
  resolutionDeadline: string; // ISO date
  isBreached: boolean;
}
- escalationRules: {
  level: number;
  triggerTime: number; // minutes
  escalateTo: string; // user ID or role
  notificationSent: boolean;
}
```

## Enhancement Features

### Enhancement Feature: Intelligent Auto-Assignment

**Problem Solved:** Automatically assign maintenance requests to the optimal technician based on skills, workload, location, equipment expertise, and current availability.

**Enhancement Type:** AI + Smart Logic - Uses machine learning algorithms and real-time data to optimize technician assignments

**User Trigger:** "Auto-Assign" button on request or automatic assignment on request creation

**Input Requirements:**
- **Required Fields:** Request ID, equipment details, urgency level
- **Optional Fields:** Preferred team, required skills, location constraints
- **Validation Rules:** Request must be in "New" status, equipment must exist

**Processing Logic:**
1. **Skill Matching:** Analyze required skills vs technician capabilities
2. **Workload Analysis:** Check current technician assignments and capacity
3. **Location Optimization:** Consider technician location vs equipment location
4. **AI Optimization:** Use machine learning to predict optimal assignments
5. **Real-time Assignment:** Automatically assign and notify technician

**COMPLETE IMPLEMENTATION SPECIFICATION:**

**Types Definition:**
```typescript
// types.ts - Add these exact types
export interface RequestWorkflow {
  requestId: string;
  currentStep: 'Created' | 'Assigned' | 'InProgress' | 'Review' | 'Completed' | 'Escalated';
  workflowHistory: WorkflowStep[];
  slaTracking: SLATracking;
  escalationRules: EscalationRule[];
  assignmentHistory: AssignmentHistory[];
  estimatedCompletion: string;
  actualCompletion?: string;
}

export interface WorkflowStep {
  step: string;
  status: 'Pending' | 'Active' | 'Completed' | 'Skipped';
  startTime?: string;
  endTime?: string;
  duration?: number; // minutes
  assignedTo?: string;
  notes?: string;
  automatedAction: boolean;
}

export interface SLATracking {
  responseTime: {
    target: number; // minutes
    actual?: number;
    deadline: string;
    isBreached: boolean;
    remainingTime: number;
  };
  resolutionTime: {
    target: number; // minutes
    actual?: number;
    deadline: string;
    isBreached: boolean;
    remainingTime: number;
  };
  escalationTriggers: Array<{
    level: number;
    triggerTime: number;
    triggered: boolean;
    triggeredAt?: string;
  }>;
}

export interface AutoAssignmentRequest {
  requestId: string;
  equipmentId: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  requiredSkills?: string[];
  preferredTeam?: string;
  locationConstraints?: {
    maxDistance?: number; // km
    sameBuilding?: boolean;
  };
  workloadConsideration: boolean;
  skillWeighting: number; // 0-1
  locationWeighting: number; // 0-1
  availabilityWeighting: number; // 0-1
}

export interface AutoAssignmentResponse {
  assignedTechnician: {
    userId: string;
    name: string;
    email: string;
    team: string;
    skills: string[];
    currentWorkload: number;
    location?: string;
    estimatedArrival?: number; // minutes
  };
  alternativeTechnicians: Array<{
    userId: string;
    name: string;
    score: number;
    reason: string;
  }>;
  assignmentScore: number; // 0-100
  assignmentReasoning: string[];
  estimatedResponseTime: number; // minutes
  confidence: number; // 0-1
  autoAssigned: boolean;
}

export interface EscalationRule {
  level: number;
  triggerCondition: 'TimeElapsed' | 'SLABreach' | 'NoResponse' | 'HighPriority';
  triggerValue: number; // minutes or threshold
  escalateTo: string; // user ID or role
  notificationMethod: 'Email' | 'SMS' | 'Push' | 'All';
  isActive: boolean;
  lastTriggered?: string;
}

export interface RequestAnalytics {
  timeRange: {
    start: string;
    end: string;
  };
  metrics: {
    totalRequests: number;
    averageResponseTime: number;
    averageResolutionTime: number;
    slaComplianceRate: number;
    escalationRate: number;
    autoAssignmentRate: number;
  };
  trends: {
    requestVolume: Array<{ date: string; count: number }>;
    responseTimesTrend: Array<{ date: string; avgTime: number }>;
    slaBreaches: Array<{ date: string; breaches: number }>;
  };
  teamPerformance: Array<{
    teamId: string;
    teamName: string;
    requestsHandled: number;
    avgResponseTime: number;
    slaCompliance: number;
  }>;
  equipmentInsights: Array<{
    equipmentId: string;
    equipmentName: string;
    requestCount: number;
    avgResolutionTime: number;
    criticalIssues: number;
  }>;
}
```

**Frontend Component:**
```typescript
// components/requests/AutoAssignmentPanel.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { 
  Users, 
  Zap, 
  MapPin, 
  Clock, 
  Target,
  Brain,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { AutoAssignmentResponse, MaintenanceRequest } from '@/types/requests';

interface AutoAssignmentPanelProps {
  request: MaintenanceRequest;
  onAssignmentComplete?: (assignment: AutoAssignmentResponse) => void;
}

export const AutoAssignmentPanel = ({ request, onAssignmentComplete }: AutoAssignmentPanelProps) => {
  const [isAssigning, setIsAssigning] = useState(false);
  const [assignment, setAssignment] = useState<AutoAssignmentResponse | null>(null);
  const [assignmentConfig, setAssignmentConfig] = useState({
    workloadConsideration: true,
    skillWeighting: 0.4,
    locationWeighting: 0.3,
    availabilityWeighting: 0.3,
    maxDistance: 50,
    sameBuilding: false
  });

  const handleAutoAssignment = async () => {
    setIsAssigning(true);
    try {
      const response = await fetch(`/api/requests/${request.id}/auto-assign`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          requestId: request.id,
          equipmentId: request.equipmentId,
          urgency: request.priority,
          requiredSkills: getRequiredSkills(request),
          preferredTeam: request.assignedTeam,
          locationConstraints: {
            maxDistance: assignmentConfig.maxDistance,
            sameBuilding: assignmentConfig.sameBuilding
          },
          workloadConsideration: assignmentConfig.workloadConsideration,
          skillWeighting: assignmentConfig.skillWeighting,
          locationWeighting: assignmentConfig.locationWeighting,
          availabilityWeighting: assignmentConfig.availabilityWeighting
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Auto-assignment failed');
      }

      const data = await response.json();
      setAssignment(data.data);
      onAssignmentComplete?.(data.data);
      
      if (data.data.autoAssigned) {
        toast.success(`Request automatically assigned to ${data.data.assignedTechnician.name}`);
      } else {
        toast.success('Assignment recommendation generated');
      }
    } catch (error) {
      console.error('Auto-assignment error:', error);
      toast.error(error.message || 'Auto-assignment failed. Please try again.');
    } finally {
      setIsAssigning(false);
    }
  };

  const confirmAssignment = async () => {
    if (!assignment) return;

    try {
      const response = await fetch(`/api/requests/${request.id}/assign`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getToken()}`
        },
        body: JSON.stringify({
          assignedTechnician: assignment.assignedTechnician.userId,
          assignedTeam: assignment.assignedTechnician.team,
          estimatedResponseTime: assignment.estimatedResponseTime
        })
      });

      if (response.ok) {
        toast.success('Request assigned successfully');
        onAssignmentComplete?.(assignment);
      }
    } catch (error) {
      toast.error('Failed to confirm assignment');
    }
  };

  const getRequiredSkills = (request: MaintenanceRequest): string[] => {
    // Extract required skills based on request and equipment type
    const skillMap: Record<string, string[]> = {
      'Machine': ['Mechanical Repair', 'Hydraulics', 'Pneumatics'],
      'Vehicle': ['Automotive Repair', 'Engine Diagnostics'],
      'Computer': ['Hardware Troubleshooting', 'Network Configuration'],
      'Electrical': ['Electrical Wiring', 'Circuit Analysis']
    };
    return skillMap[request.equipmentCategory] || [];
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Assignment Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-500" />
            Smart Assignment Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="workload">Consider Current Workload</Label>
                <Switch
                  id="workload"
                  checked={assignmentConfig.workloadConsideration}
                  onCheckedChange={(checked) => 
                    setAssignmentConfig(prev => ({ ...prev, workloadConsideration: checked }))
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Skill Matching Weight: {Math.round(assignmentConfig.skillWeighting * 100)}%</Label>
                <Slider
                  value={[assignmentConfig.skillWeighting]}
                  onValueChange={([value]) => 
                    setAssignmentConfig(prev => ({ ...prev, skillWeighting: value }))
                  }
                  max={1}
                  step={0.1}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label>Location Priority: {Math.round(assignmentConfig.locationWeighting * 100)}%</Label>
                <Slider
                  value={[assignmentConfig.locationWeighting]}
                  onValueChange={([value]) => 
                    setAssignmentConfig(prev => ({ ...prev, locationWeighting: value }))
                  }
                  max={1}
                  step={0.1}
                  className="w-full"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Availability Weight: {Math.round(assignmentConfig.availabilityWeighting * 100)}%</Label>
                <Slider
                  value={[assignmentConfig.availabilityWeighting]}
                  onValueChange={([value]) => 
                    setAssignmentConfig(prev => ({ ...prev, availabilityWeighting: value }))
                  }
                  max={1}
                  step={0.1}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label>Max Distance: {assignmentConfig.maxDistance} km</Label>
                <Slider
                  value={[assignmentConfig.maxDistance]}
                  onValueChange={([value]) => 
                    setAssignmentConfig(prev => ({ ...prev, maxDistance: value }))
                  }
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="sameBuilding">Same Building Only</Label>
                <Switch
                  id="sameBuilding"
                  checked={assignmentConfig.sameBuilding}
                  onCheckedChange={(checked) => 
                    setAssignmentConfig(prev => ({ ...prev, sameBuilding: checked }))
                  }
                />
              </div>
            </div>
          </div>

          <Button 
            onClick={handleAutoAssignment}
            disabled={isAssigning || request.status !== 'New'}
            className="w-full"
            size="lg"
          >
            {isAssigning ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Analyzing Technicians...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4 mr-2" />
                Run Smart Assignment
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Assignment Results */}
      {assignment && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-green-500" />
                Assignment Recommendation
              </div>
              <Badge className={`${getScoreColor(assignment.assignmentScore)} bg-transparent border`}>
                {assignment.assignmentScore}% Match
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="recommended" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="recommended">Recommended</TabsTrigger>
                <TabsTrigger value="alternatives">Alternatives</TabsTrigger>
                <TabsTrigger value="reasoning">Analysis</TabsTrigger>
              </TabsList>

              <TabsContent value="recommended" className="space-y-4">
                <Card className="border-green-200 bg-green-50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-100 rounded-full">
                          <Users className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <div className="font-semibold text-lg">
                            {assignment.assignedTechnician.name}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {assignment.assignedTechnician.team}
                          </div>
                        </div>
                      </div>
                      
                      {!assignment.autoAssigned && (
                        <Button onClick={confirmAssignment}>
                          Confirm Assignment
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Target className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="text-sm font-medium">
                          {assignment.assignedTechnician.currentWorkload}/10
                        </div>
                        <div className="text-xs text-muted-foreground">Current Load</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="text-sm font-medium">
                          {assignment.estimatedResponseTime}min
                        </div>
                        <div className="text-xs text-muted-foreground">Response Time</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="text-sm font-medium">
                          {assignment.assignedTechnician.estimatedArrival || 'N/A'}min
                        </div>
                        <div className="text-xs text-muted-foreground">Travel Time</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <CheckCircle className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="text-sm font-medium">
                          {Math.round(assignment.confidence * 100)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Confidence</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium mb-2">Skills</h4>
                      <div className="flex flex-wrap gap-1">
                        {assignment.assignedTechnician.skills.map((skill, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="alternatives" className="space-y-3">
                {assignment.alternativeTechnicians.map((tech, index) => (
                  <Card key={tech.userId}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{tech.name}</div>
                          <div className="text-sm text-muted-foreground">{tech.reason}</div>
                        </div>
                        <div className="text-right">
                          <div className={`text-lg font-bold ${getScoreColor(tech.score)}`}>
                            {tech.score}%
                          </div>
                          <Progress value={tech.score} className="w-20 h-2" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="reasoning" className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                    <Brain className="h-4 w-4 text-purple-500" />
                    Assignment Analysis
                  </h4>
                  <ul className="space-y-2">
                    {assignment.assignmentReasoning.map((reason, index) => (
                      <li key={index} className="flex items-start text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                        {reason}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-sm font-medium text-blue-800 mb-1">
                    Assignment Score Breakdown
                  </div>
                  <div className="text-sm text-blue-700">
                    This assignment scored {assignment.assignmentScore}% based on skill matching 
                    ({Math.round(assignmentConfig.skillWeighting * 100)}%), location proximity 
                    ({Math.round(assignmentConfig.locationWeighting * 100)}%), and current availability 
                    ({Math.round(assignmentConfig.availabilityWeighting * 100)}%).
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {isAssigning && (
        <Card>
          <CardContent className="p-6 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <div className="text-lg font-medium mb-2">Analyzing Available Technicians</div>
            <div className="text-sm text-muted-foreground">
              Evaluating skills, workload, location, and availability...
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
```

**Backend Service Method:**
```typescript
// services/RequestService.ts - Add this method
async autoAssignRequest(params: AutoAssignmentRequest): Promise<AutoAssignmentResponse> {
  try {
    // Get request and equipment details
    const request = await this.getRequest(params.requestId);
    if (!request) {
      throw new Error('Request not found');
    }

    const equipment = await this.getEquipmentDetails(params.equipmentId);
    if (!equipment) {
      throw new Error('Equipment not found');
    }

    // Get available technicians
    const availableTechnicians = await this.getAvailableTechnicians(params.preferredTeam);
    
    if (availableTechnicians.length === 0) {
      throw new Error('No available technicians found');
    }

    // Score each technician
    const technicianScores = await Promise.all(
      availableTechnicians.map(async (technician) => {
        const score = await this.calculateTechnicianScore(technician, params, equipment);
        return { technician, score };
      })
    );

    // Sort by score (highest first)
    technicianScores.sort((a, b) => b.score.total - a.score.total);

    const bestTechnician = technicianScores[0];
    const alternatives = technicianScores.slice(1, 4);

    // Use AI to generate assignment reasoning
    const aiPrompt = `Analyze technician assignment for maintenance request:

Request: ${request.subject}
Equipment: ${equipment.name} (${equipment.category})
Urgency: ${params.urgency}
Required Skills: ${params.requiredSkills?.join(', ') || 'None specified'}

Recommended Technician: ${bestTechnician.technician.name}
- Team: ${bestTechnician.technician.team}
- Skills: ${bestTechnician.technician.skills.join(', ')}
- Current Workload: ${bestTechnician.technician.currentWorkload}/10
- Score: ${bestTechnician.score.total}/100

Provide 3-4 specific reasons why this technician is the best choice for this assignment.
Consider skill match, availability, workload, and location factors.`;

    const aiResponse = await geminiClient.generateJSON({
      prompt: aiPrompt,
      schema: {
        reasoning: 'array of strings',
        estimatedResponseTime: 'number',
        confidence: 'number'
      }
    });

    // Calculate estimated response time
    const baseResponseTime = this.getBaseResponseTime(params.urgency);
    const workloadMultiplier = 1 + (bestTechnician.technician.currentWorkload / 10);
    const estimatedResponseTime = Math.round(baseResponseTime * workloadMultiplier);

    // Determine if auto-assignment should be applied
    const autoAssign = bestTechnician.score.total >= 80 && params.urgency !== 'Critical';

    // If auto-assigning, update the request
    if (autoAssign) {
      await this.assignRequest(params.requestId, {
        assignedTechnician: bestTechnician.technician.userId,
        assignedTeam: bestTechnician.technician.team,
        estimatedResponseTime
      });
    }

    return {
      assignedTechnician: {
        userId: bestTechnician.technician.userId,
        name: bestTechnician.technician.name,
        email: bestTechnician.technician.email,
        team: bestTechnician.technician.team,
        skills: bestTechnician.technician.skills,
        currentWorkload: bestTechnician.technician.currentWorkload,
        location: bestTechnician.technician.location,
        estimatedArrival: bestTechnician.score.travelTime
      },
      alternativeTechnicians: alternatives.map(alt => ({
        userId: alt.technician.userId,
        name: alt.technician.name,
        score: alt.score.total,
        reason: this.generateAlternativeReason(alt.technician, alt.score)
      })),
      assignmentScore: bestTechnician.score.total,
      assignmentReasoning: aiResponse.reasoning || [
        `Best skill match for ${equipment.category} maintenance`,
        `Optimal workload balance (${bestTechnician.technician.currentWorkload}/10 current requests)`,
        `Team specialization aligns with equipment requirements`,
        `Available for immediate response`
      ],
      estimatedResponseTime: aiResponse.estimatedResponseTime || estimatedResponseTime,
      confidence: aiResponse.confidence || (bestTechnician.score.total / 100),
      autoAssigned: autoAssign
    };
  } catch (error) {
    console.error('Auto-assignment failed:', error);
    throw new Error(`Auto-assignment failed: ${error.message}`);
  }
}

private async calculateTechnicianScore(
  technician: any, 
  params: AutoAssignmentRequest, 
  equipment: any
): Promise<{
  total: number;
  skillMatch: number;
  availability: number;
  location: number;
  workload: number;
  travelTime?: number;
}> {
  // Skill matching score (0-40 points)
  const skillScore = this.calculateSkillMatch(
    technician.skills, 
    params.requiredSkills || []
  ) * params.skillWeighting * 100;

  // Availability score (0-30 points)
  const availabilityScore = this.calculateAvailabilityScore(technician) * params.availabilityWeighting * 100;

  // Location score (0-20 points)
  const locationScore = await this.calculateLocationScore(
    technician, 
    equipment, 
    params.locationConstraints
  ) * params.locationWeighting * 100;

  // Workload score (0-10 points)
  const workloadScore = this.calculateWorkloadScore(technician.currentWorkload);

  const total = Math.round(skillScore + availabilityScore + locationScore + workloadScore);

  return {
    total: Math.min(total, 100),
    skillMatch: Math.round(skillScore),
    availability: Math.round(availabilityScore),
    location: Math.round(locationScore),
    workload: Math.round(workloadScore),
    travelTime: await this.calculateTravelTime(technician, equipment)
  };
}

private calculateSkillMatch(technicianSkills: string[], requiredSkills: string[]): number {
  if (requiredSkills.length === 0) return 0.8; // Default good score if no specific skills required

  const matchCount = requiredSkills.filter(skill => 
    technicianSkills.some(techSkill => 
      techSkill.toLowerCase().includes(skill.toLowerCase()) ||
      skill.toLowerCase().includes(techSkill.toLowerCase())
    )
  ).length;

  return matchCount / requiredSkills.length;
}

private calculateAvailabilityScore(technician: any): number {
  // Score based on current availability and schedule
  if (technician.isOnLeave) return 0;
  if (technician.currentWorkload >= 10) return 0.2;
  if (technician.currentWorkload >= 8) return 0.5;
  if (technician.currentWorkload >= 6) return 0.7;
  if (technician.currentWorkload >= 4) return 0.9;
  return 1.0;
}

private async calculateLocationScore(
  technician: any, 
  equipment: any, 
  constraints?: any
): Promise<number> {
  // Mock location scoring - in real system would use GPS/mapping services
  if (constraints?.sameBuilding && technician.building === equipment.building) {
    return 1.0;
  }

  // Mock distance calculation
  const distance = Math.random() * 50; // km
  if (constraints?.maxDistance && distance > constraints.maxDistance) {
    return 0.1;
  }

  // Score inversely proportional to distance
  return Math.max(0.1, 1 - (distance / 100));
}

private calculateWorkloadScore(currentWorkload: number): number {
  // Bonus points for balanced workload
  if (currentWorkload <= 3) return 10;
  if (currentWorkload <= 5) return 8;
  if (currentWorkload <= 7) return 5;
  return 2;
}

private async calculateTravelTime(technician: any, equipment: any): Promise<number> {
  // Mock travel time calculation
  return Math.floor(Math.random() * 30) + 10; // 10-40 minutes
}

private generateAlternativeReason(technician: any, score: any): string {
  if (score.skillMatch > 80) return 'Excellent skill match, higher workload';
  if (score.availability > 80) return 'Highly available, moderate skill match';
  if (score.location > 80) return 'Optimal location, busy schedule';
  return 'Good overall candidate, lower priority';
}

private getBaseResponseTime(urgency: string): number {
  switch (urgency) {
    case 'Critical': return 15;
    case 'High': return 60;
    case 'Medium': return 240;
    case 'Low': return 480;
    default: return 240;
  }
}

private async getAvailableTechnicians(preferredTeam?: string): Promise<any[]> {
  // Mock technician data - in real system would query user/team services
  return [
    {
      userId: 'tech-1',
      name: 'John Smith',
      email: 'john@company.com',
      team: 'Mechanics',
      skills: ['Mechanical Repair', 'Hydraulics', 'Pneumatics'],
      currentWorkload: 4,
      location: 'Building A',
      building: 'A',
      isOnLeave: false
    },
    {
      userId: 'tech-2',
      name: 'Sarah Johnson',
      email: 'sarah@company.com',
      team: 'Electricians',
      skills: ['Electrical Wiring', 'Circuit Analysis', 'Motor Repair'],
      currentWorkload: 2,
      location: 'Building B',
      building: 'B',
      isOnLeave: false
    },
    {
      userId: 'tech-3',
      name: 'Mike Wilson',
      email: 'mike@company.com',
      team: 'IT Support',
      skills: ['Hardware Troubleshooting', 'Network Configuration', 'Software Installation'],
      currentWorkload: 6,
      location: 'Building A',
      building: 'A',
      isOnLeave: false
    }
  ].filter(tech => !preferredTeam || tech.team === preferredTeam);
}
```

## Implementation Guide

### Step 0: Study Phase (MANDATORY - Do This First)

**CRITICAL:** Read `guidelines/project-architecture.md` and understand F04 (Request Management), F01 (Equipment), and F03 (Teams) integration patterns.

### Step 1: Backend Enhancement

1. Extend existing RequestService with workflow management
2. Implement auto-assignment algorithms with AI optimization
3. Add SLA tracking and escalation rule engine
4. Create integration points with equipment and team services

### Step 2: Frontend Enhancement

1. Create advanced workflow management components
2. Implement auto-assignment interface with configuration options
3. Add SLA tracking and escalation management
4. Build workflow analytics dashboard

### Step 3: Integration

1. Connect with F01 (Equipment) for health-based priority calculation
2. Integrate with F03 (Teams) for real-time availability data
3. Test auto-assignment workflow end-to-end
4. Verify SLA tracking and escalation rules work correctly

## Acceptance Criteria

- [ ] Auto-assignment intelligently matches technicians based on skills, workload, and location
- [ ] SLA tracking monitors response and resolution times with breach alerts
- [ ] Escalation rules automatically trigger based on configurable conditions
- [ ] Workflow timeline shows visual progress through request lifecycle
- [ ] Analytics dashboard provides insights into workflow performance
- [ ] **Demo Ready:** Can demonstrate intelligent auto-assignment in 30 seconds
- [ ] **Integration Working:** Seamlessly connects with F01, F03, and F04 modules
- [ ] **AI-Powered:** Uses machine learning for optimal technician assignments
- [ ] **Workflow Management:** Complete request lifecycle management with automation
- [ ] **Mobile Responsive:** Works on mobile devices for field technicians

## Testing Checklist

- [ ] **Auto-Assignment:** Test intelligent technician matching algorithms
- [ ] **SLA Tracking:** Verify SLA monitoring and breach detection
- [ ] **Escalation Rules:** Test automatic escalation triggers and notifications
- [ ] **Workflow Integration:** Test complete request lifecycle management
- [ ] **Cross-Module Integration:** Verify data flow between modules works correctly

## Deployment Checklist

- [ ] **CRITICAL - Type Check:** Run `bun run typecheck` in both backend and client
- [ ] **Serverless Config:** Added enhanced workflow function imports to serverless.yml
- [ ] **Integration Points:** Verified cross-module API calls work correctly
- [ ] **AI Configuration:** Confirmed Gemini AI integration for assignment optimization
- [ ] **Testing:** Manual testing of all workflow features completed